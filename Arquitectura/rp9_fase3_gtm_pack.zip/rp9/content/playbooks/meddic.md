# MEDDIC-lite Checklist
- Metrics
- Economic buyer
- Decision criteria/process
- Identify pain
- Champion
