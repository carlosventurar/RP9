
import { Handler } from '@netlify/functions'
export const handler: Handler = async () => {
  // TODO: aggregate KPIs from Supabase (leads, crm_events, roi_events)
  return { statusCode: 200, body: JSON.stringify({ leads_week: 0, pilot_rate: 0, win_rate: 0, mrr: 0 }) }
}
