
import { Handler } from '@netlify/functions'
export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' }
  // TODO: verify signature, map event, insert into crm_events, trigger demo-tenant if Pilot Approved
  return { statusCode: 200, body: JSON.stringify({ ok: true }) }
}
