
import { Handler } from '@netlify/functions'
export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' }
  // TODO: call orchestrator to create DEMO tenant and email credentials/checklist
  return { statusCode: 200, body: JSON.stringify({ ok: true }) }
}
