
import { Handler } from '@netlify/functions'
export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' }
  const body = JSON.parse(event.body || '{}')
  // TODO: validate (zod), insert into Supabase.leads, upsert Contact/Company/Deal in CRM, return dealUrl
  return { statusCode: 200, body: JSON.stringify({ ok: true, dealUrl: 'https://app.hubspot.com/deals/EXAMPLE' }) }
}
