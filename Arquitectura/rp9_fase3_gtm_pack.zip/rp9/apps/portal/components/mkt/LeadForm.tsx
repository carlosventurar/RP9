
'use client';
import { useState } from 'react';
export function LeadForm() {
  const [loading,setLoading]=useState(false); const [ok,setOk]=useState(false);
  async function submit(e:any){e.preventDefault(); setLoading(true);
    const body=Object.fromEntries(new FormData(e.target as HTMLFormElement));
    const r=await fetch('/.netlify/functions/leads-submit',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});
    setOk(r.ok); setLoading(false);
  }
  return (
    <form onSubmit={submit} className="space-y-3">
      <input name="name" placeholder="Nombre" className="input" required />
      <input name="email" type="email" placeholder="Email" className="input" required />
      <input name="company" placeholder="Empresa" className="input" required />
      <select name="vertical" className="input"><option value="cc">Contact Center</option><option value="fin">Finanzas</option></select>
      <button disabled={loading} className="btn-primary">{loading?'Enviando…':'Quiero el demo'}</button>
      {ok && <p className="text-green-600">¡Gracias! Te escribimos en breve.</p>}
    </form>
  );
}
