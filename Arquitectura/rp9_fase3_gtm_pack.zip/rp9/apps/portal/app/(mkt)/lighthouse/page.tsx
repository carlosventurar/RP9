export default function Page(){return <div>Lighthouse – Coming soon</div>}
