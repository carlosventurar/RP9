export default function Page(){return <div>Partners – Coming soon</div>}
