export default function Page(){return <div>Webinars – Coming soon</div>}
