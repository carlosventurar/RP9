export default function Page(){return <div>Pricing – Coming soon</div>}
