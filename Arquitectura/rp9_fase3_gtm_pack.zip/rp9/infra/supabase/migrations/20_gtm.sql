
create table if not exists leads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  country text, source text, vertical text, 
  company text, name text, email text, phone text,
  employees int, cc_platform text, pain text,
  status text default 'new',
  crm_contact_id text, crm_company_id text, crm_deal_id text,
  notes text, tenant_id uuid
);

create table if not exists crm_events (
  id bigserial primary key,
  created_at timestamptz default now(),
  crm text not null, type text not null, 
  deal_id text, stage text, amount numeric,
  meta jsonb, lead_id uuid references leads(id)
);

create table if not exists webinars_registrations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  webinar text, country text, vertical text,
  name text, email text, company text, role text
);

create table if not exists roi_events (
  id bigserial primary key, created_at timestamptz default now(),
  country text, vertical text,
  events_month int, minutes_saved int, hourly_cost numeric,
  calc_savings numeric, lead_id uuid
);

create index on leads (created_at desc);
create index on crm_events (deal_id, created_at desc);
create index on webinars_registrations (webinar);
