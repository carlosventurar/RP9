
import { Handler } from '@netlify/functions'
// NOTE: programar como scheduled function en Netlify
export const handler: Handler = async () => {
  // TODO: Por cada tenant activo:
  // 1) llamar {N8N_BASE_URL}/api/v1/executions?limit=50&status=success|error&lastId=...
  // 2) insertar de forma idempotente en Supabase (usage_executions)
  // 3) (opcional) subir usage a Stripe metered
  return { statusCode: 200, body: JSON.stringify({ ok: true }) }
}
