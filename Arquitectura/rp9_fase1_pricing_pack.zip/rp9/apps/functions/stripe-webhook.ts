
import { Handler } from '@netlify/functions'
import Stripe from 'stripe'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, { apiVersion: '2023-10-16' })

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' }
  try {
    const sig = event.headers['stripe-signature'] || ''
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET as string
    const evt = stripe.webhooks.constructEvent(event.body as string, sig, webhookSecret)

    switch (evt.type) {
      case 'checkout.session.completed':
        // TODO: marcar suscripción activa en Supabase
        break
      case 'invoice.paid':
        // TODO: actualizar status pagado
        break
      case 'invoice.payment_failed':
        // TODO: dunning (avisos)
        break
      case 'customer.subscription.updated':
        // TODO: sincronizar estado/periodo
        break
    }

    return { statusCode: 200, body: JSON.stringify({ ok: true }) }
  } catch (e:any) {
    return { statusCode: 400, body: JSON.stringify({ error: e.message }) }
  }
}
