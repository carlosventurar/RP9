
import { Handler } from '@netlify/functions'
import Stripe from 'stripe'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, { apiVersion: '2023-10-16' })

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' }
  try {
    const body = JSON.parse(event.body || '{}')
    const { plan, period, addons = [], tenantId } = body

    if (!['starter','pro','enterprise'].includes(plan)) {
      return { statusCode: 400, body: 'Invalid plan' }
    }
    if (!['monthly','yearly'].includes(period)) {
      return { statusCode: 400, body: 'Invalid period' }
    }

    if (plan === 'enterprise') {
      // Ruta sales-assisted (stub): redirigir a un formulario/CRM
      return { statusCode: 200, body: JSON.stringify({ leadUrl: '/contact?plan=enterprise' }) }
    }

    const priceMap: Record<string,string> = {
      starter_monthly: process.env.STRIPE_PRICE_STARTER_MONTHLY || '',
      starter_yearly:  process.env.STRIPE_PRICE_STARTER_YEARLY  || '',
      pro_monthly:     process.env.STRIPE_PRICE_PRO_MONTHLY     || '',
      pro_yearly:      process.env.STRIPE_PRICE_PRO_YEARLY      || ''
    }

    const line_items: Stripe.Checkout.SessionCreateParams.LineItem[] = [
      { price: priceMap[`${plan}_${period}`], quantity: 1 }
    ]

    const addonPrices: Record<string,string> = {
      exec_10k:  process.env.STRIPE_PRICE_ADDON_EXEC_10K || '',
      exec_50k:  process.env.STRIPE_PRICE_ADDON_EXEC_50K || '',
      exec_100k: process.env.STRIPE_PRICE_ADDON_EXEC_100K || ''
    }
    for (const a of addons) {
      if (addonPrices[a]) line_items.push({ price: addonPrices[a], quantity: 1 })
    }

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items,
      success_url: `${event.headers.origin || 'https://app.rp9.io'}/billing?success=1`,
      cancel_url: `${event.headers.origin || 'https://app.rp9.io'}/pricing?canceled=1`,
      metadata: { tenantId: tenantId || '' }
    })

    return { statusCode: 200, body: JSON.stringify({ url: session.url }) }
  } catch (e:any) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) }
  }
}
