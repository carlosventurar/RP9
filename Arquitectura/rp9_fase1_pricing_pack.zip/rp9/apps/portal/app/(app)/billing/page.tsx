
export default function BillingPage(){
  return <div className="p-6">Billing – próximamente: consumo, facturas y upgrades.</div>
}
