
'use client';
import { useState } from 'react';
import { PlanCard } from '@/components/mkt/PlanCard';
import { ROIForm } from '@/components/mkt/ROIForm';

export default function PricingPage(){
  const [period,setPeriod]=useState<'monthly'|'yearly'>('monthly');
  const [addons,setAddons]=useState<string[]>([]);

  async function checkout(plan:'starter'|'pro'|'enterprise'){
    const r=await fetch('/.netlify/functions/billing-checkout',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({plan, period, addons})});
    const data=await r.json();
    if (data.url) window.location.href=data.url;
    else if (data.leadUrl) window.location.href=data.leadUrl;
  }

  const plans = [
    { key:'starter', name:'Starter', price: period==='monthly'?'49':'39', features:['1,000 ejecuciones','Hasta 2 editores','Email support']},
    { key:'pro', name:'Pro', price: period==='monthly'?'199':'159', features:['10,000 ejecuciones','Hasta 5 editores','Soporte prioritario']},
    { key:'enterprise', name:'Enterprise', price:'Custom', features:['Ilimitado','RBAC/SSO','SLA/Soporte 24/7']},
  ] as const;

  return (
    <div className="container mx-auto p-6 space-y-10">
      <header className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Precios RP9</h1>
        <div className="flex items-center gap-2 text-sm">
          <button className={period==='monthly'?'font-semibold':''} onClick={()=>setPeriod('monthly')}>Mensual</button>
          <span>·</span>
          <button className={period==='yearly'?'font-semibold':''} onClick={()=>setPeriod('yearly')}>Anual (-20%)</button>
        </div>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((p)=>(
          <PlanCard key={p.key} name={p.name} price={p.price} period={period} features={p.features as any} onSelect={()=>checkout(p.key as any)} />
        ))}
      </section>

      <section id="addons" className="space-y-2">
        <div className="text-lg font-semibold">Add-ons</div>
        <label className="flex items-center gap-2"><input type="checkbox" onChange={e=>setAddons(a=> e.target.checked?[...a,'exec_10k']:a.filter(x=>x!=='exec_10k'))}/> +10k ejecuciones</label>
        <label className="flex items-center gap-2"><input type="checkbox" onChange={e=>setAddons(a=> e.target.checked?[...a,'exec_50k']:a.filter(x=>x!=='exec_50k'))}/> +50k ejecuciones</label>
        <label className="flex items-center gap-2"><input type="checkbox" onChange={e=>setAddons(a=> e.target.checked?[...a,'exec_100k']:a.filter(x=>x!=='exec_100k'))}/> +100k ejecuciones</label>
      </section>

      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        <div className="rounded-2xl border p-6"><h2 className="text-xl font-semibold mb-3">Calculadora ROI</h2><ROIForm/></div>
        <div className="rounded-2xl border p-6"><h2 className="text-xl font-semibold mb-3">¿Por qué RP9?</h2><ul className="list-disc pl-5 space-y-2 text-slate-700"><li>Automatización lista para producción sobre n8n</li><li>Precios claros + metered por uso</li><li>Plantillas por vertical (CC y Finanzas)</li></ul></div>
      </section>
    </div>
  )
}
