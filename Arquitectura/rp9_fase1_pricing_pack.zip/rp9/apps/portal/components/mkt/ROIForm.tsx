
'use client';
import { useState } from 'react';
export function ROIForm(){
  const [ev,setEv]=useState(4000),[min,setMin]=useState(3),[cost,setCost]=useState(10);
  const savings=((ev*min)/60)*cost;
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-3 gap-3">
        <input type="number" value={ev} onChange={e=>setEv(+e.target.value)} className="input border rounded px-3 py-2" placeholder="Eventos/mes" />
        <input type="number" value={min} onChange={e=>setMin(+e.target.value)} className="input border rounded px-3 py-2" placeholder="Min ahorrados" />
        <input type="number" value={cost} onChange={e=>setCost(+e.target.value)} className="input border rounded px-3 py-2" placeholder="Costo/hora" />
      </div>
      <div className="text-2xl font-semibold">Ahorro estimado: ${savings.toFixed(0)}/mes</div>
      <a href="#checkout" className="inline-block rounded-xl px-4 py-2 bg-black text-white">Iniciar Piloto 30 días</a>
    </div>
  );
}
