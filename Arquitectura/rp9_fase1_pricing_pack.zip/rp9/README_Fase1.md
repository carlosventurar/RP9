
# RP9 – Fase 1: Oferta & Pricing

## Pasos rápidos
1) Crea BD en Supabase y ejecuta `infra/supabase/migrations/10_pricing.sql`.
2) Configura variables en `.env` (Stripe, Supabase, n8n).
3) Despliega Functions en Netlify (`apps/functions`).
4) Publica el portal (`apps/portal`) en Netlify.
5) Programa `usage-collector` y `enforcement` (Netlify Scheduled Functions).

## Notas
- Usa API Key de n8n con permisos de lectura de ejecuciones.
- Para Enterprise, `billing-checkout` devuelve un `leadUrl`/mailto para capturar oportunidad.
