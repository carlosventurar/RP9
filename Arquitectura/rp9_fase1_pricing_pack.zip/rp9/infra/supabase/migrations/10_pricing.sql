
create table if not exists tenants (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  plan text not null default 'starter',
  owner_user uuid not null,
  country text,
  metadata jsonb default '{}',
  created_at timestamptz default now()
);

create table if not exists plans (
  key text primary key,
  name text not null,
  price_id text,
  price_id_yearly text,
  limits jsonb not null
);

create table if not exists subscriptions (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid references tenants(id) on delete cascade,
  stripe_customer_id text,
  stripe_subscription_id text,
  status text,
  current_period_end timestamptz
);

create table if not exists usage_executions (
  id bigserial primary key,
  tenant_id uuid references tenants(id) on delete cascade,
  workflow_id text,
  execution_id text unique,
  status text,
  started_at timestamptz,
  stopped_at timestamptz,
  duration_ms bigint,
  created_at timestamptz default now()
);

create index on usage_executions(tenant_id, created_at desc);

create table if not exists feature_flags (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid references tenants(id) on delete cascade,
  key text not null,
  enabled boolean not null default false,
  scope text default 'tenant'
);
