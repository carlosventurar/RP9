Tests de Fase 1: mocks de Stripe y funciones programadas.
