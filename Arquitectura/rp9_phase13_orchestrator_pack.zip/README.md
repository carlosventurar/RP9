
# RP9 Orchestrator Pack (Fase 13)

## Quickstart
1) Copia `.env.example` → `.env` y rellena tokens.  
2) `docker compose up -d --build`  
3) Crea un tenant (compartido):  
```bash
curl -X POST http://localhost:8080/tenants  -H "Authorization: Bearer $ORCH_TOKEN"  -H "content-type: application/json"  -d '{"tenantId":"00000000-0000-0000-0000-000000000001","subdomain":"demo","plan":"starter","mode":"shared"}'
```

## Promoción a dedicado
Usa la function `promote-tenant` (Netlify) que invoca al orquestador.  
Recomendado: ventana corta (5–10 min), TTL DNS bajo.

## Backups
Nightly + semanal (ver `backups/`). Puedes ejecutar un backup on‑demand con `backup-now`.
