# RP9 – Fase 13: Orchestrator (Escalado & Multi‑tenancy)

Este paquete implementa el **orchestrator** (Node.js + TS + Fastify) y la integración con **Netlify Functions**, **Supabase**, **Stripe**, **Traefik** y **n8n** para un modelo **híbrido** (compartido → dedicado).

- **MD guía**: `RP9_Fase13_Escalado_Multitenancy.md`
- **SQL**: `infra/supabase/migrations/40_orchestrator.sql`
- **Servicio**: `orchestrator/` (Fastify + dockerode + pino + prom-client)
- **Puentes Netlify**: `functions/*.ts`
- **Monitoreo**: `prometheus/`, `grafana/dashboards/`
- **Compose**: `deploy/docker-compose.orchestrator.yml`

> Shared n8n (Railway): `https://primary-production-7f25.up.railway.app/`

## Quickstart

1. Crea el stack en Supabase ejecutando `40_orchestrator.sql`.
2. Configura `.env` (ver `orchestrator/.env.example`) y Traefik.
3. Arranca: `docker compose -f deploy/docker-compose.orchestrator.yml up -d`
4. Prueba `POST /tenants` con body: `{"name":"ACME","email":"ops@acme","subdomain":"acme","mode":"shared","plan":"starter"}`.
5. Desde el portal, usa `/.netlify/functions/orch-bridge` para invocar el orquestador.

## Playbooks
- **Promote** shared→dedicated: freeze 5–10m → clone DB → despliegue `-blue` → cutover → verify → unfreeze.
- **Blue/Green Upgrade**: desplegar `-green`, health OK → switch router → monitor → opcional cleanup `-blue`.
- **Backups/Restores**: diarios + semanales a S3; drill trimestral a sandbox.

