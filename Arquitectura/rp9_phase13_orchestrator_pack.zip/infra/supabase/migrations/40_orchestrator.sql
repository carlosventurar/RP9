
-- 40_orchestrator.sql — multi-tenancy & orchestrator state

create extension if not exists "uuid-ossp";

create table if not exists tenants (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  subdomain text unique not null,
  plan text not null default 'starter',
  status text not null default 'active', -- provisioning|active|suspended
  owner_user uuid,
  country text,
  stripe_customer_id text,
  stripe_subscription_id text,
  metadata jsonb default '{}'::jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists tenant_instances (
  id uuid primary key default uuid_generate_v4(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  mode text not null, -- shared|dedicated
  container_name text,
  db_name text,
  cpu_quota int,      -- percentage x10 (e.g. 100 = 1 core)
  memory_mb int,
  workers int default 1,
  region text default 'us-east',
  router_color text default 'blue', -- blue|green (para upgrades)
  status text not null default 'running', -- running|stopped|error
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists tenant_limits (
  tenant_id uuid primary key references tenants(id) on delete cascade,
  executions_month int,
  cpu_quota int,
  memory_mb int,
  workflows_limit int,
  concurrency int,
  enforcement jsonb default '{}'::jsonb, -- {soft:true, grace_hours:48}
  updated_at timestamptz default now()
);

create table if not exists backups (
  id uuid primary key default uuid_generate_v4(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  path text not null,
  size_mb numeric,
  status text not null default 'completed', -- running|completed|failed
  created_at timestamptz default now()
);

create table if not exists autoscale_events (
  id bigserial primary key,
  tenant_id uuid not null references tenants(id) on delete cascade,
  reason text not null, -- queue_wait_p95|executions_min|cpu|mem
  old jsonb,
  new jsonb,
  created_at timestamptz default now()
);

-- vistas útiles
create or replace view v_tenant_costs as
select
  t.id as tenant_id,
  t.subdomain,
  coalesce(l.cpu_quota,0) as cpu_quota,
  coalesce(l.memory_mb,0) as memory_mb,
  coalesce(l.executions_month,0) as executions_month
from tenants t
left join tenant_limits l on l.tenant_id = t.id;

-- índices
create index if not exists ix_tenant_instances_tenant on tenant_instances(tenant_id);
create index if not exists ix_backups_tenant on backups(tenant_id);
create index if not exists ix_autoscale_events_tenant on autoscale_events(tenant_id);

-- (Opcional) RLS básico
alter table tenants enable row level security;
alter table tenant_instances enable row level security;
alter table tenant_limits enable row level security;

-- Políticas ejemplo: owner_user puede ver su tenant
create policy tenants_owner on tenants
  using (owner_user is null or auth.uid() = owner_user);

create policy tenants_instances_owner on tenant_instances
  using (tenant_id in (select id from tenants where owner_user = auth.uid()));

create policy tenants_limits_owner on tenant_limits
  using (tenant_id in (select id from tenants where owner_user = auth.uid()));
