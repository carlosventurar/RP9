
-- 60_orchestrator.sql
create table if not exists tenant_instances (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  subdomain text not null,
  mode text not null check (mode in ('shared','dedicated')),
  plan text not null default 'starter',
  status text not null default 'provisioning',
  container_id text,
  db_name text,
  cpu_quota_mcpu int,      -- millicores
  mem_limit_mb int,
  workers int default 1,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists quotas (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  executions_limit int,
  concurrency_limit int,
  cpu_limit_mcpu int,
  mem_limit_mb int,
  workflows_limit int,
  webhooks_limit int,
  grace_until timestamptz,
  created_at timestamptz default now()
);

create table if not exists backups (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  started_at timestamptz default now(),
  finished_at timestamptz,
  size_mb numeric,
  storage_provider text default 's3',
  path text,
  status text default 'running', -- running|completed|failed
  meta jsonb default '{}'
);

create table if not exists autoscaling_events (
  id bigserial primary key,
  tenant_id uuid not null,
  ts timestamptz default now(),
  prev_workers int,
  new_workers int,
  reason text,
  metrics jsonb
);

create table if not exists enforcement_events (
  id bigserial primary key,
  tenant_id uuid not null,
  ts timestamptz default now(),
  metric text not null,
  threshold text not null,
  action text not null,   -- alert|grace|suspend|overage|upgrade
  meta jsonb
);

-- índices útiles
create index if not exists idx_tenant_instances_tenant on tenant_instances(tenant_id);
create index if not exists idx_backups_tenant on backups(tenant_id, started_at desc);
create index if not exists idx_as_events_tenant on autoscaling_events(tenant_id, ts desc);
create index if not exists idx_enf_events_tenant on enforcement_events(tenant_id, ts desc);
