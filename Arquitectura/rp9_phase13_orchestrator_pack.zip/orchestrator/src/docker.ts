import Docker from 'dockerode';

const docker = new Docker({ socketPath: '/var/run/docker.sock' });

export type N8nEnv = {
  subdomain: string;
  encryptionKey: string;
  jwtSecret?: string;
  dbUser: string;
  dbPass: string;
  dbName: string;
  baseDomain: string;
  cpuQuota?: number;
  memoryMb?: number;
  workers?: number;
};

export async function createN8nContainer(env: N8nEnv) {
  const name = `rp9_n8n_${env.subdomain}_blue`;
  const container = await docker.createContainer({
    Image: process.env.N8N_IMAGE || 'n8nio/n8n:latest',
    name,
    Env: [
      `N8N_HOST=${env.subdomain}.${env.baseDomain}`,
      'N8N_PORT=5678',
      'N8N_PROTOCOL=https',
      `WEBHOOK_URL=https://${env.subdomain}.${env.baseDomain}/`,
      `N8N_EDITOR_BASE_URL=https://${env.subdomain}.${env.baseDomain}/`,
      `N8N_ENCRYPTION_KEY=${env.encryptionKey}`,
      'DB_TYPE=postgresdb',
      'DB_POSTGRESDB_HOST=postgres',
      'DB_POSTGRESDB_PORT=5432',
      `DB_POSTGRESDB_DATABASE=${env.dbName}`,
      `DB_POSTGRESDB_USER=${env.dbUser}`,
      `DB_POSTGRESDB_PASSWORD=${env.dbPass}`,
      'N8N_EXECUTIONS_MODE=queue',
      'N8N_QUEUE_BULL_REDIS_HOST=redis',
      'N8N_DIAGNOSTICS_ENABLED=false',
      'N8N_PERSONALIZATION_ENABLED=false',
      'N8N_METRICS=true',
      'N8N_DEFAULT_LOCALE=es'
    ],
    Labels: {
      'traefik.enable': 'true',
      [`traefik.http.routers.n8n-${env.subdomain}.rule`]: `Host(\`${env.subdomain}.${env.baseDomain}\`)`,
      [`traefik.http.routers.n8n-${env.subdomain}.entrypoints`]: 'websecure',
      [`traefik.http.routers.n8n-${env.subdomain}.tls.certresolver`]: 'letsencrypt',
      [`traefik.http.services.n8n-${env.subdomain}.loadbalancer.server.port`]: '5678',
      'rp9.tenant.subdomain': env.subdomain
    },
    HostConfig: {
      RestartPolicy: { Name: 'unless-stopped' },
      Memory: env.memoryMb ? env.memoryMb * 1024 * 1024 : undefined,
      CpuQuota: env.cpuQuota ? env.cpuQuota * 1000 : undefined,
      NetworkMode: 'rp9_network'
    }
  });
  await container.start();
  return container.id;
}

export async function removeContainerByName(name: string) {
  try {
    const c = docker.getContainer(name);
    await c.stop({ t: 20 });
    await c.remove({ force: true });
    return true;
  } catch (e) {
    return false;
  }
}
