
// orchestrator/src/index.ts
import Fastify from 'fastify'
import Docker from 'dockerode'
import { execSync } from 'node:child_process'

const fastify = Fastify({ logger: true })
const docker = new Docker({ socketPath: '/var/run/docker.sock' })

const ORCH_TOKEN = process.env.ORCH_TOKEN!
const BASE_DOMAIN = process.env.BASE_DOMAIN || 'rp9.io'
const DB_PASSWORD = process.env.DB_PASSWORD || 'change_me'

fastify.addHook('onRequest', async (req, reply) => {
  const auth = req.headers.authorization || ''
  if (!auth.startsWith('Bearer ') || auth.slice(7) !== ORCH_TOKEN) {
    reply.code(401).send({ error: 'unauthorized' })
  }
})

fastify.post('/tenants', async (req, reply) => {
  // body: { tenantId, subdomain, plan, mode: 'shared'|'dedicated' }
  const body = req.body as any
  const sub = body.subdomain
  const dbName = `n8n_${sub}`

  // 1) crear DB para el tenant
  execSync(`psql ${process.env.DATABASE_URL} -c "create database ${dbName};"`, { stdio: 'inherit' })

  // 2) crear contenedor n8n
  const envs = [
    `N8N_HOST=${sub}.${BASE_DOMAIN}`,
    'N8N_PORT=5678',
    'N8N_PROTOCOL=https',
    `WEBHOOK_URL=https://${sub}.${BASE_DOMAIN}/`,
    `N8N_EDITOR_BASE_URL=https://${sub}.${BASE_DOMAIN}/`,
    `DB_TYPE=postgresdb`,
    `DB_POSTGRESDB_HOST=postgres`,
    `DB_POSTGRESDB_PORT=5432`,
    `DB_POSTGRESDB_DATABASE=${dbName}`,
    `DB_POSTGRESDB_USER=rp9`,
    `DB_POSTGRESDB_PASSWORD=${DB_PASSWORD}`,
    'N8N_EXECUTIONS_MODE=queue',
    'N8N_QUEUE_BULL_REDIS_HOST=redis',
    'N8N_DIAGNOSTICS_ENABLED=false',
    'N8N_PERSONALIZATION_ENABLED=false',
    'N8N_METRICS=true',
    'N8N_DEFAULT_LOCALE=es'
  ]

  const container = await docker.createContainer({
    Image: 'n8nio/n8n:latest',
    name: `rp9_n8n_${sub}`,
    Env: envs,
    HostConfig: {
      NetworkMode: 'rp9_network',
      RestartPolicy: { Name: 'unless-stopped' }
    },
    Labels: {
      'traefik.enable': 'true',
      [`traefik.http.routers.n8n-${sub}.rule`]: `Host(\`${sub}.${BASE_DOMAIN}\`)`,
      [`traefik.http.routers.n8n-${sub}.entrypoints`]: 'websecure',
      [`traefik.http.routers.n8n-${sub}.tls.certresolver`]: 'letsencrypt',
      [`traefik.http.services.n8n-${sub}.loadbalancer.server.port`]: '5678'
    }
  })
  await container.start()

  reply.send({ ok: true, containerId: container.id })
})

fastify.post('/tenants/:id/scale', async (req, reply) => {
  // body: { subdomain, workers, cpuQuotaMcpu, memMb }
  const body = (req as any).body
  const sub = body.subdomain
  // Example: scale workers by launching worker containers with same env + role=worker
  reply.send({ ok: true, message: 'Scale command accepted (skeleton)' })
})

fastify.post('/tenants/:id/promote', async (req, reply) => {
  // skeleton: stop shared, clone DB, start dedicated with more resources
  reply.send({ ok: true, message: 'Promote command accepted (skeleton)' })
})

fastify.post('/tenants/:id/backup', async (req, reply) => {
  const body = (req as any).body
  const sub = body.subdomain
  const dbName = `n8n_${sub}`
  const stamp = new Date().toISOString().replace(/[:.]/g, '-')
  const file = `/backups/${sub}/backup-${stamp}.sql`
  execSync(f'pg_dump -U rp9 -h postgres {dbName} > {file}', { stdio: 'inherit', shell: '/bin/bash' })
  reply.send({ ok: true, file })
})

fastify.post('/enforcement/run', async (_req, reply) => {
  // pull usage from Supabase/Stripe, compare to quotas, take actions (alert/grace/suspend)
  reply.send({ ok: true })
})

const port = Number(process.env.ORCH_PORT || 8080)
fastify.listen({ port, host: '0.0.0.0' })
  .catch(err => { fastify.log.error(err); process.exit(1) })
