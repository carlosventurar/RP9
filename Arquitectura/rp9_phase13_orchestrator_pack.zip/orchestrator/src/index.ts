import Fastify from 'fastify';
import cors from '@fastify/cors';
import rateLimit from '@fastify/rate-limit';
import pino from 'pino';
import { tenantsRoutes } from './routes/tenants';
import { registerMetrics, metricsRoute } from './metrics';

const app = Fastify({ logger: pino({ level: 'info' }) });

app.register(cors, { origin: true });
app.register(rateLimit, { max: 300, timeWindow: '1 minute' });

registerMetrics(app);
app.get('/healthz', async () => ({ ok: true }));
app.get('/metrics', metricsRoute);
app.register(tenantsRoutes, { prefix: '/tenants' });

const port = Number(process.env.PORT || 8080);
app.listen({ port, host: '0.0.0.0' }).then(() => {
  app.log.info(`orchestrator listening on :${port}`);
}).catch((err) => {
  app.log.error(err, 'failed to start');
  process.exit(1);
});
