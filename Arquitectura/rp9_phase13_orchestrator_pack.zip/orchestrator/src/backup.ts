import { exec } from 'child_process';
import { promisify } from 'util';
const sh = promisify(exec);

export async function backupTenantDb(dbName: string, outFile: string, dbUser='rp9', dbHost='postgres') {
  const cmd = `PGPASSWORD=${process.env.DB_PASSWORD} pg_dump -h ${dbHost} -U ${dbUser} ${dbName} > ${outFile}`;
  await sh(cmd);
  return outFile;
}
