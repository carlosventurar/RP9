export type CreateTenantInput = {
  name: string;
  email: string;
  subdomain: string;
  mode: 'shared'|'dedicated';
  plan: 'starter'|'pro'|'enterprise';
  region?: string;
};
