import crypto from 'crypto';
export function verifySignature({ body, secret, timestamp, signature }:{body:string; secret:string; timestamp:string; signature:string}){
  const payload = `${timestamp}\n${body}`;
  const mac = crypto.createHmac('sha256', secret).update(payload).digest('hex');
  const safe = crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(mac));
  const skew = Math.abs(Date.now() - Number(timestamp)) / 1000 <= 300;
  return safe && skew;
}
