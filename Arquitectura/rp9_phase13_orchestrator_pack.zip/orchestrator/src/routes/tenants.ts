import { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { createN8nContainer } from '../docker';

const createTenantSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  subdomain: z.string().regex(/^[a-z0-9-]{2,32}$/),
  mode: z.enum(['shared','dedicated']),
  plan: z.enum(['starter','pro','enterprise']),
  region: z.string().optional()
});

export async function tenantsRoutes(app: FastifyInstance) {
  app.post('/', async (req, reply) => {
    const parsed = createTenantSchema.parse(req.body);
    app.log.info({ op: 'tenant.create', subdomain: parsed.subdomain }, 'creating tenant');
    if (parsed.mode === 'dedicated') {
      const id = await createN8nContainer({
        subdomain: parsed.subdomain,
        encryptionKey: require('crypto').randomBytes(32).toString('hex'),
        dbUser: 'rp9',
        dbPass: process.env.DB_PASSWORD || 'changeme',
        dbName: `n8n_${parsed.subdomain}`,
        baseDomain: process.env.TRAEFIK_DOMAIN || 'rp9.io',
        cpuQuota: 100,
        memoryMb: 2048
      });
      return reply.code(201).send({ tenant_id: id, loginUrl: `https://${parsed.subdomain}.${process.env.TRAEFIK_DOMAIN||'rp9.io'}` });
    } else {
      // shared: solo registrar tenant; usará Railway n8n + Projects/RBAC
      return reply.code(201).send({ tenant_id: parsed.subdomain, loginUrl: `https://${process.env.TRAEFIK_DOMAIN||'rp9.io'}/app` });
    }
  });

  app.post('/:id/scale', async (req, reply) => {
    // stub: update limits; real implementation would docker.updateContainer resources
    return reply.send({ ok: true });
  });

  app.post('/:id/promote', async (req, reply) => {
    // stub: perform migration shared->dedicated following playbook
    return reply.send({ ok: true, scheduled: true });
  });

  app.post('/:id/backup', async (req, reply) => {
    // stub: call backup module and upload to S3
    return reply.send({ ok: true, path: 's3://bucket/tenant/backup.sql' });
  });
}
