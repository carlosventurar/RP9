import type { FastifyInstance, FastifyReply } from 'fastify';
import client from 'prom-client';

const registry = new client.Registry();
const cpu = new client.Gauge({ name: 'rp9_tenant_cpu_percent', help: 'CPU %', labelNames: ['tenant'] });
const mem = new client.Gauge({ name: 'rp9_tenant_mem_bytes', help: 'Mem bytes', labelNames: ['tenant'] });
const q95 = new client.Gauge({ name: 'rp9_tenant_queue_wait_p95_seconds', help: 'Queue wait p95', labelNames: ['tenant'] });
const execMin = new client.Gauge({ name: 'rp9_tenant_executions_min', help: 'Executions per minute', labelNames: ['tenant'] });

registry.registerMetric(cpu);
registry.registerMetric(mem);
registry.registerMetric(q95);
registry.registerMetric(execMin);

export function registerMetrics(app: FastifyInstance) {
  app.decorate('metrics', { cpu, mem, q95, execMin, registry });
}

export async function metricsRoute(req: any, reply: FastifyReply) {
  reply.header('Content-Type', registry.contentType);
  reply.send(await registry.metrics());
}
