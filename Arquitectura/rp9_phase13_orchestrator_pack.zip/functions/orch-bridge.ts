import type { Handler } from '@netlify/functions'
import crypto from 'crypto'

function sign(body:string, secret:string){
  const ts = Date.now().toString()
  const mac = crypto.createHmac('sha256', secret).update(`${ts}\n${body}`).digest('hex')
  return { ts, sig: mac }
}

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' }
  const ORCH_URL = process.env.ORCH_URL || 'https://api.rp9.io/internal/orchestrator'
  const HMAC_SECRET = process.env.HMAC_SECRET || 'changeme'
  const body = event.body || '{}'
  const { ts, sig } = sign(body, HMAC_SECRET)
  const r = await fetch(`${ORCH_URL}/tenants`, {
    method: 'POST',
    headers: { 'content-type':'application/json', 'x-rp9-timestamp': ts, 'x-rp9-signature': sig },
    body
  })
  return { statusCode: r.status, body: await r.text() }
}
