
// apps/functions/promote-tenant.ts
import type { Handler } from '@netlify/functions'

export const handler: Handler = async (event) => {
  const { tenantId, subdomain } = JSON.parse(event.body||'{}')
  if (!tenantId || !subdomain) return { statusCode: 400, body: 'missing tenantId/subdomain' }
  const r = await fetch(`${process.env.ORCH_URL}/tenants/${tenantId}/promote`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${process.env.ORCH_TOKEN}`, 'content-type':'application/json' },
    body: JSON.stringify({ subdomain })
  })
  const data = await r.json().catch(()=>({}))
  return { statusCode: 200, body: JSON.stringify({ ok: true, data }) }
}
