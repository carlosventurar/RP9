
// apps/functions/enforcement-orch.ts
import type { Handler } from '@netlify/functions'

export const handler: Handler = async () => {
  const url = `${process.env.ORCH_URL}/enforcement/run`
  const r = await fetch(url, { method: 'POST', headers: { Authorization: `Bearer ${process.env.ORCH_TOKEN}` } })
  const data = await r.json().catch(()=>({}))
  return { statusCode: 200, body: JSON.stringify({ ok: true, data }) }
}
