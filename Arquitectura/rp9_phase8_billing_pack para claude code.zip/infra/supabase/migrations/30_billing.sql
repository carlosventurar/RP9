create table if not exists plans (
  key text primary key,
  name text not null,
  price_id text,
  price_id_yearly text,
  limits jsonb not null
);
create table if not exists subscriptions (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  stripe_customer_id text,
  stripe_subscription_id text,
  plan_key text references plans(key),
  status text,
  currency text default 'usd',
  current_period_start timestamptz,
  current_period_end timestamptz,
  metadata jsonb default '{}',
  created_at timestamptz default now()
);
create table if not exists usage_executions (
  id bigserial primary key,
  tenant_id uuid not null,
  workflow_id text not null,
  execution_id text unique not null,
  status text not null,
  started_at timestamptz,
  stopped_at timestamptz,
  duration_ms bigint,
  hash_sha256 text,
  created_at timestamptz default now()
);
create view if not exists v_usage_daily as
select tenant_id, workflow_id, date_trunc('day', created_at)::date as day,
       count(*) as executions, sum(duration_ms) as duration_ms
from usage_executions group by 1,2,3;
