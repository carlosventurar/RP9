# RP9 — Fase 8 Billing Pack
Incluye funciones Netlify (checkout, webhook, usage, dunning), SQL Supabase y página `/billing`.
Métrica: ejecuciones (success+error). Límite mixto por plan. Usa Stripe Portal para gestión.
