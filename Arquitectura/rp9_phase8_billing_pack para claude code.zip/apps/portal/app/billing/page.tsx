'use client'
export default function BillingPage(){
  return (<div className="space-y-4">
    <h1 className="text-2xl font-semibold">Facturación & Consumo</h1>
    <p>Resumen de consumo por workflow/día y acceso al Stripe Customer Portal.</p>
  </div>)
}
