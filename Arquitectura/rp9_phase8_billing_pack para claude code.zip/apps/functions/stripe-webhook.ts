import { Handler } from '@netlify/functions'
import Stripe from 'stripe'
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, { apiVersion: '2024-06-20' })
export const handler: Handler = async (event) => {
  if (event.httpMethod!=='POST') return {statusCode:405, body:'Method Not Allowed'}
  try {
    const wh = stripe.webhooks.constructEvent(event.body as string, event.headers['stripe-signature'] as string, process.env.STRIPE_WEBHOOK_SECRET as string)
    switch(wh.type){
      case 'checkout.session.completed':
      case 'invoice.paid':
      case 'invoice.payment_failed':
      case 'customer.subscription.updated':
      case 'customer.subscription.deleted':
        // TODO: persistir en Supabase
        break;
    }
    return {statusCode:200, body: JSON.stringify({ ok:true })}
  } catch(e:any){
    return {statusCode:400, body:`Webhook error: ${e.message}`}
  }
}
