import { Handler } from '@netlify/functions'
import Stripe from 'stripe'
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, { apiVersion: '2024-06-20' })
export const handler: Handler = async (event) => {
  if (event.httpMethod!=='POST') return {statusCode:405, body:'Method Not Allowed'}
  const { planKey='starter', periodicity='monthly', tenantId, successUrl, cancelUrl } = JSON.parse(event.body||'{}')
  const price = periodicity==='yearly' ? (planKey==='pro'?process.env.STRIPE_PRICE_PRO_YEARLY:process.env.STRIPE_PRICE_STARTER_YEARLY)
                                       : (planKey==='pro'?process.env.STRIPE_PRICE_PRO:process.env.STRIPE_PRICE_STARTER)
  const session = await stripe.checkout.sessions.create({
    mode:'subscription',
    line_items:[{ price: price as string, quantity:1 }],
    metadata:{ tenantId, planKey, periodicity },
    success_url: successUrl || 'https://app.rp9.io/billing?success=1',
    cancel_url: cancelUrl || 'https://app.rp9.io/billing?canceled=1'
  })
  return {statusCode:200, body: JSON.stringify({ checkoutUrl: session.url })}
}
