import { Handler } from '@netlify/functions'
import { createClient } from '@supabase/supabase-js'
import z from 'zod'

const schema = z.object({
  tenant_id: z.string().uuid(),
  type: z.enum(['msa','dpa','sla']),
  version: z.string().default('2025-01'),
  lang: z.enum(['es','en','es-en']).default('es-en'),
  vars: z.record(z.any()).default({})
})

export const handler: Handler = async (event) => {
  try {
    const input = schema.parse(JSON.parse(event.body||'{}'))
    const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
    const { data, error } = await supabase.from('contracts').insert({
      tenant_id: input.tenant_id,
      type: input.type,
      version: input.version,
      status: 'draft'
    }).select().single()
    if (error) throw error
    return { statusCode: 200, body: JSON.stringify({ ok:true, contract_id: data.id }) }
  } catch (e:any) {
    return { statusCode: 400, body: JSON.stringify({ ok:false, error: e.message }) }
  }
}
