import { Handler } from '@netlify/functions'
import { createClient } from '@supabase/supabase-js'

function tier(uptime:number){
  if (uptime >= 99.9) return 0
  if (uptime >= 99.0) return 5
  if (uptime >= 98.0) return 10
  return 20
}

export const handler: Handler = async () => {
  const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
  const now = new Date()
  const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1, 0,0,0))
  const end = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth()+1, 0, 23,59,59))
  const { data: rows, error } = await supabase.from('sla_metrics')
    .select('*').gte('period_start', start.toISOString()).lte('period_end', end.toISOString())
  if (error) return { statusCode: 500, body: JSON.stringify({ ok:false, error: error.message }) }
  let created = 0
  for (const r of rows||[]) {
    const credit = tier(Number(r.uptime_percent))
    if (credit>0){
      await supabase.from('sla_credits').insert({
        tenant_id: r.tenant_id, period_start: r.period_start, period_end: r.period_end,
        credit_percent: credit, reason: `Uptime ${r.uptime_percent}%`
      })
      created++
    }
  }
  return { statusCode: 200, body: JSON.stringify({ ok:true, created }) }
}
