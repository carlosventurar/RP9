import { Handler } from '@netlify/functions'
import { createClient } from '@supabase/supabase-js'

export const handler: Handler = async (event) => {
  try {
    const { contract_id, signer_name, signer_email } = JSON.parse(event.body||'{}')
    const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
    const { error } = await supabase.from('contracts').update({
      status: 'signed', signed_at: new Date().toISOString(),
      signer_name, signer_email
    }).eq('id', contract_id)
    if (error) throw error
    return { statusCode: 200, body: JSON.stringify({ ok:true }) }
  } catch (e:any) {
    return { statusCode: 400, body: JSON.stringify({ ok:false, error: e.message }) }
  }
}
