import { Handler } from '@netlify/functions'
import { createClient } from '@supabase/supabase-js'
export const handler: Handler = async (event) => {
  try {
    const { id, rca_url } = JSON.parse(event.body||'{}')
    const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
    const { error } = await supabase.from('incidents').update({ rca_url }).eq('id', id)
    if (error) throw error
    return { statusCode: 200, body: JSON.stringify({ ok:true }) }
  } catch (e:any) {
    return { statusCode: 400, body: JSON.stringify({ ok:false, error: e.message }) }
  }
}
