import { Handler } from '@netlify/functions'
import { createClient } from '@supabase/supabase-js'
import z from 'zod'

const schema = z.object({ action: z.enum(['list','add','notify']), payload: z.any().optional() })

export const handler: Handler = async (event) => {
  try {
    const input = schema.parse(JSON.parse(event.body||'{}'))
    const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
    if (input.action === 'notify') {
      const { data: subs } = await supabase.from('subprocessor_subscriptions').select('email')
      return { statusCode: 200, body: JSON.stringify({ ok:true, notified: (subs||[]).length }) }
    }
    return { statusCode: 200, body: JSON.stringify({ ok:true }) }
  } catch (e:any) {
    return { statusCode: 400, body: JSON.stringify({ ok:false, error: e.message }) }
  }
}
