import { Handler } from '@netlify/functions'
import { createClient } from '@supabase/supabase-js'
import z from 'zod'

const schema = z.object({
  type: z.enum(['tos','privacy']),
  version: z.string(),
  tenant_id: z.string().uuid(),
  user_id: z.string().uuid(),
  lang: z.enum(['es','en','es-en'])
})

export const handler: Handler = async (event) => {
  try {
    const input = schema.parse(JSON.parse(event.body||'{}'))
    const ip = event.headers['x-forwarded-for'] || ''
    const ua = event.headers['user-agent'] || ''
    const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
    const { error } = await supabase.from('legal_acceptances').insert({
      ...input, ip, user_agent: ua
    })
    if (error) throw error
    return { statusCode: 200, body: JSON.stringify({ ok:true }) }
  } catch (e:any) {
    return { statusCode: 400, body: JSON.stringify({ ok:false, error: e.message }) }
  }
}
