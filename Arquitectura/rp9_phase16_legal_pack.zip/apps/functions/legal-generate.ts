import { Handler } from '@netlify/functions'
import Handlebars from 'handlebars'
// TIP: para PDF puedes usar html-pdf-node en build step o un microservicio render.
const templates: Record<string,string> = {} // cargar desde /templates con bundler

export const handler: Handler = async (event) => {
  try {
    const body = JSON.parse(event.body||'{}')
    const { template='msa_es_en', vars={} } = body
    const md = (templates[template]||'') 
    const compiled = Handlebars.compile(md)(vars)
    // retornar MD/HTML (PDF opcional)
    return { statusCode: 200, body: JSON.stringify({ ok:true, content: compiled }) }
  } catch (e:any) {
    return { statusCode: 500, body: JSON.stringify({ ok:false, error: e.message }) }
  }
}
