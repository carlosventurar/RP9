-- 30_legal.sql — Fase 16 Legal & Contratos
create extension if not exists pgcrypto;

create table if not exists legal_documents (
  id uuid primary key default gen_random_uuid(),
  type text not null,
  locale text not null,
  version text not null,
  title text not null,
  url text,
  requires_signature boolean default false,
  content_md text,
  created_at timestamptz default now()
);

create unique index if not exists idx_legal_documents_key on legal_documents(type, locale, version);

create table if not exists legal_acceptances (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  user_id uuid not null,
  type text not null,
  version text not null,
  lang text not null,
  ip inet,
  user_agent text,
  accepted_at timestamptz default now()
);

create table if not exists contracts (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  type text not null,
  version text not null,
  status text not null default 'draft',
  file_url text,
  signed_at timestamptz,
  signer_name text,
  signer_email text,
  created_at timestamptz default now()
);

create table if not exists subprocessors (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  purpose text not null,
  data_categories text[] default '{operational,billing}',
  region text,
  dpa_url text,
  status text default 'active',
  added_at timestamptz default now(),
  removed_at timestamptz
);

create table if not exists subprocessor_subscriptions (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid,
  email text not null,
  created_at timestamptz default now()
);

create table if not exists incidents (
  id uuid primary key default gen_random_uuid(),
  severity text not null,
  opened_at timestamptz not null default now(),
  closed_at timestamptz,
  title text,
  description text,
  rca_url text
);

create table if not exists maintenances (
  id uuid primary key default gen_random_uuid(),
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  description text
);

create table if not exists sla_metrics (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  period_start date not null,
  period_end date not null,
  uptime_percent numeric(5,3) not null,
  created_at timestamptz default now()
);

create unique index if not exists idx_sla_metrics_tenant_period on sla_metrics(tenant_id, period_start, period_end);

create table if not exists sla_credits (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  period_start date not null,
  period_end date not null,
  credit_percent numeric(5,2) not null,
  reason text,
  created_at timestamptz default now()
);

create table if not exists retention_policies (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid,
  country text,
  logs_days int default 30,
  executions_days int default 30,
  evidence_years int default 5,
  created_at timestamptz default now()
);

-- RLS (placeholder; ajusta a tu modelo de auth)
alter table legal_acceptances enable row level security;
alter table contracts enable row level security;
alter table sla_metrics enable row level security;
alter table sla_credits enable row level security;
