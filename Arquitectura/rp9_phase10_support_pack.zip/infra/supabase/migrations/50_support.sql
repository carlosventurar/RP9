
create table if not exists support_tickets (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  tenant_id uuid,
  crm text not null default 'hubspot',
  crm_ticket_id text,
  severity text not null,
  status text not null default 'open',
  frt_minutes int,
  restored_at timestamptz,
  subject text,
  requester_email text,
  meta jsonb default '{}'
);
create index if not exists idx_support_tenant on support_tickets(tenant_id, created_at desc);

create table if not exists sla_breaches (
  id bigserial primary key,
  created_at timestamptz default now(),
  ticket_id uuid references support_tickets(id) on delete cascade,
  type text not null,
  target_minutes int not null,
  actual_minutes int not null,
  severity text not null
);

create table if not exists csat_responses (
  id bigserial primary key,
  created_at timestamptz default now(),
  ticket_id uuid references support_tickets(id) on delete cascade,
  score int check (score between 1 and 5),
  comment text,
  channel text default 'email'
);

create table if not exists kcs_articles (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  slug text unique not null,
  title text not null,
  mdx text not null,
  views int default 0,
  helpful_yes int default 0,
  helpful_no int default 0
);
