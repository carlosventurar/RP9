-- Soporte & CS core
create table if not exists support_plans (
  key text primary key,               -- starter|pro|enterprise
  channels jsonb not null,            -- ["email","chat","slack"]
  frt_minutes int not null,           -- objetivo de 1ª respuesta (plan baseline)
  created_at timestamptz default now()
);

create table if not exists sla_matrix (
  id uuid primary key default gen_random_uuid(),
  plan_key text references support_plans(key) on delete cascade,
  severity text not null,             -- P1|P2|P3
  frt_minutes int not null,
  restore_minutes int not null,
  created_at timestamptz default now()
);

create table if not exists tickets (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  subject text not null,
  description text,
  severity text not null,             -- P1|P2|P3
  channel text not null,              -- email|chat|slack
  status text not null default 'open',-- open|in_progress|waiting|resolved|closed
  assignee text,
  hubspot_ticket_id text,             -- id externo
  created_by uuid,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index if not exists idx_tickets_tenant on tickets(tenant_id, created_at desc);

create table if not exists ticket_events (
  id bigserial primary key,
  ticket_id uuid references tickets(id) on delete cascade,
  at timestamptz default now(),
  type text not null,                 -- status_change|note|assignment
  meta jsonb
);

create table if not exists incidents (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  title text not null,
  severity text not null,             -- P1|P2|P3
  status text not null default 'investigating', -- investigating|identified|monitoring|resolved
  impact text,
  eta timestamptz,
  status_provider_id text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists incident_updates (
  id bigserial primary key,
  incident_id uuid references incidents(id) on delete cascade,
  at timestamptz default now(),
  status text not null,
  message text not null
);

create table if not exists rca_docs (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  incident_id uuid references incidents(id) on delete set null,
  title text,
  md_path text,                       -- Storage key del MD/PDF
  owner uuid,
  due_date timestamptz,
  created_at timestamptz default now()
);

create table if not exists kb_articles (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid,                     -- null = público
  slug text unique,
  title text,
  tags text[] default '{}',
  mdx_path text not null,
  created_at timestamptz default now()
);

create table if not exists kb_feedback (
  id bigserial primary key,
  article_id uuid references kb_articles(id) on delete cascade,
  rating int check (rating between 1 and 5),
  comment text,
  created_at timestamptz default now()
);

create table if not exists cs_health_scores (
  id bigserial primary key,
  tenant_id uuid not null,
  score int not null,                 -- 0-100
  breakdown jsonb not null,           -- {usage:.., success:.., incidents:.., nps:..}
  created_at timestamptz default now()
);

create table if not exists qbrs (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  scheduled_for timestamptz not null,
  notes text,
  created_at timestamptz default now()
);

create table if not exists renewals (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  renew_on date not null,
  status text default 'pending',      -- pending|reminded|renewed|churned
  created_at timestamptz default now()
);

create table if not exists feature_requests (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid,
  title text not null,
  description text,
  votes int default 0,
  status text default 'new',          -- new|planned|in_progress|done
  impact text,                        -- texto libre
  arr_impact numeric,                 -- estimado
  created_at timestamptz default now()
);

-- RLS (ejemplo mínimo; ajustar a tu política)
alter table tickets enable row level security;
create policy tickets_by_tenant on tickets
  using (tenant_id::text = current_setting('request.jwt.claims', true)::jsonb->>'tenant_id');

alter table incidents enable row level security;
create policy incidents_by_tenant on incidents
  using (tenant_id::text = current_setting('request.jwt.claims', true)::jsonb->>'tenant_id');

alter table cs_health_scores enable row level security;
create policy health_by_tenant on cs_health_scores
  using (tenant_id::text = current_setting('request.jwt.claims', true)::jsonb->>'tenant_id');