import { Handler } from '@netlify/functions'
const SB = { url: process.env.SUPABASE_URL!, key: process.env.SUPABASE_SERVICE_ROLE_KEY! }
export const handler: Handler = async (event) => {
  try {
    if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' }
    const { ticket_id, score, comment, channel='email' } = JSON.parse(event.body||'{}')
    await fetch(`${SB.url}/rest/v1/csat_responses`, { method:'POST', headers:{ 'apikey':SB.key, 'Authorization':`Bearer ${SB.key}`, 'content-type':'application/json' }, body: JSON.stringify({ ticket_id, score, comment, channel }) })
    return { statusCode: 200, body: JSON.stringify({ ok:true }) }
  } catch (e:any) { return { statusCode: 500, body: JSON.stringify({ error: e.message }) } }
}
