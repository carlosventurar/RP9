import { Handler } from '@netlify/functions'
const SB = { url: process.env.SUPABASE_URL!, key: process.env.SUPABASE_SERVICE_ROLE_KEY! }
export const handler: Handler = async (event) => {
  try {
    if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' }
    const { crm_ticket_id, status, restored_at } = JSON.parse(event.body||'{}')
    const res = await fetch(`${SB.url}/rest/v1/support_tickets?crm_ticket_id=eq.${crm_ticket_id}`, { headers:{ 'apikey':SB.key, 'Authorization':`Bearer ${SB.key}`, 'content-type':'application/json' } })
    const rows = await res.json()
    if (!rows.length) return { statusCode: 404, body: 'Ticket not found' }
    const id = rows[0].id
    await fetch(`${SB.url}/rest/v1/support_tickets?id=eq.${id}`, { method:'PATCH', headers:{ 'apikey':SB.key, 'Authorization':`Bearer ${SB.key}`, 'content-type':'application/json' }, body: JSON.stringify({ status, restored_at }) })
    return { statusCode: 200, body: JSON.stringify({ ok:true }) }
  } catch (e:any) { return { statusCode: 500, body: JSON.stringify({ error: e.message }) } }
}
