import { Handler } from '@netlify/functions'
import crypto from 'crypto'
const SB = { url: process.env.SUPABASE_URL!, key: process.env.SUPABASE_SERVICE_ROLE_KEY! }
const CRM_TOKEN = process.env.HUBSPOT_TOKEN!
export const handler: Handler = async (event) => {
  try {
    if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' }
    const sig = event.headers['x-rp9-signature']||''
    const h = crypto.createHmac('sha256', process.env.WEBHOOK_HMAC_SECRET||'').update(event.body||'').digest('hex')
    if (sig !== h) return { statusCode: 401, body: 'Bad signature' }
    const { tenant_id, subject, requester_email, severity='P3', meta={} } = JSON.parse(event.body||'{}')
    const hs = await fetch('https://api.hubapi.com/crm/v3/objects/tickets', {
      method:'POST',
      headers:{ 'authorization':`Bearer ${CRM_TOKEN}`, 'content-type':'application/json' },
      body: JSON.stringify({ properties: { subject, hs_pipeline:'0', hs_pipeline_stage:'1', content: JSON.stringify(meta), source_type:'RP9' } })
    }).then(r=>r.json())
    await fetch(`${SB.url}/rest/v1/support_tickets`, { method:'POST', headers:{ 'apikey':SB.key, 'Authorization':`Bearer ${SB.key}`, 'content-type':'application/json' }, body: JSON.stringify({ tenant_id, crm:'hubspot', crm_ticket_id: hs.id, severity, status:'open', subject, requester_email, meta }) })
    return { statusCode: 200, body: JSON.stringify({ ok:true, id: hs.id }) }
  } catch (e:any) { return { statusCode: 500, body: JSON.stringify({ error: e.message }) } }
}
