import { Handler } from '@netlify/functions'
const SB = { url: process.env.SUPABASE_URL!, key: process.env.SUPABASE_SERVICE_ROLE_KEY! }
const PLAN_TARGETS:any = { P1:{FRT:60, RESTORE:120}, P2:{FRT:240, RESTORE:480}, P3:{FRT:480, RESTORE:2880} }
export const handler: Handler = async () => {
  try {
    const r = await fetch(`${SB.url}/rest/v1/support_tickets?select=*`, { headers:{ 'apikey':SB.key, 'Authorization':`Bearer ${SB.key}` } })
    const rows = await r.json()
    let breaches = 0
    for (const t of rows) {
      const target = PLAN_TARGETS[t.severity] || PLAN_TARGETS.P3
      if (t.frt_minutes && t.frt_minutes > target.FRT) {
        breaches++
        await fetch(`${SB.url}/rest/v1/sla_breaches`, { method:'POST', headers:{ 'apikey':SB.key, 'Authorization':`Bearer ${SB.key}`, 'content-type':'application/json' }, body: JSON.stringify({ ticket_id: t.id, type:'FRT', target_minutes: target.FRT, actual_minutes: t.frt_minutes, severity: t.severity }) })
      }
      if (t.restored_at) {
        const dur = Math.floor((new Date(t.restored_at).getTime() - new Date(t.created_at).getTime())/60000)
        if (dur > target.RESTORE) {
          breaches++
          await fetch(`${SB.url}/rest/v1/sla_breaches`, { method:'POST', headers:{ 'apikey':SB.key, 'Authorization':`Bearer ${SB.key}`, 'content-type':'application/json' }, body: JSON.stringify({ ticket_id: t.id, type:'RESTORE', target_minutes: target.RESTORE, actual_minutes: dur, severity: t.severity }) })
        }
      }
    }
    return { statusCode: 200, body: JSON.stringify({ ok:true, breaches }) }
  } catch (e:any) { return { statusCode: 500, body: JSON.stringify({ error: e.message }) } }
}
