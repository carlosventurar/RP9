# Playbooks D7/D30/D60
D7: activación; D30: adopción; D60–90: expansión.
