# Comunicación de Incidentes
- Inicio: anuncio y próxima actualización
- Follow-ups: cada 30–60m (según severidad)
- Cierre: resumen + compromiso de RCA
