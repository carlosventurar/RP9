# RCA / RFO — Plantilla
Resumen, línea de tiempo, causa raíz (5 porqués), acciones correctivas, prevención, comunicación.
