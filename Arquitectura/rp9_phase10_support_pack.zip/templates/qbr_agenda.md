# QBR / EBR
1) MRR y uso  2) KPIs  3) Incidentes/SLA  4) Roadmap  5) Objetivos 90 días
