# RP9 — SLA de Soporte (Resumen)
- Starter: Email 8x5, FRT 8h
- Pro: Email + Chat 8x5, FRT 4h
- Enterprise: Email + Chat 24/5 + Slack, FRT 1h

Severidades:
- P1 — Restore ≤2h; updates cada 30m
- P2 — Restore ≤8h
- P3 — Resolución ≤2 días
