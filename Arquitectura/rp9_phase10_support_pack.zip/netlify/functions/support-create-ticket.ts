import { Handler } from '@netlify/functions'
export const handler: Handler = async (event) => {
  try { return { statusCode: 200, body: JSON.stringify({ ok: true }) } }
  catch (e:any) { return { statusCode: 500, body: JSON.stringify({ ok:false, error: e.message }) } }
}
