RP9 Fase 10 — Soporte & CS
1) Aplica SQL en Supabase
2) Configura .env y deploy Functions en Netlify
3) Conecta HubSpot Service Hub
4) Crea Status Page y enlaza en portal
5) Programa support-sla-watch (5–10 min)
