// apps/functions/lib/security/rate-limit.ts
// Token bucket por tenant y apiKey. Usa Upstash Redis si está disponible, si no fallback a Supabase.

import fetch from 'node-fetch';

const url = process.env.UPSTASH_REDIS_REST_URL;
const token = process.env.UPSTASH_REDIS_REST_TOKEN;

async function upstashIncr(key: string, ttlSec: number) {
  if (!url || !token) return null;
  const body = JSON.stringify(["INCR", key]);
  const r = await fetch(url, { method: 'POST', headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' }, body });
  const json = await r.json();
  // set expire
  await fetch(url, { method: 'POST', headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify(['EXPIRE', key, ttlSec]) });
  return json.result;
}

export async function checkRateLimit(tenant: string, apiKey: string, rpm = Number(process.env.RATE_LIMIT_DEFAULT_RPM||300)) {
  const key = `rl:${tenant}:${apiKey}:${new Date().getUTCMinutes()}`;
  const count = await upstashIncr(key, 90);
  if (count === null) {
    // Fallback naive sin Redis: permitir (o implementar con Supabase buckets)
    return { allowed: true, remaining: 9999 };
  }
  const remaining = Math.max(0, rpm - Number(count));
  return { allowed: remaining > 0, remaining };
}
