// apps/functions/lib/security/ip-allowlist.ts
// Verifica IP contra allowlist por tenant (tabla ip_allowlist) + global CSV ALLOWED_IPS_GLOBAL

import { createClient } from '@supabase/supabase-js';

const supa = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);

function parseCsv(csv?: string|null) {
  return (csv||'').split(',').map(s=>s.trim()).filter(Boolean);
}

export async function checkIpAllowlist(tenantId: string, ip: string) {
  const globals = parseCsv(process.env.ALLOWED_IPS_GLOBAL);
  // Si globals vacío y tenant no tiene reglas → permitir por defecto
  const { data, error } = await supa.from('ip_allowlist').select('cidr').eq('tenant_id', tenantId);
  if (error) return { allowed: false, reason: 'db_error' };
  const cidrs = (data||[]).map(r=>r.cidr).concat(globals);
  if (!cidrs.length) return { allowed: true };

  // match simple por prefijo (aprox). Para producción usar lib CIDR match.
  const allowed = cidrs.some(c => ip && (ip.startsWith(c.replace('/32',''))));
  return { allowed, reason: allowed ? undefined : 'not_in_allowlist' };
}
