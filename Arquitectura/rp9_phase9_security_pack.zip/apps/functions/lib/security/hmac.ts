// apps/functions/lib/security/hmac.ts
// Verifica HMAC: sha256(secret, timestamp + "\n" + rawBody)
// Anti-replay: drift y nonce opcional (cache externo)

import crypto from 'crypto';

export function verifyHmac(headers: Record<string,string|undefined>, rawBody: string, secret: string, driftSec = 300) {
  const ts = headers['x-rp9-timestamp'] || headers['X-RP9-Timestamp'.toLowerCase()];
  const sig = headers['x-rp9-signature'] || headers['X-RP9-Signature'.toLowerCase()];
  if (!ts || !sig) return { ok: false, code: 'missing_headers' as const };

  const now = Math.floor(Date.now()/1000);
  const t = parseInt(String(ts), 10);
  if (!Number.isFinite(t) || Math.abs(now - t) > driftSec) return { ok: false, code: 'timestamp_out_of_range' as const };

  const payload = `${t}\n${rawBody}`;
  const mac = crypto.createHmac('sha256', secret).update(payload).digest('hex');
  const expected = `sha256=${mac}`;
  const provided = String(sig);
  const ok = crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(provided));
  return ok ? { ok: true as const } : { ok: false as const, code: 'invalid_signature' as const };
}
