// apps/functions/lib/audit.ts
import { createClient } from '@supabase/supabase-js';

const supa = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);

export async function logAudit(entry: {
  actor?: string|null,
  tenant_id?: string|null,
  ip?: string|null,
  ua?: string|null,
  action: string,
  resource?: string|null,
  result: 'allow'|'deny'|'error',
  diff?: any,
  meta?: any
}) {
  await supa.from('audit_log').insert({
    actor: entry.actor ? entry.actor : null,
    tenant_id: entry.tenant_id ? entry.tenant_id : null,
    ip: entry.ip || null,
    ua: entry.ua || null,
    action: entry.action,
    resource: entry.resource || null,
    result: entry.result,
    diff: entry.diff || null,
    meta: entry.meta || null
  });
}
