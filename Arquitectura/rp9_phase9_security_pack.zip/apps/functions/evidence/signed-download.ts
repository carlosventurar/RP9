// apps/functions/evidence/signed-download.ts
import { Handler } from '@netlify/functions';
import { createClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import { logAudit } from '../lib/audit.js';
import { verifyHmac } from '../lib/security/hmac.js';

export const handler: Handler = async (event, context) => {
  const rawBody = event.body || '';
  const secret = process.env.WEBHOOK_HMAC_SECRET || '';
  const v = verifyHmac(event.headers as any, rawBody, secret, Number(process.env.HMAC_ALLOWED_DRIFT_SECONDS||300));
  if (!v.ok) return { statusCode: 401, body: JSON.stringify({ error: 'invalid_signature', code: v.code }) };

  const supa = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);
  try {
    const { id } = JSON.parse(rawBody||'{}'); // evidence id
    if (!id) return { statusCode: 400, body: JSON.stringify({ error: 'missing_id' }) };

    const { data, error } = await supa.from('evidence_files').select('*').eq('id', id).single();
    if (error || !data) return { statusCode: 404, body: JSON.stringify({ error: 'not_found' }) };

    // Download file bytes to verify hash (server-side)
    const [bucket, ...keyParts] = String(data.path).split('/', 2);
    const key = keyParts.join('/');
    const { data: dl, error: stErr } = await supa.storage.from(bucket).download(key);
    if (stErr || !dl) return { statusCode: 500, body: JSON.stringify({ error: 'storage_error' }) };

    const buf = Buffer.from(await dl.arrayBuffer());
    const sha = crypto.createHash('sha256').update(buf).digest('hex');
    if (sha !== data.sha256) {
      await logAudit({ action: 'evidence.hash_mismatch', resource: id, result: 'deny' });
      return { statusCode: 409, body: JSON.stringify({ error: 'hash_mismatch' }) };
    }

    // Create signed URL
    const { data: signed, error: urlErr } = await supa.storage.from(bucket).createSignedUrl(key, 60); // 60s
    if (urlErr || !signed) return { statusCode: 500, body: JSON.stringify({ error: 'sign_error' }) };

    await logAudit({ action: 'evidence.signed_download', resource: id, result: 'allow' });
    return { statusCode: 200, body: JSON.stringify({ url: signed.signedUrl }) };
  } catch (e:any) {
    await logAudit({ action: 'evidence.signed_download', result: 'error', meta: { message: e.message } });
    return { statusCode: 500, body: JSON.stringify({ error: 'server_error' }) };
  }
};
