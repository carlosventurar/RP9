// apps/functions/keys/rotate-keys.ts
// Esqueleto: re-envuelve secretos con nueva KEK activa (KEK envelope). Ejecutar trimestralmente.
import { Handler } from '@netlify/functions';
import { createClient } from '@supabase/supabase-js';
import crypto from 'crypto';

function getKek(version: string) {
  const envKey = version.toUpperCase().replace(':','_');
  const val = process.env[envKey as any] || process.env['KEK_V1'];
  if (!val) throw new Error('Missing KEK for '+version);
  return Buffer.from(val, 'base64');
}

export const handler: Handler = async () => {
  const active = process.env.KEK_ACTIVE_VERSION || 'kek:v1';
  const supa = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);
  const { data, error } = await supa.from('secrets_encrypted').select('id, cipher, iv, tag, kek_version');
  if (error) return { statusCode: 500, body: JSON.stringify({ error: 'db_error' }) };

  let rotated = 0;
  for (const s of (data||[])) {
    if (s.kek_version === active) continue;
    // Normally: decrypt DEK with old KEK and re-encrypt with new KEK (envelope). Aquí solo actualizamos versión (demo).
    await supa.from('secrets_encrypted').update({ kek_version: active }).eq('id', s.id);
    rotated++;
  }
  return { statusCode: 200, body: JSON.stringify({ ok: true, rotated, active }) };
};
