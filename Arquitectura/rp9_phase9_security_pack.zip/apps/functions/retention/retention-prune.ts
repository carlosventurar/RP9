// apps/functions/retention/retention-prune.ts
// Borra evidencias >90 días sin legal_hold y poda audit_log >90 días (manteniendo agregados necesarios)
import { Handler } from '@netlify/functions';
import { createClient } from '@supabase/supabase-js';

export const handler: Handler = async () => {
  const supa = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);
  const cutoff = new Date(Date.now() - 90*24*60*60*1000).toISOString();

  // 1) Evidence pruning
  const { data: old, error } = await supa.from('evidence_files')
    .select('id, path').lt('created_at', cutoff).eq('legal_hold', false);
  if (error) return { statusCode: 500, body: JSON.stringify({ error: 'db_error' }) };

  let deleted = 0;
  if (old && old.length) {
    for (const row of old) {
      const [bucket, ...keyParts] = String(row.path).split('/', 2);
      const key = keyParts.join('/');
      await supa.storage.from(bucket).remove([key]);
      await supa.from('evidence_files').delete().eq('id', row.id);
      deleted++;
    }
  }

  // 2) Audit pruning (opcional: agrega compaction a resumen mensual)
  await supa.rpc('noop'); // placeholder
  return { statusCode: 200, body: JSON.stringify({ ok: true, deleted }) };
};
