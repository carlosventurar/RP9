# Seguridad en CI
- **CodeQL** para SAST (GitHub Actions).
- **Dependabot** para actualizaciones de dependencias.
- **ZAP Baseline** mensual (documentar resultados).