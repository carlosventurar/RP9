# RP9 Incident Response Playbook
Severidades: P1 (critico), P2, P3, P4. Objetivos: notificar clientes ≤72h, RCA ≤5 días.
- **Detección**: soporte/monitoreo/alerta.
- **Clasificación**: P1 fuga de datos, P2 indisponibilidad extendida, etc.
- **Acciones**: contener, mitigar, comunicar (email plantillas), registrar evidencias.
- **Cierre**: RCA, acciones preventivas, actualización de runbooks.