# Acceso a Producción (JIT)

- **SSO + MFA** obligatorio; **JIT 60 min** por ticket aprobado.  
- Accesos grabados en auditoría (usuario, hora, comandos críticos).  
- Revisiones **trimestrales** de accesos y eliminación de cuentas inactivas.  
- Prohibido compartir credenciales; uso de cuentas personales nominativas.
