# Playbook de Respuesta a Incidentes (RP9)

**Objetivo:** contener, erradicar y comunicar incidentes de seguridad con **notificación ≤72h** y **RCA ≤5 días**.

## Severidades
- **P1 – Data breach / PII expuesta:** notificación legal, clientes impactados, regulador si aplica.
- **P2 – Disponibilidad / fuga no confirmada:** comunicación a clientes si impacto significativo.
- **P3 – Menor / falso positivo:** seguimiento interno.

## Flujo
1) **Detección** → abrir ticket IR ### y canal privado.  
2) **Contención**: revocar llaves, aislar servicios, habilitar logs de nivel alto.  
3) **Erradicación**: parches, rotación de secretos, hardening.  
4) **Recuperación**: restaurar desde backup si aplica; monitoreo reforzado 7 días.  
5) **Comunicación**: aviso ≤72h (P1); actualización diaria hasta cierre.  
6) **RCA (≤5 días)**: 5 whys + medidas preventivas + dueños/fechas.

## Evidencias
- Hash de artefactos, export CSV/Parquet de logs, copias de configuraciones.
