# Política de Privacidad & PII (RP9)

- **Minimización:** almacenar solo los campos estrictamente necesarios.  
- **Enmascarado en ingestión:** emails `u***@dom.com`, teléfonos `+1*** *** 1234`.  
- **Clasificación:** Público / Interno / Confidencial / Regulado.  
- **Acceso:** RLS por tenant + roles; auditoría de accesos sensibles.  
- **Derechos de usuario:** export/eliminación bajo solicitud (endpoint dedicado).  
- **Retención:** 90 días por defecto; legal hold por ticket de auditoría.
