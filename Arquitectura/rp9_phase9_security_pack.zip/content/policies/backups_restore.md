# Backups & Restore

- **Backups diarios** de base de datos y Storage; **versionado** activado.  
- **Pruebas de restauración trimestrales** con checklist y tiempos objetivos.  
- Copias offsite cifradas; documentación de RTO/RPO por sistema.  
- Registro de resultados y mejoras en cada ejercicio.
