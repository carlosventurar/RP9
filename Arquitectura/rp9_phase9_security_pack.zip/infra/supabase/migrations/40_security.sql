-- Fase 9 • Seguridad & Compliance (Supabase)
-- Habilitar extensiones (si no existen)
create extension if not exists pgcrypto;
create extension if not exists pg_trgm;

-- === Tabla de auditoría ===
create table if not exists audit_log (
  id bigserial primary key,
  created_at timestamptz default now(),
  actor uuid,                      -- auth.uid() si aplica
  tenant_id uuid,
  ip inet,
  ua text,
  action text not null,            -- e.g. 'webhook.verify', 'evidence.download'
  resource text,                   -- e.g. 'workflow:123'
  result text,                     -- 'allow' | 'deny' | 'error'
  diff jsonb,                      -- cambios (old->new) sin PII
  meta jsonb
);
create index if not exists audit_log_tenant_idx on audit_log (tenant_id, created_at desc);

-- === Evidencias (si no existiera de fases previas) ===
create table if not exists evidence_files (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  workflow_id text,
  path text not null,              -- storage key
  sha256 text not null,
  size_bytes bigint,
  legal_hold boolean default false,
  created_by uuid,
  created_at timestamptz default now()
);
create index if not exists evidence_tenant_idx on evidence_files (tenant_id, created_at desc);

-- === API Keys por workflow/scope ===
create table if not exists api_keys (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  workflow_id text,                -- opcional: null = tenant‑wide
  scope text not null,             -- read|execute|metrics
  key_hash text not null,          -- sha256(rp9_sk_...)
  created_at timestamptz default now(),
  revoked_at timestamptz
);
create index if not exists api_keys_tenant_idx on api_keys (tenant_id, scope);

-- === Allowlist de IPs por tenant ===
create table if not exists ip_allowlist (
  id bigserial primary key,
  tenant_id uuid not null,
  cidr cidr not null,              -- 1.2.3.4/32 o rangos
  note text,
  created_at timestamptz default now()
);

-- === Buckets de rate-limit (fallback si no hay Redis) ===
create table if not exists rate_limit_buckets (
  key text primary key,            -- tenant:key
  tokens numeric not null default 0,
  capacity numeric not null default 300,
  refill_rate numeric not null default 5, -- tokens por segundo
  updated_at timestamptz not null default now()
);

-- === Secretos cifrados (envoltura con KEK) ===
create table if not exists secrets_encrypted (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid,
  name text not null,
  cipher text not null,            -- base64(AES-GCM(DEK,data))
  iv bytea not null,
  tag bytea not null,
  kek_version text not null,       -- kek:v1
  created_at timestamptz default now()
);

-- === RLS básico (ajusta a tu modelo de auth) ===
alter table audit_log enable row level security;
create policy audit_by_tenant on audit_log
  using ( tenant_id in (select id from tenants where owner_user = auth.uid()) );

alter table evidence_files enable row level security;
create policy evidence_by_tenant on evidence_files
  using ( tenant_id in (select id from tenants where owner_user = auth.uid()) );

alter table api_keys enable row level security;
create policy keys_by_tenant on api_keys
  using ( tenant_id in (select id from tenants where owner_user = auth.uid()) );

alter table ip_allowlist enable row level security;
create policy ip_by_tenant on ip_allowlist
  using ( tenant_id in (select id from tenants where owner_user = auth.uid()) );

alter table secrets_encrypted enable row level security;
create policy secrets_by_tenant on secrets_encrypted
  using ( tenant_id in (select id from tenants where owner_user = auth.uid()) );
