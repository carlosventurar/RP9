export type MoneyInput = { amount: number; currency: string; locale?: string };
export function formatMoney({ amount, currency, locale='es-419' }: MoneyInput) {
  return new Intl.NumberFormat(locale, { style: 'currency', currency }).format(amount);
}
export function displayPrice(localAmount:number, localCurrency:string, showUSD:boolean, usdAmount?:number, locale='es-419'){
  const local = formatMoney({ amount: localAmount, currency: localCurrency, locale });
  if (!showUSD || usdAmount == null) return local;
  const usd = formatMoney({ amount: usdAmount, currency: 'USD', locale: 'en-US' });
  return `${local} (≈ ${usd})`;
}
