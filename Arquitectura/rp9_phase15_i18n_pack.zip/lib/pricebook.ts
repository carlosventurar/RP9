type PriceQuery = { plan:'starter'|'pro'|'enterprise'|'addon'; period:'monthly'|'yearly'; country:string; currencyPref?:'LOCAL'|'USD' }
type PriceResult = { stripe_price_id:string; currency:string; psychological_price:number }

// Dummy implementation; reads local JSON pricebook at build/runtime
import fs from 'fs'
import path from 'path'

export async function getPriceId(q: PriceQuery): Promise<PriceResult> {
  const p = path.join(process.cwd(), 'config', 'pricebook.json')
  const raw = fs.readFileSync(p, 'utf-8')
  const book = JSON.parse(raw) as any
  const key = `${q.country}:${q.plan}:${q.period}`
  const row = book[key]
  if(!row) throw new Error('Price not found for ' + key)
  return { stripe_price_id: row.stripe_price_id, currency: row.currency, psychological_price: row.psychological_price }
}
