# RP9 — Fase 15 Internacionalización (LatAm‑first)

Este paquete incluye:
- `RP9_Fase15_Internacionalizacion.md`: Master Prompt para Claude Code (decisiones, sprints, SQL, ejemplos).
- Mensajes i18n base: `apps/portal/messages/*.json`
- Middleware de negociación de locale: `apps/portal/middleware.ts`
- Utilidades i18n: `apps/portal/lib/i18n/*`
- Componentes de UI: `apps/portal/components/{LocaleSwitcher,PriceTag}.tsx`
- Netlify Function de checkout seleccionando `price_id`: `apps/functions/billing/checkout.ts`
- `infra/supabase/migrations/90_i18n.sql`: tablas i18n/pricebook/flags/impuestos.
- `config/pricebook.example.json`: ejemplo de price book por país/plan.
- `.env.example`

## Uso rápido
1. Copia la carpeta a tu monorepo `rp9/`.
2. Crea `config/pricebook.json` con tus `price_id` de Stripe por país/plan/período.
3. Ejecuta la migración `90_i18n.sql` en Supabase.
4. Ajusta `messages/*.json` y agrega tus textos.
5. Despliega en Netlify; prueba `/.netlify/functions/billing/checkout` con `{plan,period,country}`.

**Nota**: este pack asume Stripe Price Book por país (sin FX runtime) y normalización financiera a USD a nivel analítico.
