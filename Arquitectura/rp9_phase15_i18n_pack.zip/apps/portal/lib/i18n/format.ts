export function formatCurrency(value:number, currency:string, locale?:string){
  return new Intl.NumberFormat(locale || undefined, { style:'currency', currency }).format(value)
}
export function formatNumber(value:number, locale?:string){
  return new Intl.NumberFormat(locale || undefined).format(value)
}
