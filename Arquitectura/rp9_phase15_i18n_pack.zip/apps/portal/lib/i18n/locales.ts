export const SUPPORTED_LOCALES = ['es-419','en-US','es-MX','es-AR','es-CO','es-CL','es-PE','es-DO'] as const
export type Locale = typeof SUPPORTED_LOCALES[number]
export const DEFAULT_LOCALE: Locale = 'es-419'

export const COUNTRY_TO_LOCALE: Record<string, Locale> = {
  MX:'es-MX', AR:'es-AR', CO:'es-CO', CL:'es-CL', PE:'es-PE', DO:'es-DO'
}
