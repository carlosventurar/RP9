import { NextRequest, NextResponse } from 'next/server';

const SUPPORTED = ['es-419','es-MX','es-AR','es-CO','es-CL','es-PE','es-DO','en-US'] as const;
const COUNTRY_MAP: Record<string,string> = { MX:'es-MX', AR:'es-AR', CO:'es-CO', CL:'es-CL', PE:'es-PE', DO:'es-DO', US:'en-US' };
const COUNTRY_ALIAS: Record<string,string> = { mx:'es-MX', ar:'es-AR', co:'es-CO', cl:'es-CL', pe:'es-PE', do:'es-DO', us:'en-US' };
const DEFAULT_LOCALE = process.env.DEFAULT_LOCALE || 'es-419';

export function middleware(req: NextRequest) {
  const { pathname, search } = req.nextUrl;
  if (pathname.startsWith('/_next') || pathname.startsWith('/api') || pathname.includes('.')) return NextResponse.next();

  const seg = pathname.split('/').filter(Boolean)[0];
  if ((SUPPORTED as readonly string[]).includes(seg)) return NextResponse.next();

  let locale: string | null = null;

  const utmParam = req.nextUrl.searchParams.get('utm_locale') || req.nextUrl.searchParams.get('utm_country');
  if (utmParam) {
    const key = utmParam.toLowerCase();
    locale = COUNTRY_ALIAS[key] || (SUPPORTED as readonly string[]).find(l => l.toLowerCase() === key) || null;
  }

  if (!locale) {
    const country = (req.headers.get('x-nf-geo') || req.headers.get('cf-ipcountry') || '').toUpperCase();
    if (COUNTRY_MAP[country]) locale = COUNTRY_MAP[country];
  }

  if (!locale) {
    const al = req.headers.get('accept-language') || '';
    const pref = al.split(',')[0];
    const found = (SUPPORTED as readonly string[]).find(l => pref.startsWith(l));
    locale = found || null;
  }

  if (!locale) {
    const cookie = req.cookies.get('rp9_locale')?.value;
    if (cookie && (SUPPORTED as readonly string[]).includes(cookie)) locale = cookie;
  }

  if (!locale) locale = DEFAULT_LOCALE;

  const url = req.nextUrl.clone();
  url.pathname = `/${locale}${pathname}`;
  url.search = search;
  const res = NextResponse.redirect(url);
  res.cookies.set('rp9_locale', locale, { path: '/', maxAge: 60*60*24*365 });
  return res;
}

export const config = { matcher: ['/((?!_next|api|.*\\..*).*)'] };