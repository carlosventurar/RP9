import { NextRequest, NextResponse } from 'next/server'
import { match as matchLocale } from '@formatjs/intl-localematcher'

const SUPPORTED = ['es-419','en-US','es-MX','es-AR','es-CO','es-CL','es-PE','es-DO']
const DEFAULT = 'es-419'

export function middleware(req: NextRequest) {
  const { nextUrl, headers } = req
  const { pathname } = nextUrl

  // 1) Alias por país: /mx → /es-MX
  const alias = pathname.split('/')[1]
  const aliasMap: Record<string,string> = { mx:'es-MX', ar:'es-AR', co:'es-CO', cl:'es-CL', pe:'es-PE', do:'es-DO' }
  if (alias in aliasMap) {
    const url = req.nextUrl.clone()
    url.pathname = `/${aliasMap[alias]}${pathname.replace(`/${alias}`,'')}`
    return NextResponse.redirect(url)
  }

  // 2) Si ya incluye locale, sigue
  const seg = pathname.split('/')[1]
  if (SUPPORTED.includes(seg)) return NextResponse.next()

  // 3) Negociación en cascada
  const utmLoc = nextUrl.searchParams.get('utm_loc')
  const ipLoc = headers.get('x-country')
  const al = headers.get('accept-language') || ''
  const candidates = [utmLoc, ipLoc, ...al.split(',')].filter(Boolean) as string[]
  const matched = matchLocale(candidates, SUPPORTED, DEFAULT)

  const url = req.nextUrl.clone()
  url.pathname = `/${matched}${pathname}`
  return NextResponse.redirect(url)
}

export const config = { matcher: ['/((?!_next|favicon.ico|assets).*)'] }
