'use client';
import { useState } from 'react';
const LABELS: Record<string,string> = { MX:'RFC', CO:'NIT', CL:'RUT', PE:'RUC', AR:'CUIT', DO:'RNC' };
export function TaxIdField({ country='MX', value='', onChange }:{ country?:string; value?:string; onChange?:(v:string)=>void }) {
  const [val,setVal]=useState(value); const label = LABELS[country] || 'Tax ID';
  function handle(v:string){ setVal(v); onChange?.(v); }
  return (
    <div className="space-y-1">
      <label className="text-sm text-slate-600">{label}</label>
      <input value={val} onChange={e=>handle(e.target.value)} className="border rounded px-2 py-1 w-full" placeholder={label} />
      <p className="text-xs text-slate-500">Validación básica; reglas completas en backend.</p>
    </div>
  );
}
