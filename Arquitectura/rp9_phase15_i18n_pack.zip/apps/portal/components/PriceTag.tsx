'use client'
import { useState } from 'react'
import { formatCurrency } from '../lib/i18n/format'

export function PriceTag({ localAmount, currency, usdApprox }:{ localAmount:number; currency:string; usdApprox:number }){
  const [showUSD, setShowUSD] = useState(false)
  return (
    <div className="flex items-center gap-2">
      <span className="text-2xl font-semibold">{formatCurrency(localAmount, currency)}</span>
      <button type="button" className="text-xs underline" onClick={()=>setShowUSD(!showUSD)}>
        {showUSD ? formatCurrency(localAmount, currency) : `≈ ${formatCurrency(usdApprox, 'USD', 'en-US')}`}
      </button>
    </div>
  )
}
