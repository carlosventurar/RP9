'use client'
import { usePathname, useRouter } from 'next/navigation'
import { SUPPORTED_LOCALES } from '../lib/i18n/locales'

export function LocaleSwitcher(){
  const router = useRouter()
  const path = usePathname()
  function setLocale(loc:string){
    const segs = path.split('/').filter(Boolean)
    const currentIsLocale = SUPPORTED_LOCALES.includes(segs[0] as any)
    if(currentIsLocale){ segs[0] = loc } else { segs.unshift(loc) }
    router.push('/' + segs.join('/'))
  }
  return (
    <select onChange={(e)=>setLocale(e.target.value)} className="border rounded px-2 py-1">
      {SUPPORTED_LOCALES.map(l => <option key={l} value={l}>{l}</option>)}
    </select>
  )
}
