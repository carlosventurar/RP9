'use client';
import { useState, useEffect } from 'react';
const LOCALES = ['es-419','es-MX','es-AR','es-CO','es-CL','es-PE','es-DO','en-US'];
export function LocaleSwitcher() {
  const [locale,setLocale] = useState<string>('es-419');
  useEffect(()=>{ const cur = window.location.pathname.split('/').filter(Boolean)[0]; if (LOCALES.includes(cur)) setLocale(cur); },[]);
  function onChange(e:any){
    const next = e.target.value; const parts = window.location.pathname.split('/').filter(Boolean); parts[0] = next;
    const dest = '/' + parts.join('/'); document.cookie = `rp9_locale=${next};path=/;max-age=${60*60*24*365}`; window.location.assign(dest);
  }
  return (<select value={locale} onChange={onChange} className="border rounded px-2 py-1">{LOCALES.map(l => <option key={l} value={l}>{l}</option>)}</select>);
}
