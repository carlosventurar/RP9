'use client';
import { useState, useEffect } from 'react';
export function CurrencyToggle(){
  const [showUSD,setShowUSD]=useState<boolean>(true);
  useEffect(()=>{ const v = localStorage.getItem('rp9_show_usd'); setShowUSD(v !== 'false'); },[]);
  function toggle(){ const v = !showUSD; setShowUSD(v); localStorage.setItem('rp9_show_usd', String(v)); location.reload(); }
  return (<button onClick={toggle} className="border rounded px-3 py-1">{showUSD ? 'Mostrar solo moneda local' : 'Mostrar también USD'}</button>);
}
