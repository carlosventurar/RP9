import { Handler } from '@netlify/functions'
import Stripe from 'stripe'
import { getPriceId } from '../../lib/pricebook'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2023-10-16' })

export const handler: Handler = async (event) => {
  if(event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' }
  const body = JSON.parse(event.body||'{}')
  const { plan, period, country } = body
  if(!plan || !period || !country) return { statusCode: 400, body: 'Missing plan/period/country' }
  const price = await getPriceId({ plan, period, country })
  const session = await stripe.checkout.sessions.create({
    mode: 'subscription',
    line_items: [{ price: price.stripe_price_id, quantity: 1 }],
    success_url: 'https://rp9.io/success',
    cancel_url: 'https://rp9.io/cancel'
  })
  return { statusCode: 200, body: JSON.stringify({ url: session.url }) }
}
