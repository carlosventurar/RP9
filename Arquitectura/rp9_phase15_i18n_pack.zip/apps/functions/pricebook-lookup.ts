import { Handler } from '@netlify/functions';
const cfg = require('../../config/priceBooks.json');
export const handler: Handler = async (event) => {
  try {
    const { country='MX', plan='starter', period='monthly' } = JSON.parse(event.body || '{}');
    const priceId = cfg?.[country]?.[plan]?.[period];
    if (!priceId) return { statusCode: 404, body: JSON.stringify({ error: 'Not found' }) };
    return { statusCode: 200, body: JSON.stringify({ priceId }) };
  } catch (e:any) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) };
  }
}
