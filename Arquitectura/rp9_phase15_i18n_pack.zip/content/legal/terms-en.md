# Terms of Service (EN)
Localized country annexes live alongside the ES base.
