# Términos de Servicio (ES) — base neutra
Anexos por país en `annex-*.md`.
