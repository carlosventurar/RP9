-- Fase 15 · Internacionalización (LatAm-first)

create table if not exists locales (
  code text primary key,
  name text not null,
  country text,
  created_at timestamptz default now()
);

create table if not exists i18n_messages (
  id bigserial primary key,
  locale text references locales(code) on delete cascade,
  ns text default 'common',
  key text not null,
  value text not null,
  updated_by uuid,
  updated_at timestamptz default now()
);
create index if not exists i18n_idx_locale_ns on i18n_messages(locale, ns);
create unique index if not exists i18n_unique_key on i18n_messages(locale, ns, key);

create table if not exists country_configs (
  country text primary key,
  locale_default text references locales(code),
  currency text not null,
  pricing_model text not null check (pricing_model in ('gross','net')),
  tax_label text,
  tax_id_label text,
  tax_id_regex text,
  timezone text,
  meta jsonb default '{}',
  updated_at timestamptz default now()
);

create table if not exists price_books (
  id uuid primary key default gen_random_uuid(),
  country text references country_configs(country) on delete cascade,
  plan text not null,
  period text not null check (period in ('monthly','yearly')),
  price_id text not null,
  currency text not null,
  addons jsonb default '[]',
  active boolean default true,
  unique(country, plan, period)
);

create table if not exists tenant_settings (
  tenant_id uuid primary key,
  locale text references locales(code),
  currency text,
  timezone text,
  show_usd boolean default true,
  updated_at timestamptz default now()
);

insert into locales(code,name,country) values
  ('es-419','Español (LatAm)','LA'),
  ('es-MX','Español (México)','MX'),
  ('es-AR','Español (Argentina)','AR'),
  ('es-CO','Español (Colombia)','CO'),
  ('es-CL','Español (Chile)','CL'),
  ('es-PE','Español (Perú)','PE'),
  ('es-DO','Español (Rep. Dominicana)','DO'),
  ('en-US','English (US)','US')
on conflict (code) do nothing;

insert into country_configs(country, locale_default, currency, pricing_model, tax_label, tax_id_label, timezone)
values
  ('MX','es-MX','MXN','net','IVA','RFC','America/Mexico_City'),
  ('CO','es-CO','COP','net','IVA','NIT','America/Bogota'),
  ('CL','es-CL','CLP','gross','IVA','RUT','America/Santiago'),
  ('PE','es-PE','PEN','gross','IGV','RUC','America/Lima'),
  ('AR','es-AR','ARS','gross','IVA','CUIT','America/Argentina/Buenos_Aires'),
  ('DO','es-DO','DOP','gross','ITBIS','RNC','America/Santo_Domingo')
on conflict (country) do nothing;
