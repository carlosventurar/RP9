-- País/locale preferido del tenant
create table if not exists tenant_settings (
  tenant_id uuid primary key,
  country char(2) not null default 'MX',
  locale text not null default 'es-MX',
  timezone text not null default 'America/Mexico_City',
  currency char(3) not null default 'MXN',
  flags jsonb default '{}',
  updated_at timestamptz default now()
);

-- Preferencias de usuario
create table if not exists user_prefs (
  user_id uuid primary key,
  locale text default 'es-419',
  currency char(3) default 'LOCAL',
  updated_at timestamptz default now()
);

-- Price book por país/plan/periodicidad
create table if not exists pricebook (
  id bigserial primary key,
  country char(2) not null,
  plan text not null,              -- starter|pro|enterprise|addon
  period text not null,            -- monthly|yearly
  currency char(3) not null,
  stripe_price_id text not null,
  psychological_price numeric,     -- 1999, 399000...
  meta jsonb default '{}',
  unique(country, plan, period)
);

-- Reglas de impuestos por país
create table if not exists tax_rules (
  country char(2) primary key,
  mode text not null,              -- gross|net
  tax_id_label text,               -- RFC|RUT|RUC|CUIT|NIT|RNC
  required boolean default false,
  vat numeric,                     -- opcional
  meta jsonb default '{}'
);

-- Feature flags por país y por tenant
create table if not exists country_flags (
  country char(2) primary key,
  flags jsonb not null             -- { payment_local: true, include_tax: true, templates: ["SAT","DIAN"] }
);

create table if not exists tenant_flags (
  tenant_id uuid primary key,
  flags jsonb not null default '{}'
);

-- Mensajes i18n gestionados en BD
create table if not exists i18n_messages (
  id bigserial primary key,
  locale text not null,
  key text not null,
  value text not null,
  unique(locale, key)
);