
# DATA_RETENTION.md — Retención y anonimización

- Payloads de ejecuciones: 30–90 días (por tenant).
- Opción de anonimizar a 30 días por contrato (hash, truncamiento, PII removal).
- Auditoría: logs de acciones (no payloads completos).
