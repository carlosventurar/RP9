
# ACCESS_REVIEW.md — Revisión mensual de accesos

## Alcance
- GitHub, Netlify, Supabase, Stripe, Railway, Status Page, Cloudflare.

## Pasos
1. Exporta lista de usuarios/roles.
2. Revoca accesos inactivos.
3. Verifica 2FA y rotación de claves (>90 días).
