
import { Handler } from '@netlify/functions'
import crypto from 'crypto'

export const handler: Handler = async (event) => {
  // En un caso real: lee registro, calcula/valida hash del archivo en Storage
  const id = event.queryStringParameters?.id
  if (!id) return { statusCode: 400, body: 'id required' }
  const url = `https://storage.rp9.io/tmp/${id}?sig=${crypto.randomBytes(8).toString('hex')}`
  return { statusCode: 200, body: JSON.stringify({ url }) }
}
