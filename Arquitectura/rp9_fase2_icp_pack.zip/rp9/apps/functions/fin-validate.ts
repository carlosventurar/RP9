
import { Handler } from '@netlify/functions'
import { adminClient } from '../../lib/supabase'
import crypto from 'crypto'

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' }
  // Se asume base64 del archivo para simplificar el stub
  const body = JSON.parse(event.body || '{}')
  const { tenant_id, country, workflow_id, filename, file_b64 } = body
  if (!file_b64) return { statusCode: 400, body: 'file_b64 required' }

  const buf = Buffer.from(file_b64, 'base64')
  const sha256 = crypto.createHash('sha256').update(buf).digest('hex')

  const supa = adminClient()
  // Subir a Storage (stub en DB: solo registramos path/sha)
  const path = `evidence/${new Date().toISOString().slice(0,10)}/${filename}`
  const { error } = await supa.from('evidence_files').insert({
    tenant_id, country, workflow_id, path, sha256, size_bytes: buf.length
  } as any)
  if (error) return { statusCode: 500, body: JSON.stringify({ error: error.message }) }

  return { statusCode: 200, body: JSON.stringify({ id: 'ev_'+sha256.slice(0,8), path, sha256, size_bytes: buf.length }) }
}
