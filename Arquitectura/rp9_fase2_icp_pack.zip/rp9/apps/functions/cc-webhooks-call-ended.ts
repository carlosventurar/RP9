
import { Handler } from '@netlify/functions'
import { adminClient } from '../../lib/supabase'
import { verifyHmac } from '../../lib/security/hmac'
import { rateLimit } from '../../lib/rateLimit'

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' }
  const key = (event.headers['x-forwarded-for'] || 'anon') + ':cc-webhook'
  const rl = rateLimit(String(key), Number(process.env.RATE_LIMIT_MAX||300), Number(process.env.RATE_LIMIT_WINDOW_MS||60000))
  if (!rl.allowed) return { statusCode: 429, body: 'Rate limit exceeded' }

  const signature = event.headers['x-rp9-signature'] as string
  const secret = process.env.HMAC_SECRET as string
  const raw = event.body || ''

  if (!verifyHmac(raw, signature, secret)) {
    return { statusCode: 401, body: 'Invalid signature' }
  }

  const payload = JSON.parse(raw || '{}')
  const normalized = {
    type: 'call.ended',
    provider: payload.provider || '3cx',
    occurred_at: payload.ended_at || new Date().toISOString(),
    payload
  }

  const supa = adminClient()
  const { error } = await supa.from('events_cc').insert({
    tenant_id: payload.tenant_id || null,
    type: normalized.type,
    provider: normalized.provider,
    payload: payload,
    occurred_at: normalized.occurred_at
  } as any)

  if (error) return { statusCode: 500, body: JSON.stringify({ error: error.message }) }

  return { statusCode: 200, body: JSON.stringify({ ok: true }) }
}
