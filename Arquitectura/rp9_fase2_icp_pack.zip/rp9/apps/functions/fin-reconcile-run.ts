
import { Handler } from '@netlify/functions'
import { adminClient } from '../../lib/supabase'

function matches(rule:any, tx:any){
  const txt = (tx.description||'').toLowerCase();
  if (rule.contains && !txt.includes(String(rule.contains).toLowerCase())) return false;
  if (rule.amount_delta && Math.abs((tx.amount||0) - (rule.amount||0)) > Number(rule.amount_delta)) return false;
  return true;
}

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' }
  const body = JSON.parse(event.body || '{}')
  const supa = adminClient()
  // Cargar reglas
  const { data: rules } = await supa.from('reconciliation_rules').select('*').eq('tenant_id', body.tenant_id)
  const exceptions:any[] = []

  for (const tx of (body.transactions||[])) {
    const rule = (rules||[]).find((r:any)=> matches(r.matcher, tx))
    const status = rule ? 'matched' : 'exception'
    await supa.from('reconciliation_matches').insert({
      tenant_id: body.tenant_id, rule_id: rule?.id || null, bank_tx: tx, status
    } as any)
    if (!rule) exceptions.push(tx)
  }

  return { statusCode: 200, body: JSON.stringify({ ok: true, exceptions }) }
}
