
import { Handler } from '@netlify/functions'

export const handler: Handler = async () => {
  // KPIs de ejemplo
  const autoValidation = 0.93;
  const exceptions = 17;
  const hoursSaved = 46;
  const cycleDays = 2.1;
  return { statusCode: 200, body: JSON.stringify({ autoValidation, exceptions, hoursSaved, cycleDays }) }
}
