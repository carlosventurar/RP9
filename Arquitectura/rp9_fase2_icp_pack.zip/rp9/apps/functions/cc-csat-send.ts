
import { Handler } from '@netlify/functions'
import { adminClient } from '../../lib/supabase'
import fetch from 'node-fetch'

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' }
  const body = JSON.parse(event.body || '{}')
  const phone = body.phone
  const waUrl = process.env.WA_API_URL!
  const waToken = process.env.WA_TOKEN!
  try {
    // Enviar mensaje WA (stub)
    await fetch(waUrl, { method: 'POST', headers: { 'Authorization': `Bearer ${waToken}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ to: phone, template: process.env.WA_TEMPLATE_ID || 'csat_template_es' }) })
  } catch (e:any) {
    // TODO: fallback email
  }
  // Persistir estado csat pending
  const supa = adminClient()
  await supa.from('tickets').insert({ tenant_id: body.tenant_id || null, crm: 'hubspot', contact_id: body.contact_id || null, status: 'csat_pending', meta: body })
  return { statusCode: 200, body: JSON.stringify({ ok: true }) }
}
