
import { Handler } from '@netlify/functions'
import { createTicketHubSpot } from '../../lib/crm/hubspot'
import { createTicketZendesk } from '../../lib/crm/zendesk'
import { createTicketFreshdesk } from '../../lib/crm/freshdesk'

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' }
  const body = JSON.parse(event.body || '{}')
  const text = (body.transcript || '').toLowerCase()
  const urgent = text.includes('cancelación') || (body.sla && body.sla.breached)
  if (!urgent) return { statusCode: 200, body: JSON.stringify({ ok: true, escalated: false }) }

  const crm = (process.env.CRM_PROVIDER || 'hubspot').toLowerCase()
  let ticket
  if (crm === 'hubspot') ticket = await createTicketHubSpot(body)
  else if (crm === 'zendesk') ticket = await createTicketZendesk(body)
  else ticket = await createTicketFreshdesk(body)

  return { statusCode: 200, body: JSON.stringify({ ok: true, escalated: true, ticket }) }
}
