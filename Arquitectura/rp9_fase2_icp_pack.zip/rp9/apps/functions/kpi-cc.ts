
import { Handler } from '@netlify/functions'
import { adminClient } from '../../lib/supabase'

export const handler: Handler = async () => {
  const supa = adminClient()
  // NOTA: KPIs de ejemplo (usar SQL agregados reales)
  const aht = 120; const p95 = 180; const csat = 4.4; const errorRate = 0.03;
  return { statusCode: 200, body: JSON.stringify({ aht, p95, csat, errorRate }) }
}
