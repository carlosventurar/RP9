
'use client';
import { useEffect, useState } from 'react';
export function CCKPIs(){
  const [kpi,setKpi]=useState<any>({});
  useEffect(()=>{ fetch('/.netlify/functions/kpi-cc').then(r=>r.json()).then(setKpi); },[]);
  const items=[
    {label:'AHT', value: (kpi.aht||0)+'s'},
    {label:'p95', value: (kpi.p95||0)+'s'},
    {label:'CSAT', value: (kpi.csat||0)},
    {label:'Errores', value: ((kpi.errorRate||0)*100).toFixed(1)+'%'},
  ];
  return <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{items.map(i=>(
    <div key={i.label} className="rounded-2xl border p-4">
      <div className="text-xs text-slate-500">{i.label}</div>
      <div className="text-xl font-semibold mt-1">{i.value}</div>
    </div>
  ))}</div>;
}
