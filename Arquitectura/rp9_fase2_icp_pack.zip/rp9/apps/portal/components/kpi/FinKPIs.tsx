
'use client';
import { useEffect, useState } from 'react';
export function FinKPIs(){
  const [kpi,setKpi]=useState<any>({});
  useEffect(()=>{ fetch('/.netlify/functions/kpi-fin').then(r=>r.json()).then(setKpi); },[]);
  const items=[
    {label:'Validación auto', value: ((kpi.autoValidation||0)*100).toFixed(0)+'%'},
    {label:'Excepciones', value: (kpi.exceptions||0)},
    {label:'Horas ahorradas', value: (kpi.hoursSaved||0)},
    {label:'Ciclo (días)', value: (kpi.cycleDays||0)},
  ];
  return <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{items.map(i=>(
    <div key={i.label} className="rounded-2xl border p-4">
      <div className="text-xs text-slate-500">{i.label}</div>
      <div className="text-xl font-semibold mt-1">{i.value}</div>
    </div>
  ))}</div>;
}
