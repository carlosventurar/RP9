
'use client';
import { useEffect, useState } from 'react';

export function EvidenceTable(){
  const [rows,setRows]=useState<any[]>([]);
  const [q,setQ]=useState('');
  useEffect(()=>{
    // TODO: fetch from Supabase via RPC/API
    setRows([]);
  },[]);
  async function download(id:string){
    const r=await fetch('/.netlify/functions/evidence-get?id='+id);
    const data=await r.json();
    window.location.href=data.url;
  }
  return (
    <div className="space-y-3">
      <input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="Buscar..." className="border rounded px-3 py-2 w-full"/>
      <div className="overflow-auto rounded border">
        <table className="min-w-full text-sm">
          <thead><tr><th className="text-left p-2">ID</th><th className="text-left p-2">País</th><th className="text-left p-2">Workflow</th><th className="text-left p-2">Archivo</th><th></th></tr></thead>
          <tbody>
            {rows.filter(r=>JSON.stringify(r).toLowerCase().includes(q.toLowerCase())).map(r=>(
              <tr key={r.id} className="border-t">
                <td className="p-2">{r.id}</td>
                <td className="p-2">{r.country}</td>
                <td className="p-2">{r.workflow_id}</td>
                <td className="p-2">{r.path}</td>
                <td className="p-2"><button className="px-3 py-1 rounded bg-black text-white" onClick={()=>download(r.id)}>Descargar</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
