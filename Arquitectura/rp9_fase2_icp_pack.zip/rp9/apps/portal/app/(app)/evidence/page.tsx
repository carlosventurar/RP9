
import { EvidenceTable } from '@/components/evidence/EvidenceTable'

export default function EvidencePage(){
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Evidencias</h1>
      <EvidenceTable/>
    </div>
  )
}
