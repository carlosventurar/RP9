
import { CCKPIs } from '@/components/kpi/CCKPIs'
import { FinKPIs } from '@/components/kpi/FinKPIs'

export default function Dashboard(){
  return (
    <div className="space-y-6">
      <section>
        <h1 className="text-2xl font-semibold mb-2">Contact Center</h1>
        <CCKPIs/>
      </section>
      <section>
        <h1 className="text-2xl font-semibold mb-2">Finanzas</h1>
        <FinKPIs/>
      </section>
    </div>
  )
}
