
-- Fase 2: ICP CC + Finanzas
create table if not exists events_cc (
  id bigserial primary key,
  tenant_id uuid references tenants(id) on delete cascade,
  type text not null,
  provider text not null,
  payload jsonb not null,
  occurred_at timestamptz not null,
  created_at timestamptz default now()
);

create table if not exists tickets (
  id bigserial primary key,
  tenant_id uuid references tenants(id) on delete cascade,
  crm text not null,
  contact_id text,
  ticket_id text,
  priority text,
  status text,
  csat int,
  meta jsonb default '{}',
  created_at timestamptz default now()
);

create table if not exists evidence_files (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid references tenants(id) on delete cascade,
  country text,
  workflow_id text,
  path text not null,
  sha256 text not null,
  size_bytes bigint,
  created_by uuid,
  created_at timestamptz default now()
);

create table if not exists reconciliation_rules (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid references tenants(id) on delete cascade,
  name text,
  matcher jsonb not null,
  account text,
  created_at timestamptz default now()
);

create table if not exists reconciliation_matches (
  id bigserial primary key,
  tenant_id uuid references tenants(id) on delete cascade,
  rule_id uuid references reconciliation_rules(id) on delete cascade,
  bank_tx jsonb not null,
  status text not null,
  created_at timestamptz default now()
);

create index if not exists idx_events_cc_tenant_time on events_cc (tenant_id, occurred_at desc);
create index if not exists idx_evidence_tenant_time on evidence_files (tenant_id, created_at desc);
create index if not exists idx_recon_tenant_time on reconciliation_matches (tenant_id, created_at desc);
