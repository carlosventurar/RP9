
export function verifyHmac(rawBody: string, signature: string, secret: string) {
  const crypto = require('crypto');
  const mac = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
  if (!signature) return false;
  const a = Buffer.from(mac);
  const b = Buffer.from(signature);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
