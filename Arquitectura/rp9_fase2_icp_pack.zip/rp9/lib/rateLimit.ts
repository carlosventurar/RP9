
const buckets = new Map<string,{count:number,reset:number}>();

export function rateLimit(key:string, max:number, windowMs:number){
  const now=Date.now();
  const b=buckets.get(key) || {count:0, reset: now+windowMs};
  if (now>b.reset){ b.count=0; b.reset=now+windowMs; }
  b.count++;
  buckets.set(key,b);
  return { allowed: b.count<=max, remaining: Math.max(0, max-b.count), reset: b.reset };
}
