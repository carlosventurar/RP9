
export async function createTicketZendesk(input:any){ return { id: 'zd_ticket_1' }; }
