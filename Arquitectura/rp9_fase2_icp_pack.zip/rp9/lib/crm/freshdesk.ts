
export async function createTicketFreshdesk(input:any){ return { id: 'fd_ticket_1' }; }
