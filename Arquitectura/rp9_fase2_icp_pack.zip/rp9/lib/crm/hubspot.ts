
export async function createTicketHubSpot(input:any){ return { id: 'hs_ticket_1' }; }
export async function upsertContactHubSpot(input:any){ return { id: 'hs_contact_1' }; }
