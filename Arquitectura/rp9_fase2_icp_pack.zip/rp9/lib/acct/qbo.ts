
export async function createJournalQBO(input:any){ return { id: 'qbo_journal_1' }; }
