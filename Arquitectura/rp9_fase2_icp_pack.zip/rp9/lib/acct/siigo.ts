
export async function createEntrySiigo(input:any){ return { id: 'siigo_entry_1' }; }
