
# RP9 – Fase 2: ICP & Casos de Uso (CC + Finanzas)

## Pasos rápidos
1) Ejecuta la migración `infra/supabase/migrations/15_icp_cc_fin.sql` en Supabase.
2) Configura `.env` (HMAC, Supabase, WhatsApp, CRM/Contabilidad, n8n).
3) Despliega Netlify Functions de `apps/functions`.
4) Publica páginas `/dashboard` y `/evidence` en `apps/portal`.
5) Carga plantillas JSON en `apps/portal/public/templates` e impórtalas en n8n via API.

## Notas
- Habilita RLS y usa **service role** sólo en Functions.
- Anonimiza PII en logs.
- Reutiliza el recolector de uso de Fase 1 para pricing.
