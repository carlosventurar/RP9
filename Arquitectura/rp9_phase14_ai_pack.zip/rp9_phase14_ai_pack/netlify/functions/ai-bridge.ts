
import type { Handler } from '@netlify/functions';

const AI_URL = process.env.AI_BACKEND_URL!;
const SECRET = process.env.AI_HMAC_SECRET || '';

function sign(body: string){
  // simple HMAC placeholder if needed in backend
  return ''; 
}

export const handler: Handler = async (event) => {
  try {
    if(event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };
    const { path, body } = JSON.parse(event.body||'{}');
    if(!path) return { statusCode: 400, body: 'path required' };
    const res = await fetch(AI_URL.replace(/\/$/,'') + path, {
      method:'POST',
      headers: { 'content-type':'application/json', 'x-rp9-sig': sign(JSON.stringify(body)) },
      body: JSON.stringify(body)
    });
    const j = await res.json().catch(()=> ({}));
    return { statusCode: res.status, body: JSON.stringify(j) };
  } catch (e:any) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) };
  }
}
