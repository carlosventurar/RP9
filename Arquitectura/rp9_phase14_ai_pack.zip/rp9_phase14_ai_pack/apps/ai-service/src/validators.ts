
import { z } from 'zod';

export const GenWorkflowSchema = z.object({
  tenantId: z.string().uuid().or(z.string().min(1)),
  natural: z.string().min(5),
  provider: z.enum(['auto','openai','anthropic']).optional(),
  byok: z.object({ provider: z.enum(['openai','anthropic']), apiKey: z.string().min(10) }).optional(),
  context: z.object({
    vertical: z.enum(['cc','fin']).optional(),
    priorFlows: z.array(z.object({ id: z.string(), name: z.string() })).optional()
  }).optional()
});

export const ExplainErrorSchema = z.object({
  tenantId: z.string().uuid().or(z.string().min(1)),
  executionId: z.string().optional(),
  logs: z.string().optional(),
  provider: z.enum(['auto','openai','anthropic']).optional(),
  byok: z.object({ provider: z.enum(['openai','anthropic']), apiKey: z.string().min(10) }).optional(),
}).refine(x => x.executionId || x.logs, { message: 'executionId o logs requerido' });

export const OptimizeSchema = z.object({
  tenantId: z.string().uuid().or(z.string().min(1)),
  workflowId: z.string(),
  provider: z.enum(['auto','openai','anthropic']).optional(),
  byok: z.object({ provider: z.enum(['openai','anthropic']), apiKey: z.string().min(10) }).optional(),
});

export const ApplySchema = z.object({
  tenantId: z.string().uuid().or(z.string().min(1)),
  userId: z.string().uuid().optional(),
  role: z.enum(['viewer','editor','admin']).default('viewer'),
  workflowId: z.string(),
  diff: z.any(),
  notes: z.string().optional()
});
