
import LRUCache from 'lru-cache';

export type Provider = 'openai'|'anthropic'|'auto';

export interface RouteInput {
  tenantId: string;
  prompt: string;
  system?: string;
  provider?: Provider;
  byok?: { provider: 'openai'|'anthropic', apiKey: string } | null;
  maxTokens?: number;
}

type RouteOutput = { text: string; provider: string; tokensIn?: number; tokensOut?: number; costUsd?: number };

const cache = new LRUCache<string, RouteOutput>({ max: 500, ttl: (parseInt(process.env.AI_CACHE_TTL_SEC||'600')*1000) });

function hash(s: string){ // simple hash (no-crypto) for cache keys
  let h=0; for (let i=0;i<s.length;i++){ h = (h<<5)-h + s.charCodeAt(i); h|=0; } return h.toString(16);
}

async function callOpenAI(prompt: string, system?: string, apiKey?: string): Promise<RouteOutput> {
  const key = apiKey || process.env.OPENAI_API_KEY;
  if(!key) throw new Error('OPENAI_API_KEY missing');
  const body = {
    model: 'gpt-4o-mini',
    messages: [
      ...(system ? [{role:'system', content: system}] : []),
      { role:'user', content: prompt }
    ],
    temperature: 0.2
  };
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'content-type':'application/json', 'authorization':`Bearer ${key}` },
    body: JSON.stringify(body)
  });
  if(!res.ok){ throw new Error('OpenAI error: '+res.status); }
  const j = await res.json();
  const text = j.choices?.[0]?.message?.content || '';
  const usage = j.usage || {};
  const costUsd = (usage.prompt_tokens||0)*0.00015 + (usage.completion_tokens||0)*0.0006; // approx for gpt-4o-mini
  return { text, provider: apiKey ? 'byok:openai' : 'openai', tokensIn: usage.prompt_tokens, tokensOut: usage.completion_tokens, costUsd };
}

async function callAnthropic(prompt: string, system?: string, apiKey?: string): Promise<RouteOutput> {
  const key = apiKey || process.env.ANTHROPIC_API_KEY;
  if(!key) throw new Error('ANTHROPIC_API_KEY missing');
  const body:any = {
    model: 'claude-3-haiku-20240307',
    max_tokens: 1024,
    messages: [{ role: 'user', content: prompt }],
  };
  if(system){ body.system = system; }
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type':'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify(body)
  });
  if(!res.ok){ throw new Error('Anthropic error: '+res.status); }
  const j = await res.json();
  const text = (j.content?.[0]?.text) || '';
  const usage = j.usage || {};
  const costUsd = (usage.input_tokens||0)*0.00025 + (usage.output_tokens||0)*0.00125; // approx haiku
  return { text, provider: apiKey ? 'byok:anthropic' : 'anthropic', tokensIn: usage.input_tokens, tokensOut: usage.output_tokens, costUsd };
}

export async function routeLLM(input: RouteInput): Promise<RouteOutput> {
  const keyBase = JSON.stringify({t: input.tenantId, p: input.prompt.slice(0,4000), s: input.system||'', prov: input.provider||'auto', byok: !!input.byok});
  const ck = 'ai:'+hash(keyBase);
  const cached = cache.get(ck);
  if(cached) return cached;

  const run = async () => {
    try {
      if(input.byok){
        // Prefer BYOK first
        if(input.byok.provider === 'openai') return await callOpenAI(input.prompt, input.system, input.byok.apiKey);
        if(input.byok.provider === 'anthropic') return await callAnthropic(input.prompt, input.system, input.byok.apiKey);
      }
      if(input.provider === 'openai') return await callOpenAI(input.prompt, input.system);
      if(input.provider === 'anthropic') return await callAnthropic(input.prompt, input.system);
      // auto: try openai then anthropic
      try { return await callOpenAI(input.prompt, input.system); } catch(e) { return await callAnthropic(input.prompt, input.system); }
    } catch(e){
      // last resort: other provider
      try {
        return await callAnthropic(input.prompt, input.system);
      } catch(_){
        throw e;
      }
    }
  };

  const out = await run();
  cache.set(ck, out);
  return out;
}
