
export function redactPII(input: string){
  // Very simple redaction (expand as needed)
  let out = input;
  out = out.replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi, '[email-token]');
  out = out.replace(/\+?\d[\d\s\-\(\)]{7,}\d/g, '[phone-token]');
  out = out.replace(/\b(?:\d[ -]*?){13,16}\b/g, '[card-token]');
  out = out.replace(/\b(?:RFC|NIT|CUIT)[:\s]*[A-Z0-9-]+/gi, '[taxid-token]');
  return out;
}
