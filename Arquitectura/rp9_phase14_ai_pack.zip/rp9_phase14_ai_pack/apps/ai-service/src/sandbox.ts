
/**
 * Sandbox runner for n8n: duplicates workflow into a temporary one with mock data,
 * runs once, captures issues, then deletes.
 * In a real impl, use the n8n API and a dedicated "sandbox" project.
 */
export async function dryRunN8n(workflowJSON: any, opts: { baseUrl: string, apiKey: string }){
  const base = opts.baseUrl.replace(/\/$/,'');
  const headers = { 'content-type':'application/json', 'X-N8N-API-KEY': opts.apiKey };
  // create
  const create = await fetch(`${base}/api/v1/workflows`, { method:'POST', headers, body: JSON.stringify(workflowJSON) });
  if(!create.ok) return { ok:false, error:'create_failed', status:create.status };
  const wf = await create.json();
  // execute
  const run = await fetch(`${base}/api/v1/workflows/${wf.id}/run`, { method:'POST', headers, body: JSON.stringify({}) });
  let issues: any = null;
  if(!run.ok){ issues = { code:'execution_failed', status: run.status }; }
  // delete
  await fetch(`${base}/api/v1/workflows/${wf.id}`, { method:'DELETE', headers });
  return { ok:true, issues };
}
