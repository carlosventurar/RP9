
import Fastify from 'fastify';
import rateLimit from 'fastify-rate-limit';
import { routeLLM } from './modelRouter.js';
import { redactPII } from './redact.js';
import { GenWorkflowSchema, ExplainErrorSchema, OptimizeSchema, ApplySchema } from './validators.js';
import { translateToN8nJSON } from './blueprint.js';
import { dryRunN8n } from './sandbox.js';

const app = Fastify({ logger: true });
await app.register(rateLimit, { max: 300, timeWindow: '1 minute' });

function hmacOk(req: any){
  // hook for HMAC if you front with ai-bridge
  return true;
}

function ensureBudget(tenantId: string){
  // TODO: check ai_budgets in Supabase; for now allow
  return { allowed: true, hardBlock: false };
}

app.get('/health', async ()=> ({ ok:true }));

app.post('/ai/generate-workflow', async (req, reply) => {
  if(!hmacOk(req)) return reply.code(401).send({ error:'bad_sig' });
  const parse = GenWorkflowSchema.safeParse(req.body);
  if(!parse.success) return reply.code(400).send({ error:'invalid', details: parse.error.flatten() });
  const { tenantId, natural, provider, byok, context } = parse.data;
  const budget = ensureBudget(tenantId); if(!budget.allowed) return reply.code(402).send({ error:'budget_exceeded' });

  const naturalRedacted = redactPII(natural);
  const system = 'Eres un asistente que produce un DSL simple (JSON) con source/transform/destination para integraciones típicas.';
  const out = await routeLLM({ tenantId, prompt: naturalRedacted, system, provider: provider||'auto', byok: byok||null });

  let blueprint: any;
  try { blueprint = JSON.parse(out.text); } catch { blueprint = { source:{type:'http',config:{}}, destination:{type:'http',config:{}}, transforms:[] }; }
  const wf = translateToN8nJSON(blueprint);

  const sandbox = await dryRunN8n(wf, { baseUrl: process.env.N8N_BASE_URL!, apiKey: process.env.N8N_API_KEY! });
  return { workflowJSON: wf, issues: sandbox.issues, cost_estimate: out.costUsd||0.0, provider: out.provider };
});

app.post('/ai/explain-error', async (req, reply) => {
  const parse = ExplainErrorSchema.safeParse(req.body);
  if(!parse.success) return reply.code(400).send({ error:'invalid', details: parse.error.flatten() });
  const { tenantId, executionId, logs, provider, byok } = parse.data;
  const input = `Diagnostica el error en este flujo. Devuelve JSON con {root_cause, impacted_nodes:[{name,reason}], patch_suggestion:{...}}. Logs:\n`+(logs||`executionId=${executionId}`);
  const out = await routeLLM({ tenantId, prompt: redactPII(input), provider: provider||'auto', byok: byok||null });
  let obj:any = {}; try { obj = JSON.parse(out.text); } catch { obj = { root_cause: 'unknown', impacted_nodes:[], patch_suggestion:{} }; }
  return { ...obj, provider: out.provider };
});

app.post('/ai/optimize', async (req, reply) => {
  const parse = OptimizeSchema.safeParse(req.body);
  if(!parse.success) return reply.code(400).send({ error:'invalid', details: parse.error.flatten() });
  const { tenantId, workflowId, provider, byok } = parse.data;
  const prompt = `Analiza el workflow ${workflowId}. Propón optimizaciones (batching, caching, retry-jitter, concurrencia) y devuelve un PATCH JSON aplicable.`;
  const out = await routeLLM({ tenantId, prompt, provider: provider||'auto', byok: byok||null });
  let patch:any = {}; try { patch = JSON.parse(out.text); } catch { patch = {}; }
  return { workflowId, patch, provider: out.provider };
});

app.post('/ai/apply', async (req, reply) => {
  const parse = ApplySchema.safeParse(req.body);
  if(!parse.success) return reply.code(400).send({ error:'invalid', details: parse.error.flatten() });
  const { role, workflowId, diff } = parse.data;
  if(!(role==='admin' || role==='editor')) return reply.code(403).send({ error:'forbidden' });
  // Persist PR (diff) in Supabase (omitted here)
  // Apply with n8n PATCH
  const res = await fetch(`${process.env.N8N_BASE_URL!.replace(/\/$/,'')}/api/v1/workflows/${workflowId}`, {
    method:'PATCH', headers:{ 'content-type':'application/json', 'X-N8N-API-KEY': process.env.N8N_API_KEY! }, body: JSON.stringify(diff)
  });
  if(!res.ok) return reply.code(502).send({ error:'n8n_patch_failed', status: res.status });
  const data = await res.json();
  return { ok:true, data };
});

const port = parseInt(process.env.PORT || '8787', 10);
app.listen({ port, host:'0.0.0.0' }).then(()=> app.log.info('AI service up on '+port));
