
/**
 * Very small DSL:
 * {
 *   source: { type: 'hubspot'|'http'|'webhook'|'sheets', config: {...} },
 *   transforms?: [{ type:'map'|'filter'|'batch', config:{} }],
 *   destination: { type:'sheets'|'whatsapp'|'http'|'crm', config:{} }
 * }
 */
type Node = any;

export function translateToN8nJSON(blueprint: any){
  const nodes: Node[] = [];
  const connections: any = {};

  // Manual trigger (for dry-run/testing)
  const manual = { id:'1', name:'Manual Trigger', type:'n8n-nodes-base.manualTrigger', typeVersion:1, position:[0,0], parameters:{} };
  nodes.push(manual);

  // Example mapping for source
  let srcId = '2', srcName = 'HTTP Request';
  if(blueprint?.source?.type === 'http'){
    nodes.push({ id:srcId, name:srcName, type:'n8n-nodes-base.httpRequest', typeVersion:4, position:[280,0],
      parameters:{ method: blueprint.source.config?.method || 'GET', url: blueprint.source.config?.url || 'https://httpbin.org/get' } });
  } else if(blueprint?.source?.type === 'hubspot'){
    srcName = 'HubSpot Trigger';
    nodes.push({ id:srcId, name:srcName, type:'n8n-nodes-base.hubspotTrigger', typeVersion:1, position:[280,0], parameters:{} });
  } else {
    // default to webhook
    srcName = 'Webhook';
    nodes.push({ id:srcId, name:srcName, type:'n8n-nodes-base.webhook', typeVersion:1, position:[280,0], parameters:{}});
  }
  // connect manual -> source for dry run
  connections[manual.name] = { main: [[{ node: srcName, type:'main', index:0 }]] };

  // Transforms
  let lastName = srcName, x=560, idx=3;
  for(const t of (blueprint.transforms||[])){
    const name = `Transform_${t.type}`;
    nodes.push({ id:String(idx++), name, type:'n8n-nodes-base.code', typeVersion:2, position:[x,0], parameters:{ language:'javascript', jsCode:'return items;' } });
    connections[lastName] = { main: [[{ node: name, type:'main', index:0 }]] };
    lastName = name; x+=280;
  }

  // Destination
  let destName = 'HTTP Request';
  if(blueprint?.destination?.type === 'sheets'){
    destName = 'Google Sheets';
    nodes.push({ id:String(idx++), name:destName, type:'n8n-nodes-base.googleSheets', typeVersion:4, position:[x,0], parameters:{ operation:'append' } });
  } else if(blueprint?.destination?.type === 'whatsapp'){
    destName = 'HTTP Request';
    nodes.push({ id:String(idx++), name:destName, type:'n8n-nodes-base.httpRequest', typeVersion:4, position:[x,0], parameters:{ method:'POST', url:'https://graph.facebook.com/v17.0/...' } });
  } else {
    nodes.push({ id:String(idx++), name:destName, type:'n8n-nodes-base.httpRequest', typeVersion:4, position:[x,0], parameters:{ method:'POST', url:'https://httpbin.org/post' } });
  }
  connections[lastName] = { main: [[{ node: destName, type:'main', index:0 }]] };

  return { name: 'AI Generated Flow', active:false, nodes, connections, settings: { saveDataErrorExecution: 'all' } };
}
