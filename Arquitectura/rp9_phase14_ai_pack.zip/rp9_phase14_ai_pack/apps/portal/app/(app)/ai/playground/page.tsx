
'use client';
import { useState } from 'react';

export default function AIPlaygroundPage(){
  const [natural,setNatural]=useState('Sincroniza leads de HubSpot a Sheets y envía WhatsApp CSAT');
  const [res,setRes]=useState<any>(null);
  async function run(){
    const payload = { path:'/ai/generate-workflow', body:{ tenantId:'default', natural } };
    const r = await fetch('/.netlify/functions/ai-bridge',{ method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify(payload) });
    const j = await r.json(); setRes(j);
  }
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">AI Playground</h1>
      <textarea className="w-full h-32 border rounded-lg p-2" value={natural} onChange={e=>setNatural(e.target.value)} />
      <button className="px-3 py-2 rounded-lg bg-blue-600 text-white" onClick={run}>Generar</button>
      <pre className="text-xs bg-slate-100 p-3 rounded-lg overflow-auto">{JSON.stringify(res,null,2)}</pre>
    </div>
  );
}
