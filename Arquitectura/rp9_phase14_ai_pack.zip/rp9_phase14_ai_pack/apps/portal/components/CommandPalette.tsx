
'use client';
import { useEffect, useState } from 'react';

export function CommandPalette(){
  const [open, setOpen] = useState(false);
  useEffect(()=>{
    const onKey = (e: KeyboardEvent) => {
      if((e.ctrlKey || e.metaKey) && e.key.toLowerCase()==='k'){ e.preventDefault(); setOpen(v=>!v); }
      if(e.key === '/') { setOpen(true); }
    };
    window.addEventListener('keydown', onKey);
    return ()=> window.removeEventListener('keydown', onKey);
  }, []);
  if(!open) return null;
  const actions = [
    { key:'gen', label:'Generar flujo con IA' },
    { key:'opt', label:'Optimizar flujo actual' },
    { key:'exp', label:'Explicar error último run' }
  ];
  return (
    <div className="fixed inset-0 bg-black/30 z-50 grid place-items-start p-8">
      <div className="w-full max-w-xl mx-auto rounded-2xl bg-white p-4 space-y-2 shadow-xl">
        <input autoFocus placeholder="Escribe un comando…" className="w-full border px-3 py-2 rounded-lg" />
        <div className="divide-y border rounded-lg">
          {actions.map(a=> <button key={a.key} className="w-full text-left px-3 py-2 hover:bg-slate-50">{a.label}</button>)}
        </div>
        <div className="text-xs text-slate-500">Atajos: <kbd>⌘K</kbd> / <kbd>Ctrl K</kbd> o <kbd>/</kbd></div>
      </div>
    </div>
  );
}
