
'use client';
import { useState } from 'react';

export function FixWithAIButton({ executionId }:{ executionId: string }){
  const [loading,setLoading]=useState(false);
  const [diff,setDiff]=useState<any|null>(null);
  async function suggest(){
    setLoading(true);
    const r = await fetch('/.netlify/functions/ai-bridge', { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ path:'/ai/explain-error', body: { tenantId:'default', executionId } }) });
    const j = await r.json(); setDiff(j.patch_suggestion||null); setLoading(false);
  }
  async function apply(){
    if(!diff) return;
    const r = await fetch('/.netlify/functions/ai-bridge', { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ path:'/ai/apply', body: { tenantId:'default', workflowId: diff.workflowId, diff, role:'admin' } }) });
    const j = await r.json(); alert(j.ok ? 'Aplicado' : 'Error');
  }
  return (
    <div className="flex items-center gap-2">
      <button className="px-3 py-2 rounded-lg bg-blue-600 text-white" onClick={suggest} disabled={loading}>{loading? 'Pensando…' : 'Fix con IA'}</button>
      {diff && <button className="px-3 py-2 rounded-lg bg-emerald-600 text-white" onClick={apply}>Aplicar</button>}
    </div>
  );
}
