create table if not exists ai_usage (
  id bigserial primary key,
  created_at timestamptz default now(),
  tenant_id uuid not null,
  user_id uuid,
  provider text not null,           -- openai|anthropic|byok:openai
  tokens_in int default 0,
  tokens_out int default 0,
  cost_usd numeric(10,4) default 0,
  latency_ms int,
  action text not null,             -- generate|explain|optimize|apply
  accepted boolean,
  meta jsonb default '{}'
);
create index on ai_usage (tenant_id, created_at desc);

create table if not exists ai_budgets (
  tenant_id uuid primary key,
  monthly_usd numeric(10,2) not null default 20,
  spent_usd numeric(10,2) not null default 0,
  hard_limit_behavior text not null default 'warn' -- block|warn
);

create table if not exists ai_prs (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  tenant_id uuid not null,
  user_id uuid,
  workflow_id text not null,
  diff jsonb not null,              -- patch JSON (antes/después)
  status text not null default 'pending', -- pending|applied|reverted
  notes text
);
create index on ai_prs (tenant_id, created_at desc);

create table if not exists ai_prompts (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  tenant_id uuid not null,
  name text not null,
  body text not null,
  meta jsonb default '{}'
);

create table if not exists ai_flags (
  tenant_id uuid primary key,
  auto_fix_enabled boolean default false,
  profiler_enabled boolean default true,
  playground_enabled boolean default true
);

-- Habilitar RLS y políticas mínimas según tu esquema de auth
-- alter table ai_usage enable row level security;
-- ... (políticas según roles)