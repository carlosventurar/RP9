# RP9 — Fase 14 AI Assistant Pack

Este paquete contiene el **servicio de IA**, componentes de portal y migraciones SQL para lanzar el **AI Assistant** con:
- Generación de flujos (blueprint → n8n JSON)
- Explicación de errores con **Fix 1‑click**
- Profiler/Optimización con recomendaciones
- BYOK + multi‑proveedor + caché + presupuestos

**n8n base:** https://primary-production-7f25.up.railway.app (ajusta la KEY en `.env`).

## Estructura
- `apps/ai-service/` Fastify (TS)
- `apps/portal/components/` Command Palette + FixWithAI
- `apps/portal/app/(app)/ai/playground/` Playground
- `infra/supabase/migrations/50_ai.sql` Tablas
- `netlify/functions/ai-bridge.ts` Proxy opcional

## Arranque rápido
```bash
cd apps/ai-service
cp .env.example .env # configura OPENAI/ANTHROPIC/N8N/SUPABASE
npm i
npm run dev
# En portal, llama a /.netlify/functions/ai-bridge con {{path:'/ai/...'}} 
```

## Seguridad
- Redacción de PII antes de enviar al LLM.
- Dry‑run en sandbox (no producción) al generar.
- RBAC + flags por plan en `/ai/apply`.

## Licencia
Uso interno RP9 (work-in-progress).
