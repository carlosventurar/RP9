// web/app/flows/new/page.tsx
'use client';
import React, { useState } from 'react';
import ReactFlow, { Background, Controls, addEdge, MiniMap, Connection, Edge, Node } from 'reactflow';
import 'reactflow/dist/style.css';
import axios from 'axios';

const initialNodes: Node[] = [
  { id: 'manual', position: { x: 0, y: 0 }, data: { label: 'Manual Trigger' }, type: 'input' },
  { id: 'http', position: { x: 280, y: 0 }, data: { label: 'HTTP Request' }, type: 'default' },
];
const initialEdges: Edge[] = [];

export default function NewFlowPage() {
  const [nodes, setNodes] = useState<Node[]>(initialNodes);
  const [edges, setEdges] = useState<Edge[]>(initialEdges);
  const [name, setName] = useState('RP9 – Demo Flow');
  const onConnect = (c: Connection) => setEdges((eds) => addEdge(c, eds));

  function toN8nJSON() {
    const nodeById: Record<string, any> = {};
    for (const n of nodes) {
      if (n.id === 'manual') nodeById[n.id] = { id:'1', name:'Manual Trigger', type:'n8n-nodes-base.manualTrigger', typeVersion:1, position:[n.position.x,n.position.y], parameters:{} };
      if (n.id === 'http') nodeById[n.id] = { id:'2', name:'HTTP Request', type:'n8n-nodes-base.httpRequest', typeVersion:4, position:[n.position.x,n.position.y], parameters:{ url:'https://httpbin.org/get', method:'GET' } };
    }
    const connections:any = {};
    for (const e of edges) {
      const src = nodeById[e.source]?.name, tgt = nodeById[e.target]?.name; if (!src||!tgt) continue;
      connections[src] = connections[src] || { main:[[]] };
      connections[src].main[0].push({ node: tgt, type:'main', index:0 });
    }
    return { name, active:false, nodes:Object.values(nodeById), connections, settings:{ saveDataErrorExecution:'all' } };
  }

  async function save() {
    const workflow = toN8nJSON();
    const { data } = await axios.post('/api/workflows', { workflow });
    alert('Creado/actualizado: ' + (data?.id || 'ok'));
  }

  return (
    <div className="p-4">
      <div className="flex gap-2 items-center mb-3">
        <input className="border px-2 py-1 rounded w-80" value={name} onChange={e=>setName(e.target.value)} />
        <button className="px-3 py-2 rounded bg-black text-white" onClick={save}>Guardar en n8n</button>
      </div>
      <div style={{ height: 520, border: '1px solid #eee', borderRadius: 8 }}>
        <ReactFlow nodes={nodes} edges={edges} onNodesChange={setNodes as any} onEdgesChange={setEdges as any} onConnect={onConnect}>
          <MiniMap /><Controls /><Background />
        </ReactFlow>
      </div>
    </div>
  );
}