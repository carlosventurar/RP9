// server/index.js
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const axios = require('axios');
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb', verify:(req, res, buf)=>{ req.rawBody = buf; } }));
app.use(morgan('tiny'));
app.use(rateLimit({ windowMs: 60_000, max: 300 }));

const PORT = process.env.PORT || 4000;
const N8N_BASE_URL = (process.env.N8N_BASE_URL || '').replace(/\/$/, '');
const N8N_API_KEY = process.env.N8N_API_KEY || '';

function api() {
  return axios.create({
    baseURL: `${N8N_BASE_URL}/api/v1`,
    headers: { 'X-N8N-API-KEY': N8N_API_KEY, 'accept': 'application/json' },
    timeout: 15000,
  });
}

function verifyHmac(req, secret) {
  const sig = req.header('x-rp9-signature') || '';
  const mac = crypto.createHmac('sha256', secret).update(req.rawBody || '').digest('hex');
  try { return crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(mac)); } catch { return false; }
}

// Listar workflows
app.get('/api/workflows', async (req, res) => {
  try { const { data } = await api().get('/workflows', { params: { limit: 250 } }); res.json(data); }
  catch (e) { res.status(e.response?.status||500).json({ error: e.message, details: e.response?.data }); }
});

// Upsert workflow por name
app.post('/api/workflows', async (req, res) => {
  try {
    const wf = req.body?.workflow;
    if (!wf?.name || !Array.isArray(wf?.nodes)) return res.status(400).json({ error: 'workflow inválido' });
    const list = await api().get('/workflows', { params: { limit: 250 } });
    const existing = (list.data?.data||[]).find(w => w.name === wf.name);
    const out = existing ? await api().patch(`/workflows/${existing.id}`, wf) : await api().post(`/workflows`, wf);
    res.json(out.data);
  } catch (e) {
    res.status(e.response?.status||500).json({ error: e.message, details: e.response?.data });
  }
});

// Ejecutions (para métricas)
app.get('/api/executions', async (req, res) => {
  try { const { data } = await api().get('/executions', { params: req.query }); res.json(data); }
  catch (e) { res.status(e.response?.status||500).json({ error: e.message, details: e.response?.data }); }
});

app.listen(PORT, () => console.log('RP9 BFF on :' + PORT));