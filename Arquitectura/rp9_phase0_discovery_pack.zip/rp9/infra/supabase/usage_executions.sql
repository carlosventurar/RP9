-- usage por ejecución (metered)
create table if not exists usage_executions (
  id bigserial primary key,
  tenant text not null,
  workflow_id text not null,
  execution_id text unique,
  status text not null,           -- success|error|waiting
  started_at timestamptz,
  stopped_at timestamptz,
  duration_ms bigint,
  created_at timestamptz default now()
);
create index if not exists idx_usage_tenant_time on usage_executions (tenant, created_at desc);