
# RP9 — Fase 0: Discovery & Starter
Este paquete incluye:
- `docs/decisions.json` y `docs/qna.csv` (resumen de decisiones pre‑Fase 1).
- `apps/bff` (Express) y `apps/portal` (Next.js) esqueletos mínimos.
- `infra/supabase` con la tabla `usage_executions`.

## Pasos
1) Copia `.env.example` y configura N8N.
2) Arranca BFF y portal (local o Netlify).
3) Ejecuta la SQL en Supabase.
4) Usa el mini‑builder para crear tu primer workflow y guardarlo en n8n.
