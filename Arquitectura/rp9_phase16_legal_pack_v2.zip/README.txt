RP9 Phase 16 – Legal & Contracts Pack
Date: 2025-08-11

How to use:
1) Import 'infra/supabase/migrations/96_legal.sql' into Supabase.
2) Deploy Netlify functions in 'apps/functions'.
3) Place 'content/legal' into your repo (Next.js portal) and expose routes under /legal/*.
4) Update .env with your SUPABASE and STRIPE keys.
