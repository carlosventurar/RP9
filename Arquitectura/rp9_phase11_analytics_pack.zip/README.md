# RP9 — Fase 11: Analítica & Reporting

Este paquete contiene el **prompt para Claude Code**, migraciones **SQL**, esqueletos de **Netlify Functions** y configuración para crons/entorno.

## Estructura
```
rp9_phase11_analytics_pack/
  RP9_Fase11_Analitica_Reporting.md
  README.md
  .env.example
  netlify.toml
  content/metrics.yml
  infra/supabase/migrations/40_analytics.sql
  functions/
    analytics-ingest.ts
    analytics-collector.ts
    analytics-aggregate.ts
    analytics-kpis.ts
    analytics-alerts.ts
    analytics-report.ts
    analytics-export.ts
```

## Pasos rápidos
1. Crea variables de entorno (`.env`) a partir de `.env.example`.
2. Aplica migración `40_analytics.sql` en Supabase.
3. Despliega **Netlify Functions** y **netlify.toml** con los crons.
4. Pega el **Master Prompt** del archivo `.md` en **Claude Code** para que genere UI y código restante.
5. Verifica dashboards `/api/analytics/kpis` y páginas `/analytics/*`.

> n8n base: `https://primary-production-7f25.up.railway.app`.
