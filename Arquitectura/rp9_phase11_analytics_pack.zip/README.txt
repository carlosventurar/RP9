
RP9 — Fase 11 (Analítica & Reporting)
====================================

1) Supabase
-----------
- Ejecuta `infra/supabase/migrations/60_analytics.sql`.
- Crea función RPC para refresh MVs (ver comentario en `analytics-refresh-mv.ts`).

2) Netlify Functions
--------------------
- Copia `apps/functions/*` y configura `.env` (service role, HMAC, Slack).
- Programa:
  - `analytics-refresh-mv` cada 30–60 min.
  - `analytics-anomaly-watch` cada 5–10 min.
- En el portal, enlaza páginas en `/analytics/executive`, `/analytics/ops`, `/analytics/finance`.

3) Eventos
----------
- Envía eventos a `/.netlify/functions/analytics-track` con HMAC (opcional).
- Normaliza `outcome.achieved` para calcular TTV/NSM/Adopción.

4) Notas
--------
- `mv_north_star_monthly` asume costo/hora default (env/tenants.metadata).
- Adopción por pack infiere prefijos `CC-`/`FIN-`; ajusta mapeo según tu catálogo.
