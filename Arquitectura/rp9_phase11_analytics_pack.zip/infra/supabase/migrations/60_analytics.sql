
-- 60_analytics.sql
-- Tablas base
create table if not exists analytics_events (
  id bigserial primary key,
  created_at timestamptz default now(),
  tenant_id uuid not null,
  user_id uuid,
  session_id text,
  source text not null,                 -- portal|bff|n8n
  event text not null,                  -- signup|flow.installed|execution.success|execution.error|outcome.achieved|...
  properties jsonb default '{}'::jsonb,
  occurred_at timestamptz not null
);
create index if not exists idx_ae_tenant_time on analytics_events(tenant_id, occurred_at desc);
create index if not exists idx_ae_event on analytics_events(event);

-- Outcomes de negocio (normalizados)
create table if not exists business_outcomes (
  id bigserial primary key,
  created_at timestamptz default now(),
  tenant_id uuid not null,
  workflow_id text,
  outcome_type text not null,           -- ticket.created|cfdi.validated|payment.reconciled|message.sent|...
  value numeric,                        -- opcional (USD u otra unidad)
  occurred_at timestamptz not null,
  meta jsonb default '{}'::jsonb
);
create index if not exists idx_bo_tenant_time on business_outcomes(tenant_id, occurred_at desc);

-- Overrides por cliente para horas ahorradas
create table if not exists hours_overrides (
  id bigserial primary key,
  created_at timestamptz default now(),
  tenant_id uuid not null,
  workflow_id text,
  minutes_saved_per_event int not null check (minutes_saved_per_event >= 0),
  effective_from date default now()
);

-- Metadata por plantilla (catálogo) – minutos ahorrados default
create table if not exists template_savings_catalog (
  id uuid primary key default gen_random_uuid(),
  template_code text unique not null,   -- CC‑001, FIN‑002, etc.
  minutes_saved_per_event int not null check (minutes_saved_per_event >= 0),
  last_updated timestamptz default now()
);

-- Tabla de espejo mínima de ejecuciones (si no existe de fases previas)
create table if not exists usage_executions (
  id bigserial primary key,
  tenant_id uuid not null,
  workflow_id text not null,
  execution_id text unique,
  status text not null,                 -- success|error|waiting
  started_at timestamptz,
  stopped_at timestamptz,
  duration_ms bigint,
  created_at timestamptz default now()
);
create index if not exists idx_ux_tenant_time on usage_executions(tenant_id, created_at desc);

-- ============================
-- Vistas materializadas
-- ============================

-- 1) TTV: tiempo desde signup hasta primer outcome por tenant (y cohort semanal/mensual)
-- Requiere evento 'signup' y 'outcome.achieved'
create materialized view if not exists mv_ttv_tenant as
with signups as (
  select tenant_id, min(occurred_at) as signup_at
  from analytics_events
  where event = 'signup'
  group by tenant_id
), first_outcome as (
  select tenant_id, min(occurred_at) as first_outcome_at
  from business_outcomes
  group by tenant_id
)
select s.tenant_id,
       s.signup_at,
       f.first_outcome_at,
       extract(epoch from (f.first_outcome_at - s.signup_at))/3600.0 as ttv_hours,
       date_trunc('week', s.signup_at)::date as cohort_week,
       date_trunc('month', s.signup_at)::date as cohort_month
from signups s
left join first_outcome f using (tenant_id);

create index if not exists idx_mtt_cohorts on mv_ttv_tenant(cohort_week, cohort_month);

-- 2) North Star: horas y USD ahorrados por mes/tenant
-- Estima minutos por evento usando override -> template -> fallback 3 min
create materialized view if not exists mv_north_star_monthly as
with execs as (
  select ue.tenant_id, ue.workflow_id, date_trunc('month', coalesce(ue.stopped_at, ue.created_at))::date as month,
         count(*) filter (where ue.status='success') as events
  from usage_executions ue
  group by 1,2,3
),
mins as (
  select e.tenant_id, e.workflow_id, e.month, e.events,
         coalesce(o.minutes_saved_per_event,
                  (tc.minutes_saved_per_event),
                  3) as minutes_per_event
  from execs e
  left join hours_overrides o on o.tenant_id=e.tenant_id and (o.workflow_id is null or o.workflow_id=e.workflow_id)
  left join template_savings_catalog tc on tc.template_code = e.workflow_id -- si el workflow_id usa code del catálogo
),
agg as (
  select tenant_id, month,
         sum(events * minutes_per_event) as minutes_saved_total
  from mins
  group by 1,2
)
select tenant_id, month,
       minutes_saved_total,
       round(minutes_saved_total/60.0,2) as hours_saved_total,
       -- Para USD: definir costo/hora por tenant; por ahora 10 USD/h como default
       round((minutes_saved_total/60.0) * coalesce((select (metadata->>'hourly_cost_usd')::numeric from tenants t where t.id=agg.tenant_id), 10), 2) as usd_saved_estimated
from agg;

create index if not exists idx_nsm_month on mv_north_star_monthly(month);

-- 3) Adopción por pack (mensual): uso + outcome
-- pack: inferido de prefix en workflow_id (CC-, FIN-, etc.) o mapping aparte
create materialized view if not exists mv_adoption_pack_monthly as
with wf as (
  select tenant_id,
         date_trunc('month', coalesce(stopped_at, created_at))::date as month,
         workflow_id,
         case when workflow_id ilike 'CC-%' then 'CC'
              when workflow_id ilike 'FIN-%' then 'FIN'
              else 'GEN' end as pack,
         count(*) filter (where status='success') as exec_ok
  from usage_executions
  group by 1,2,3
),
outc as (
  select tenant_id,
         date_trunc('month', occurred_at)::date as month,
         case when outcome_type ilike 'ticket.%' then 'CC'
              when outcome_type ilike 'cfdi.%' or outcome_type ilike 'dian.%' then 'FIN'
              else 'GEN' end as pack,
         count(*) as outcomes
  from business_outcomes
  group by 1,2,3
)
select coalesce(wf.tenant_id, outc.tenant_id) as tenant_id,
       coalesce(wf.month, outc.month) as month,
       coalesce(wf.pack, outc.pack) as pack,
       sum(coalesce(wf.exec_ok,0)) as executions,
       sum(coalesce(outc.outcomes,0)) as outcomes,
       (sum(coalesce(wf.exec_ok,0)) >= 30 and sum(coalesce(outc.outcomes,0)) >= 1) as adopted
from wf
full outer join outc on wf.tenant_id=outc.tenant_id and wf.month=outc.month and wf.pack=outc.pack
group by 1,2,3;

create index if not exists idx_apm_month on mv_adoption_pack_monthly(month, pack);

-- 4) Data Health (lag comparando eventos esperados vs recibidos por tenant/día)
create materialized view if not exists mv_data_health_daily as
select tenant_id,
       date_trunc('day', occurred_at)::date as day,
       count(*) filter (where event like 'execution.%') as exec_events,
       count(*) filter (where event like 'outcome.%') as outcome_events
from analytics_events
group by 1,2;

-- Notas:
--   REFRESH MATERIALIZED VIEW mv_ttv_tenant;
--   REFRESH MATERIALIZED VIEW mv_north_star_monthly;
--   REFRESH MATERIALIZED VIEW mv_adoption_pack_monthly;
--   REFRESH MATERIALIZED VIEW mv_data_health_daily;
