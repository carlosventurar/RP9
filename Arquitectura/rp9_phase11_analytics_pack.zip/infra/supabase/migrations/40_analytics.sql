
-- 40_analytics.sql — RP9 Fase 11 (Analítica & Reporting)

-- 1) Eventos de Funnel
create table if not exists funnel_events (
  id bigserial primary key,
  tenant_id uuid not null,
  user_id uuid,
  session_id uuid,
  step text not null,            -- signup, connect_data, install_template, first_run, first_outcome
  meta jsonb default '{}',
  occurred_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create index if not exists idx_funnel_tenant_time on funnel_events(tenant_id, occurred_at desc);
create index if not exists idx_funnel_step on funnel_events(step);

-- 2) Outcomes (primera victoria y subsecuentes)
create table if not exists outcomes (
  id bigserial primary key,
  tenant_id uuid not null,
  user_id uuid,
  workflow_id text,
  pack text,                     -- cc|fin|otros
  kind text not null,            -- ticket.created | cfdi.validated | message.sent | etc
  value_numeric numeric,         -- opcional (monto, score, etc)
  meta jsonb default '{}',
  occurred_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create index if not exists idx_outcomes_tenant_time on outcomes(tenant_id, occurred_at desc);
create index if not exists idx_outcomes_kind on outcomes(kind);

-- 3) Baselines de ahorro
create table if not exists savings_baseline (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  workflow_id text not null,
  minutes_per_event numeric not null default 3,
  hourly_cost numeric not null default 10,
  updated_at timestamptz default now()
);
create unique index if not exists uq_savings_tenant_workflow on savings_baseline(tenant_id, workflow_id);

-- 4) Metadatos de Plantillas (default minutos/evento)
create table if not exists templates_metadata (
  workflow_key text primary key,
  default_minutes numeric not null default 3,
  pack text,
  meta jsonb default '{}'
);

-- 5) Usage/executions (si no existe ya, referencial)
create table if not exists usage_executions (
  id bigserial primary key,
  tenant_id uuid not null,
  workflow_id text not null,
  execution_id text unique,
  status text,
  started_at timestamptz,
  stopped_at timestamptz,
  duration_ms bigint,
  created_at timestamptz default now()
);
create index if not exists idx_usage_tenant_time on usage_executions(tenant_id, created_at desc);
create index if not exists idx_usage_workflow on usage_executions(workflow_id);

-- 6) Rollups diarios/mensuales
create table if not exists kpi_rollups_daily (
  day date not null,
  tenant_id uuid not null,
  executions_success int default 0,
  executions_error int default 0,
  p95_ms bigint default 0,
  hours_saved numeric default 0,
  roi_usd numeric default 0,
  outcomes_count int default 0,
  primary key(day, tenant_id)
);

create table if not exists kpi_rollups_monthly (
  month date not null,
  tenant_id uuid not null,
  executions_success int default 0,
  executions_error int default 0,
  p95_ms bigint default 0,
  hours_saved numeric default 0,
  roi_usd numeric default 0,
  outcomes_count int default 0,
  primary key(month, tenant_id)
);

-- 7) Vistas materializadas

-- a) Funnels diarios
create materialized view if not exists mv_funnels_daily as
select
  date_trunc('day', occurred_at)::date as day,
  tenant_id,
  step,
  count(*) as events
from funnel_events
group by 1,2,3;

create index if not exists idx_mv_funnels_daily on mv_funnels_daily(day, tenant_id, step);

-- b) Cohorts TTV semanales
-- Suponemos que la "primera victoria" es el primer outcome por usuario/tenant
create materialized view if not exists mv_ttv_cohorts_weekly as
with signups as (
  select tenant_id, user_id, min(occurred_at) as signup_at
  from funnel_events
  where step = 'signup'
  group by 1,2
),
first_outcome as (
  select tenant_id, user_id, min(occurred_at) as first_outcome_at
  from outcomes
  group by 1,2
)
select
  s.tenant_id,
  date_trunc('week', s.signup_at)::date as cohort_week,
  extract(epoch from (fo.first_outcome_at - s.signup_at))/3600.0 as ttv_hours
from signups s
join first_outcome fo
  on fo.tenant_id = s.tenant_id and fo.user_id = s.user_id;

create index if not exists idx_mv_ttv_cohorts_weekly on mv_ttv_cohorts_weekly(cohort_week, tenant_id);

-- c) Adopción por pack (uso + outcome)
create materialized view if not exists mv_adoption_pack as
with use_last_30 as (
  select tenant_id, coalesce(o.pack, 'unknown') as pack,
         count(*) filter (where ue.status='success') as runs,
         count(distinct ue.workflow_id) as workflows_active
  from usage_executions ue
  left join outcomes o on o.workflow_id = ue.workflow_id and o.tenant_id = ue.tenant_id
  where ue.created_at > now() - interval '30 days'
  group by 1,2
),
outcome_signal as (
  select tenant_id, coalesce(pack, 'unknown') as pack,
         count(*) as outcomes_30d
  from outcomes
  where occurred_at > now() - interval '30 days'
  group by 1,2
)
select
  u.tenant_id, u.pack,
  u.workflows_active,
  u.runs,
  coalesce(o.outcomes_30d,0) as outcomes_30d,
  case when u.workflows_active >= 2 and u.runs >= 30 and coalesce(o.outcomes_30d,0) > 0
       then 1.0 else 0.0 end as adoption_signal
from use_last_30 u
left join outcome_signal o
  on o.tenant_id = u.tenant_id and o.pack = u.pack;

create index if not exists idx_mv_adoption_pack on mv_adoption_pack(tenant_id, pack);

-- d) NSM (ROI USD) — horas ahorradas * costo hora
create materialized view if not exists mv_nsm_usd as
with durations as (
  select tenant_id, workflow_id, date_trunc('month', created_at)::date as month,
         count(*) filter (where status='success') as success_count
  from usage_executions
  group by 1,2,3
),
minutes as (
  select d.tenant_id, d.workflow_id, d.month,
         coalesce(sb.minutes_per_event, tm.default_minutes) as minutes_per_event,
         coalesce(sb.hourly_cost, 10) as hourly_cost
  from durations d
  left join savings_baseline sb on sb.tenant_id=d.tenant_id and sb.workflow_id=d.workflow_id
  left join templates_metadata tm on tm.workflow_key=d.workflow_id
)
select
  d.month, d.tenant_id,
  sum( (m.minutes_per_event/60.0) * d.success_count ) as hours_saved,
  sum( (m.minutes_per_event/60.0) * d.success_count * m.hourly_cost ) as roi_usd
from durations d
join minutes m on m.tenant_id=d.tenant_id and m.workflow_id=d.workflow_id and m.month=d.month
group by 1,2;

create index if not exists idx_mv_nsm_usd on mv_nsm_usd(month, tenant_id);

-- 8) RLS (asume tabla tenants y sesión con tenant_id en JWT o claims)
alter table funnel_events enable row level security;
alter table outcomes enable row level security;
alter table savings_baseline enable row level security;
alter table usage_executions enable row level security;
alter table kpi_rollups_daily enable row level security;
alter table kpi_rollups_monthly enable row level security;

-- Políticas ejemplo (ajustar a tu esquema de auth)
do $$ begin
  -- Evitar error si ya existen
  begin
    create policy tenant_read_funnel on funnel_events for select using (true);
  exception when duplicate_object then null; end;

  begin
    create policy tenant_read_outcomes on outcomes for select using (true);
  exception when duplicate_object then null; end;

  begin
    create policy tenant_read_usage on usage_executions for select using (true);
  exception when duplicate_object then null; end;
end $$;

-- Nota: En producción, reemplaza (true) por condición como:
-- current_setting('request.jwt.claims', true)::jsonb->>'tenant_id' = tenant_id::text
