
import { Handler } from '@netlify/functions'

const SB = { url: process.env.SUPABASE_URL!, key: process.env.SUPABASE_SERVICE_ROLE_KEY! }
function ok(body:any){ return { statusCode: 200, body: JSON.stringify(body) } }
function bad(code:number,msg:string){ return { statusCode: code, body: msg } }

async function sbSelect(path:string){
  const r = await fetch(`${SB.url}/rest/v1/${path}`, { headers:{ 'apikey':SB.key,'Authorization':`Bearer ${SB.key}` } })
  if (!r.ok) throw new Error(await r.text())
  return r.json()
}

export const handler: Handler = async (event) => {
  try {
    const tenantId = event.queryStringParameters?.tenant_id || ''
    const q = (p:string)=> tenantId ? `${p}?tenant_id=eq.${tenantId}` : p
    const [ttv, ns, adopt] = await Promise.all([
      sbSelect(q('mv_ttv_tenant')),
      sbSelect(q('mv_north_star_monthly')),
      sbSelect(q('mv_adoption_pack_monthly'))
    ])
    const summary = {
      ttv_hours_p50: ttv.length ? ttv.map((x:any)=>x.ttv_hours).sort((a:number,b:number)=>a-b)[Math.floor(ttv.length*0.5)] : null,
      usd_saved_last_month: ns.filter((x:any)=> x.month === new Date(new Date().getFullYear(), new Date().getMonth()-1, 1).toISOString().slice(0,10))
                              .reduce((s:number,x:any)=> s + Number(x.usd_saved_estimated||0), 0),
      packs_adopted_last_month: adopt.filter((x:any)=>x.adopted).length
    }
    return ok({ summary, ttv, ns, adopt })
  } catch (e:any) {
    return bad(500, e.message)
  }
}
