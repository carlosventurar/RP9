
import { Handler } from '@netlify/functions'

const SB = { url: process.env.SUPABASE_URL!, key: process.env.SUPABASE_SERVICE_ROLE_KEY! }
async function exec(sql:string){
  const r = await fetch(`${SB.url}/rest/v1/rpc/exec_sql`, {
    method:'POST',
    headers:{ 'apikey':SB.key,'Authorization':`Bearer ${SB.key}`,'content-type':'application/json' },
    body: JSON.stringify({ q: sql })
  })
  if (!r.ok) throw new Error(await r.text())
  return r.json()
}

/**
 * Requiere crear función SQL:
 * create or replace function exec_sql(q text) returns json as $$
 * declare res json; begin execute q; return '{{"ok":true}}'::json; end; $$ language plpgsql security definer;
 * grant execute on function exec_sql(text) to postgres, anon, authenticated, service_role;
 */
export const handler: Handler = async () => {
  const views = ['mv_ttv_tenant','mv_north_star_monthly','mv_adoption_pack_monthly','mv_data_health_daily']
  for (const v of views) {
    await exec(`REFRESH MATERIALIZED VIEW CONCURRENTLY ${v};`)
  }
  return { statusCode: 200, body: JSON.stringify({ ok:true, refreshed: views }) }
}
