
import { Handler } from '@netlify/functions'

// Placeholder: genera JSON para PDF (delegar render a n8n/worker)
const SB = { url: process.env.SUPABASE_URL!, key: process.env.SUPABASE_SERVICE_ROLE_KEY! }

export const handler: Handler = async (event) => {
  const tenantId = event.queryStringParameters?.tenant_id || ''
  const month = event.queryStringParameters?.month || ''
  const headers = { 'apikey':SB.key,'Authorization':`Bearer ${SB.key}` }
  const q = (p:string)=> tenantId ? `${p}?tenant_id=eq.${tenantId}` : p
  const [ns, adopt] = await Promise.all([
    fetch(`${SB.url}/rest/v1/${q('mv_north_star_monthly')}`, { headers }).then(r=>r.json()),
    fetch(`${SB.url}/rest/v1/${q('mv_adoption_pack_monthly')}`, { headers }).then(r=>r.json())
  ])
  return { statusCode: 200, body: JSON.stringify({ month, ns, adopt }) }
}
