
import { Handler } from '@netlify/functions'
import crypto from 'crypto'

const SB = { url: process.env.SUPABASE_URL!, key: process.env.SUPABASE_SERVICE_ROLE_KEY! }
const SECRET = process.env.WEBHOOK_HMAC_SECRET || ''

function ok(body:any){ return { statusCode: 200, body: JSON.stringify(body) } }
function bad(code:number, msg:string){ return { statusCode: code, body: msg } }

export const handler: Handler = async (event) => {
  try {
    if (event.httpMethod !== 'POST') return bad(405, 'Method Not Allowed')
    // HMAC opcional
    if (SECRET) {
      const sig = event.headers['x-rp9-signature'] || ''
      const mac = crypto.createHmac('sha256', SECRET).update(event.body||'').digest('hex')
      if (sig !== mac) return bad(401, 'Bad signature')
    }
    const payload = JSON.parse(event.body||'{}')
    const rows = Array.isArray(payload) ? payload : [payload]
    const mapped = rows.map((r:any)=> ({
      tenant_id: r.tenant_id,
      user_id: r.user_id || null,
      session_id: r.session_id || null,
      source: r.source || 'portal',
      event: r.event,
      properties: r.properties || {},
      occurred_at: r.occurred_at || new Date().toISOString()
    }))
    await fetch(`${SB.url}/rest/v1/analytics_events`, {
      method:'POST',
      headers:{ 'apikey':SB.key,'Authorization':`Bearer ${SB.key}`,'content-type':'application/json' },
      body: JSON.stringify(mapped)
    })
    // Si llega un outcome normalizado, también registra
    const outcomes = rows.filter((r:any)=> r.event==='outcome.achieved' && r.outcome_type)
                         .map((r:any)=> ({
                           tenant_id: r.tenant_id,
                           workflow_id: r.workflow_id || null,
                           outcome_type: r.outcome_type,
                           value: r.value || null,
                           occurred_at: r.occurred_at || new Date().toISOString(),
                           meta: r.properties || {}
                         }))
    if (outcomes.length) {
      await fetch(`${SB.url}/rest/v1/business_outcomes`, {
        method:'POST',
        headers:{ 'apikey':SB.key,'Authorization':`Bearer ${SB.key}`,'content-type':'application/json' },
        body: JSON.stringify(outcomes)
      })
    }
    return ok({ ok:true, inserted: rows.length, outcomes: outcomes.length })
  } catch (e:any) {
    return bad(500, e.message)
  }
}
