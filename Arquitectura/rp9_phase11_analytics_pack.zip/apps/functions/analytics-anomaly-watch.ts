
import { Handler } from '@netlify/functions'

const SB = { url: process.env.SUPABASE_URL!, key: process.env.SUPABASE_SERVICE_ROLE_KEY! }
const SLACK = process.env.SLACK_WEBHOOK_URL

async function select(path:string){
  const r = await fetch(`${SB.url}/rest/v1/${path}`, { headers:{ 'apikey':SB.key,'Authorization':`Bearer ${SB.key}` } })
  if (!r.ok) throw new Error(await r.text())
  return r.json()
}
async function notify(text:string){
  if (!SLACK) return
  await fetch(SLACK, { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ text }) })
}

export const handler: Handler = async () => {
  // Heurísticas básicas (últimos 2 días vs 7 anteriores)
  const now = new Date(); const d1 = new Date(now.getTime() - 2*86400000).toISOString()
  const dh = await select(f"mv_data_health_daily?day=gte.{d1}")
  // Agrega reglas adicionales: éxito cae >20%, p95 sube 50% (requerir métricas adicionales)
  await notify(`RP9 Analytics: verificación completada (${dh.length} filas).`)
  return { statusCode: 200, body: JSON.stringify({ ok:true }) }
}
