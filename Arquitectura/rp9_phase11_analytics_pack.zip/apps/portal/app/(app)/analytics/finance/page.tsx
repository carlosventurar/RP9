
export default function AnalyticsFinancePage(){
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-2">Analítica — Finanzas</h1>
      <p className="text-slate-600">Incluye NSM USD, ARPU y consumo metered por plan. (Conectar a functions y charts).</p>
    </div>
  )
}
