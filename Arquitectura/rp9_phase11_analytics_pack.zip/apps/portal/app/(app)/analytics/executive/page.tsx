
'use client';
import useSWR from 'swr'
import { useSearchParams } from 'next/navigation'

const fetcher = (url:string)=> fetch(url).then(r=>r.json())

export default function AnalyticsExecutivePage(){
  const params = useSearchParams()
  const tenant = params.get('tenant_id') || ''
  const { data } = useSWR(`/.netlify/functions/analytics-kpis?tenant_id=${tenant}`, fetcher)
  const s = data?.summary || {}
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Analítica — Ejecutivo</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl border"><div className="text-sm text-slate-500">TTV P50</div><div className="text-2xl font-semibold">{s.ttv_hours_p50 ?? '—'} h</div></div>
        <div className="p-4 rounded-xl border"><div className="text-sm text-slate-500">ROI (USD) último mes</div><div className="text-2xl font-semibold">${s.usd_saved_last_month ?? 0}</div></div>
        <div className="p-4 rounded-xl border"><div className="text-sm text-slate-500">Packs adoptados</div><div className="text-2xl font-semibold">{s.packs_adopted_last_month ?? 0}</div></div>
      </div>
    </div>
  )
}
