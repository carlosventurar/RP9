import { Handler } from '@netlify/functions'
import { createClient } from '@supabase/supabase-js'

export const handler: Handler = async () => {
  // Stub: genera JSON (PDF a implementar con tu proveedor preferido)
  const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
  const { data: tenants } = await supabase.from('tenants').select('id, name').limit(50)
  // Para cada tenant, obtener KPIs y enviar por email (omitir implementación real)
  return { statusCode: 200, body: JSON.stringify({ ok:true, tenants: tenants?.length || 0 }) }
}
