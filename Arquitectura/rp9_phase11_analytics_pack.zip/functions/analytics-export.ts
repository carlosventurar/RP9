import { Handler } from '@netlify/functions'
import { createClient } from '@supabase/supabase-js'

export const handler: Handler = async (event) => {
  if(event.httpMethod!=='POST') return { statusCode:405, body:'Method Not Allowed' }
  const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
  const { query } = JSON.parse(event.body || '{}')
  // Por seguridad, soporta sólo queries predefinidas (switch/case) — evitar SQL arbitrario
  if(query==='roi_by_month'){
    const { data } = await supabase.from('mv_nsm_usd').select('*').order('month', { ascending: true })
    return { statusCode:200, body: JSON.stringify({ data }) }
  }
  return { statusCode:400, body: JSON.stringify({ error:'query no soportada' }) }
}
