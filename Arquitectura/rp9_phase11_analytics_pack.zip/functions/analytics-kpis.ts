import { Handler } from '@netlify/functions'
import { createClient } from '@supabase/supabase-js'

export const handler: Handler = async (event) => {
  const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
  const q = new URLSearchParams(event.queryStringParameters || {})
  const tenant = q.get('tenant_id')

  // ROI mensual
  const { data: roi } = await supabase.from('mv_nsm_usd').select('*').eq('tenant_id', tenant).order('month', { ascending: true })
  // Adopción
  const { data: adoption } = await supabase.from('mv_adoption_pack').select('*').eq('tenant_id', tenant)
  // TTV
  const { data: ttv } = await supabase.from('mv_ttv_cohorts_weekly').select('*').eq('tenant_id', tenant).order('cohort_week', { ascending: true })

  return { statusCode: 200, body: JSON.stringify({ roi, adoption, ttv }) }
}
