import { Handler } from '@netlify/functions'
import { createClient } from '@supabase/supabase-js'
import fetch from 'node-fetch'

async function postSlack(text:string){
  if(!process.env.SLACK_WEBHOOK_URL) return
  await fetch(process.env.SLACK_WEBHOOK_URL, { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ text }) })
}

export const handler: Handler = async () => {
  const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

  // Ejemplo: detectar caída de ROI >25% m/m (simple)
  const { data } = await supabase.rpc('get_roi_drop_alerts').catch(()=>({ data: [] } as any))

  if (Array.isArray(data) && data.length) {
    await postSlack(`⚠️ RP9 Analytics: caída de ROI en ${data.length} tenants. Detalle: ${JSON.stringify(data).slice(0,300)}…`)
  }

  return { statusCode: 200, body: JSON.stringify({ ok:true, alerts: data?.length || 0 }) }
}
