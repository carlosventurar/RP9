import { Handler } from '@netlify/functions'
import crypto from 'crypto'
import { createClient } from '@supabase/supabase-js'

function verifyHmac(body: string, sig: string|undefined, secret: string){
  if(!sig) return false
  const mac = crypto.createHmac('sha256', secret).update(body).digest('hex')
  return crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(mac))
}

export const handler: Handler = async (event) => {
  try{
    if(event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' }
    const secret = process.env.HMAC_SECRET || ''
    const ok = verifyHmac(event.body || '', event.headers['x-rp9-signature'], secret)
    if(!ok) return { statusCode: 401, body: 'Invalid signature' }

    const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
    const payload = JSON.parse(event.body || '{}')
    const { type, tenant_id, user_id, session_id, meta } = payload

    if(type?.startsWith('funnel_')){
      const step = type.replace('funnel_', '')
      await supabase.from('funnel_events').insert({ tenant_id, user_id, session_id, step, meta })
    } else if(type?.startsWith('outcome_')){
      const kind = type.replace('outcome_', '')
      await supabase.from('outcomes').insert({ tenant_id, user_id, workflow_id: payload.workflow_id, pack: payload.pack, kind, value_numeric: payload.value_numeric, meta })
    }

    return { statusCode: 200, body: JSON.stringify({ ok:true }) }
  }catch(e:any){
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) }
  }
}
