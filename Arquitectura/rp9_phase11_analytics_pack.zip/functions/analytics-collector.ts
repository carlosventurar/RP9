import { Handler } from '@netlify/functions'
import fetch from 'node-fetch'
import { createClient } from '@supabase/supabase-js'

export const handler: Handler = async () => {
  const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
  const base = (process.env.N8N_BASE_URL || '').replace(/\/$/, '')
  const key = process.env.N8N_API_KEY || ''

  // Simple: traer últimas N ejecuciones (ajusta paginación según necesidad)
  const r = await fetch(`${base}/api/v1/executions?limit=250&status=success`, { headers: { 'X-N8N-API-KEY': key, 'accept':'application/json' } })
  const data = await r.json()

  const rows = (data?.data || []).map((e:any) => ({
    tenant_id: e?.tenant_id || null,   // si no existe en n8n, resuélvelo en el BFF/mapper
    workflow_id: String(e?.workflowId || ''),
    execution_id: String(e?.id || ''),
    status: e?.status || 'success',
    started_at: e?.startedAt ? new Date(e.startedAt) : null,
    stopped_at: e?.stoppedAt ? new Date(e.stoppedAt) : null,
    duration_ms: e?.stoppedAt && e?.startedAt ? (new Date(e.stoppedAt).getTime() - new Date(e.startedAt).getTime()) : null
  }))

  // Idempotente por execution_id
  for(const row of rows){
    if(!row.execution_id) continue
    await supabase.from('usage_executions').upsert(row, { onConflict: 'execution_id' })
  }

  return { statusCode: 200, body: JSON.stringify({ ok: true, count: rows.length }) }
}
