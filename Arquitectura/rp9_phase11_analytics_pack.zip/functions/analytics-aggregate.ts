import { Handler } from '@netlify/functions'
import { createClient } from '@supabase/supabase-js'

export const handler: Handler = async () => {
  const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

  // Recalcular rollups diarios (ejemplo simple)
  await supabase.rpc('refresh_materialized_view', { view_name: 'mv_funnels_daily' }).catch(()=>{})
  await supabase.rpc('refresh_materialized_view', { view_name: 'mv_ttv_cohorts_weekly' }).catch(()=>{})
  await supabase.rpc('refresh_materialized_view', { view_name: 'mv_adoption_pack' }).catch(()=>{})
  await supabase.rpc('refresh_materialized_view', { view_name: 'mv_nsm_usd' }).catch(()=>{})

  return { statusCode: 200, body: JSON.stringify({ ok: true }) }
}
