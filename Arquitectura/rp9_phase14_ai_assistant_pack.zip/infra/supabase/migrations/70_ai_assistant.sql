
-- 70_ai_assistant.sql
create table if not exists ai_events (
  id bigserial primary key,
  tenant_id uuid not null,
  user_id uuid,
  type text not null,               -- generate|debug|optimize|profile|apply_fix|feedback
  provider text,                    -- openai|anthropic|cache
  tokens_in int default 0,
  tokens_out int default 0,
  cost_cents int default 0,
  latency_ms int,
  accepted boolean,
  meta jsonb default '{}',
  created_at timestamptz default now()
);

create table if not exists ai_budgets (
  tenant_id uuid primary key,
  monthly_limit_cents int not null default 1000,  -- $10 por defecto
  used_cents int not null default 0,
  month text not null default to_char((now() at time zone 'utc'),'YYYY-MM')
);

create table if not exists ai_versions (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  workflow_id text not null,
  base_hash text not null,
  new_hash text not null,
  diff jsonb not null,
  ai_meta jsonb default '{}',
  created_by uuid,
  created_at timestamptz default now()
);

create table if not exists ai_cache (
  key text primary key,             -- hash(prompt+contexto+provider+model)
  value jsonb not null,
  created_at timestamptz default now(),
  ttl_seconds int not null default 86400
);

create table if not exists ai_models (
  tenant_id uuid primary key,
  allow_byok boolean default true,
  order_pref jsonb default '["openai","anthropic"]'::jsonb
);

create table if not exists ai_prompts (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  version int not null default 1,
  body text not null,
  tags text[] default array[]::text[],
  created_at timestamptz default now()
);
