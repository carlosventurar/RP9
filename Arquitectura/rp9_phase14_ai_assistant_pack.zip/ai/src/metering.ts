
// ai/src/metering.ts
export function estimateCost(provider:string, inTok:number, outTok:number){
  // Estimación simple USD -> cents
  const rateIn = provider==='anthropic'? 0.000002 : 0.0000015
  const rateOut= provider==='anthropic'? 0.000006 : 0.000002
  const usd = inTok*rateIn + outTok*rateOut
  return Math.round(usd*100)
}

export class Budget {
  static async check(tenantId:string){ return { allowed:true, remaining_cents: 999 } }
  static async add(tenantId:string, cost_cents:number){ return true }
}
