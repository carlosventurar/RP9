
// ai/src/jsondiff.ts
export function jsonDiff(a:any,b:any): any[] {
  // minimal: replace whole if different
  if (JSON.stringify(a)===JSON.stringify(b)) return []
  return [{ op:'replace', path:'/', value:b }]
}
export function applyDiff(a:any, diff:any[]): any {
  if (!diff?.length) return a
  const rep = diff.find((d:any)=>d.op==='replace' && d.path==='/')
  return rep ? rep.value : a
}
