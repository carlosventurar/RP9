
// ai/src/redact.ts
export function redactPayload(text: string): string {
  if (!text) return text
  // emails
  text = text.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig, '[EMAIL]')
  // phones (simple)
  text = text.replace(/(\+?\d[\d\-\s]{7,}\d)/g, '[PHONE]')
  // credit cards (very naive)
  text = text.replace(/\b(?:\d[ -]*?){13,16}\b/g, '[CARD]')
  // national IDs (very naive, country‑agnostic)
  text = text.replace(/\b[A-Z0-9]{8,12}\b/g, '[ID]')
  return text
}
