
// ai/src/providers/openai.ts
export interface Provider {
  name: 'openai'|'anthropic'
  chat(system: string, messages: Array<{role:'user'|'system'|'assistant', content:string}>): Promise<{ output:any, tokensIn:number, tokensOut:number }>
}

export class OpenAIProvider implements Provider {
  name: 'openai' = 'openai'
  constructor(private apiKey: string){}
  async chat(system: string, messages: any[]) {
    // Stub: no internet access here. Simula respuesta estructurada.
    const output = { workflow: { name:'AI Flow', nodes:[], connections:{} }, explanation: 'Generado por stub', requirements: [] }
    const tokensIn = JSON.stringify(messages).length/4|0, tokensOut = JSON.stringify(output).length/4|0
    return { output, tokensIn, tokensOut }
  }
}
