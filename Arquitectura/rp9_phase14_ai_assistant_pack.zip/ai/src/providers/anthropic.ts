
// ai/src/providers/anthropic.ts
import type { Provider } from './openai'

export class AnthropicProvider implements Provider {
  name: 'anthropic' = 'anthropic'
  constructor(private apiKey: string){}
  async chat(system: string, messages: any[]) {
    const output = { workflow: { name:'AI Flow', nodes:[], connections:{} }, explanation: 'Generado por stub', requirements: [] }
    const tokensIn = JSON.stringify(messages).length/4|0, tokensOut = JSON.stringify(output).length/4|0
    return { output, tokensIn, tokensOut }
  }
}
