
// ai/src/providers/chooser.ts
import { Provider, OpenAIProvider } from './openai'
import { AnthropicProvider } from './anthropic'

export function chooseProvider(byok?: {provider?: 'openai'|'anthropic', apiKey?: string}): Provider {
  const order = ['openai','anthropic']
  const requested = byok?.provider
  const apiKey = byok?.apiKey
  if (requested === 'anthropic') return new AnthropicProvider(apiKey || process.env.ANTHROPIC_API_KEY || '')
  if (requested === 'openai') return new OpenAIProvider(apiKey || process.env.OPENAI_API_KEY || '')
  // default order with fallback
  const keyOpenAI = apiKey || process.env.OPENAI_API_KEY || ''
  if (keyOpenAI) return new OpenAIProvider(keyOpenAI)
  return new AnthropicProvider(apiKey || process.env.ANTHROPIC_API_KEY || '')
}
