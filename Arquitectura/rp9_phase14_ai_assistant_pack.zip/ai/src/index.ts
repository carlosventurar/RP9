
// ai/src/index.ts
import Fastify from 'fastify'
import { z } from 'zod'
import { chooseProvider } from './providers/chooser'
import { redactPayload } from './redact'
import { jsonDiff, applyDiff } from './jsondiff'
import { estimateCost, Budget } from './metering'
import { cacheGet, cacheSet, keyOf } from './simpleCache'

const fastify = Fastify({ logger: true })

const AI_TOKEN = process.env.AI_TOKEN || ''
const PORT = Number(process.env.AI_PORT || 8090)

fastify.addHook('onRequest', async (req, reply) => {
  const auth = req.headers.authorization || ''
  if (!auth.startsWith('Bearer ') || auth.slice(7) !== AI_TOKEN) {
    reply.code(401).send({ error: 'unauthorized' })
  }
})

const GenerateSchema = z.object({
  prompt: z.string().min(5),
  context: z.object({
    industry: z.string().optional(),
    availableIntegrations: z.array(z.string()).optional(),
    skillLevel: z.string().optional(),
    locale: z.string().optional()
  }).optional(),
  byok: z.object({
    provider: z.enum(['openai','anthropic']).optional(),
    apiKey: z.string().optional()
  }).optional()
})

fastify.post('/ai/generate-workflow', async (req, reply) => {
  const t0 = Date.now()
  const body = GenerateSchema.parse(req.body || {})
  const redacted = redactPayload(body.prompt)
  const provider = chooseProvider(body.byok)

  const cacheKey = keyOf('gen', redacted, provider.name)
  const cached = await cacheGet(cacheKey)
  if (cached) return reply.send({ ...cached, cached: true })

  const system = `Eres experto en n8n. Devuelve JSON con campos: workflow, explanation, requirements. El workflow debe ser válido n8n.`
  const input = { role: 'user', content: `${redacted}
Contexto:${JSON.stringify(body.context||{})}` }

  const { output, tokensIn, tokensOut } = await provider.chat(system, [input])
  // Nota: output.worklow es responsabilidad del prompt; validación mínima:
  const workflow = output?.workflow || { name:'AI Flow', nodes:[], connections:{} }
  const explanation = output?.explanation || 'Propuesta generada.'
  const requirements = output?.requirements || []

  const latency = Date.now()-t0
  const cost = estimateCost(provider.name, tokensIn, tokensOut)
  await cacheSet(cacheKey, { workflow, explanation, requirements }, Number(process.env.AI_CACHE_TTL_SECONDS||'86400'))
  reply.send({ workflow, explanation, requirements, tokensIn, tokensOut, cost, latency })
})

const DebugSchema = z.object({
  workflow: z.record(z.any()),
  errorLog: z.any(),
  byok: z.object({ provider: z.enum(['openai','anthropic']).optional(), apiKey: z.string().optional() }).optional()
})

fastify.post('/ai/debug', async (req, reply) => {
  const t0 = Date.now()
  const body = DebugSchema.parse(req.body||{})
  const provider = chooseProvider(body.byok)
  const prompt = `Analiza el siguiente workflow de n8n y el error. Devuelve JSON con: diagnosis, fixes[], affectedNodes[], optionalAutoFixDiff[].`
  const input = { role:'user', content:`WORKFLOW=${JSON.stringify(body.workflow)}\nERROR=${JSON.stringify(body.errorLog)}` }
  const { output, tokensIn, tokensOut } = await provider.chat(prompt, [input])
  const latency = Date.now()-t0
  const cost = estimateCost(provider.name, tokensIn, tokensOut)
  reply.send({ ...(output||{}), tokensIn, tokensOut, cost, latency })
})

const OptimizeSchema = z.object({
  workflow: z.record(z.any()),
  metrics: z.object({
    avgExecutionMs: z.number().optional(),
    errors: z.number().optional(),
    totalExecutions: z.number().optional()
  }).optional(),
  byok: z.object({ provider: z.enum(['openai','anthropic']).optional(), apiKey: z.string().optional() }).optional()
})

fastify.post('/ai/optimize', async (req, reply) => {
  const t0 = Date.now()
  const body = OptimizeSchema.parse(req.body||{})
  const provider = chooseProvider(body.byok)
  const prompt = `Revisa el workflow y propone optimizaciones (batching, retries, cache, paralelismo). Devuelve JSON con: suggestions[], diff[].`
  const input = { role:'user', content:`WORKFLOW=${JSON.stringify(body.workflow)}\nMETRICS=${JSON.stringify(body.metrics||{})}` }
  const { output, tokensIn, tokensOut } = await provider.chat(prompt, [input])
  const latency = Date.now()-t0
  const cost = estimateCost(provider.name, tokensIn, tokensOut)
  reply.send({ ...(output||{}), tokensIn, tokensOut, cost, latency })
})

const ApplySchema = z.object({
  workflow: z.record(z.any()),
  diff: z.array(z.any()),
  meta: z.object({ tenantId: z.string().optional(), workflowId: z.string().optional() }).optional()
})

fastify.post('/ai/apply-fix', async (req, reply) => {
  const body = ApplySchema.parse(req.body||{})
  const newWf = applyDiff(body.workflow, body.diff)
  // TODO: persist in Supabase as ai_versions with base/new hash + diff
  reply.send({ workflow: newWf })
})

const ProfileSchema = z.object({
  workflow: z.record(z.any()).optional(),
  executionIds: z.array(z.string()).optional()
})

fastify.post('/ai/profile', async (req, reply) => {
  const body = ProfileSchema.parse(req.body||{})
  // Stub profiler: calcula conteo de nodos y asigna tiempos simulados
  const nodes = (body.workflow?.nodes||[]).map((n:any)=> ({ name:n.name, p50: 120, p95: 450, calls: 100 }))
  reply.send({ nodes, bottlenecks: nodes.slice(0,2).map(n=>n.name) })
})

fastify.get('/ai/health', async (_req, reply)=> reply.send({ ok:true }))

fastify.listen({ port: PORT, host:'0.0.0.0' })
  .catch(err=>{ fastify.log.error(err); process.exit(1) })
