
# RP9 – AI Assistant Service (Fase 14)

## Quickstart
1) Copia `.env.example` → `.env` y completa tus claves.
2) `docker compose up -d --build` (levanta `ai-service` en :8090).
3) En Netlify, crea Function proxy (`apps/functions/ai-proxy.ts`) y define envs `AI_URL` y `AI_TOKEN`.
4) Desde el portal usa endpoints vía `/.netlify/functions/ai-proxy/ai/*`.

## Endpoints
- POST `/ai/generate-workflow` – crea blueprint + JSON n8n.
- POST `/ai/debug` – explica errores y propone fixes (con diff).
- POST `/ai/optimize` – optimización de performance/costos.
- POST `/ai/profile` – perfil de performance por nodo (stub).
- POST `/ai/apply-fix` – aplica diff y registra versión (conectar Supabase).

## Seguridad
- Token Bearer en cabecera (RP9 → AI Service).
- BYOK opcional por cabecera (`x-ai-key`) vía body `byok`.
- Redacción PII antes de componer prompts.

## Pendientes sugeridos
- Persistencia real en Supabase (`ai_events`, `ai_versions`, budgets).
- Integración n8n API para dry-run/sandbox y guardar PR AI como versión.
- UI: vista visual de diff (por nodo) y “1‑click fix” con rollback.
