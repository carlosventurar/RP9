
// apps/functions/ai-proxy.ts
import type { Handler } from '@netlify/functions'

const AI_URL = process.env.AI_URL || 'http://localhost:8090'
const AI_TOKEN = process.env.AI_TOKEN!

export const handler: Handler = async (event) => {
  if (!event.path) return { statusCode: 400, body: 'bad path' }
  const sub = event.path.replace('/.netlify/functions/ai-proxy', '')
  const url = AI_URL + sub
  const res = await fetch(url, {
    method: event.httpMethod,
    headers: { 'content-type': 'application/json', authorization: `Bearer ${AI_TOKEN}` },
    body: event.body
  })
  const data = await res.text()
  return { statusCode: res.status, body: data, headers: { 'content-type': res.headers.get('content-type')||'application/json' } }
}
