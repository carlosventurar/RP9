
// apps/portal/components/ai/FixPanel.tsx
'use client'
import { useState } from 'react'

export function FixPanel({ workflow }:{ workflow:any }){
  const [loading, setLoading] = useState(false)
  const [resp, setResp] = useState<any>(null)
  async function explain(err:any){
    setLoading(true)
    const r = await fetch('/.netlify/functions/ai-proxy/ai/debug',{method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ workflow, errorLog: err }) })
    setResp(await r.json()); setLoading(false)
  }
  return (
    <div className="space-y-3">
      <button disabled={loading} onClick={()=>explain({ message:'Timeout HTTP node'})} className="px-3 py-2 rounded bg-black text-white">
        {loading?'Analizando…':'Explicar & Sugerir Fix'}
      </button>
      {resp && <pre className="text-xs whitespace-pre-wrap">{JSON.stringify(resp,null,2)}</pre>}
    </div>
  )
}
