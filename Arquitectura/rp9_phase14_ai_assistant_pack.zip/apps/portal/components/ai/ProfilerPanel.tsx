
// apps/portal/components/ai/ProfilerPanel.tsx
'use client'
import { useState } from 'react'

export function ProfilerPanel({ workflow }:{ workflow:any }){
  const [data,setData] = useState<any>(null)
  async function run(){
    const r = await fetch('/.netlify/functions/ai-proxy/ai/profile',{method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ workflow }) })
    setData(await r.json())
  }
  return (
    <div className="border rounded-2xl p-4">
      <button onClick={run} className="px-3 py-2 rounded bg-black text-white">Perfil de performance</button>
      {data && <pre className="text-xs mt-3">{JSON.stringify(data,null,2)}</pre>}
    </div>
  )
}
