
// apps/portal/components/ai/DiffViewer.tsx
'use client'
import { useState } from 'react'

export function DiffViewer({ base, proposal }:{ base:any, proposal:any }){
  const [show, setShow] = useState<'json'|'visual'>('json')
  return (
    <div className="border rounded-2xl p-4">
      <div className="flex gap-2 mb-2">
        <button className="px-3 py-1 rounded bg-black text-white" onClick={()=>setShow('json')}>JSON</button>
        <button className="px-3 py-1 rounded bg-slate-200" onClick={()=>setShow('visual')}>Visual</button>
      </div>
      {show==='json' ? (
        <pre className="text-xs whitespace-pre-wrap">{JSON.stringify({base, proposal}, null, 2)}</pre>
      ) : (
        <div className="text-sm text-slate-600">Vista visual (pendiente) — resalta nodos añadidos/modificados.</div>
      )}
    </div>
  )
}
