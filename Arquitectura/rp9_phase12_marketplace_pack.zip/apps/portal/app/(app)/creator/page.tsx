
export default function CreatorCenter(){
  return (
    <div className="space-y-2">
      <h1 className="text-2xl font-semibold">Creator Center</h1>
      <p className="text-slate-600">Sube plantillas, revisa curaduría, métricas e ingresos.</p>
    </div>
  )
}
