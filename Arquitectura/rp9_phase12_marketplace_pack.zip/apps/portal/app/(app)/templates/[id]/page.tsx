
'use client';
import useSWR from 'swr'
import { useParams } from 'next/navigation'

const fetcher = (url:string)=> fetch(url).then(r=>r.json())

export default function TemplateDetail(){
  const params = useParams() as any
  const id = params?.id
  const { data } = useSWR(id ? `/.netlify/functions/marketplace/template-detail?id=${id}` : null, fetcher)
  const tpl = data || {}
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">{tpl.title || 'Plantilla'}</h1>
      <p className="text-slate-600">{tpl.summary}</p>
      <div className="flex gap-2">
        {(tpl.tags||[]).map((t:string)=>(<span key={t} className="text-xs bg-slate-100 px-2 py-1 rounded">{t}</span>))}
      </div>
      <div className="space-y-2">
        <button className="px-3 py-2 rounded bg-black text-white">Comprar/Instalar</button>
        <button className="px-3 py-2 rounded border">Vista previa</button>
      </div>
    </div>
  )
}
