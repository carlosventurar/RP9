// app/(app)/templates/[slug]/page.tsx
export default function TemplateDetail(){ return <div style={{padding:20}}>Detalle de plantilla (placeholder)</div> }
