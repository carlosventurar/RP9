// app/(app)/templates/page.tsx
'use client'
export default function TemplatesPage(){ return <div style={{padding:20}}>Marketplace: listado placeholder</div> }
