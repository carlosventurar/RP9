
'use client';
import useSWR from 'swr'
import Link from 'next/link'

const fetcher = (url:string)=> fetch(url).then(r=>r.json())

export default function TemplatesPage(){
  const { data } = useSWR('/.netlify/functions/marketplace/templates-list', fetcher)
  const items = data?.items || []
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Marketplace de Plantillas</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map((it:any)=>(
          <Link key={it.id} href={`/templates/${it.id}`} className="border rounded-2xl p-4 hover:shadow">
            <div className="text-sm text-slate-500">{it.category}</div>
            <div className="font-medium">{it.title}</div>
            <div className="text-xs mt-1">{(it.tags||[]).join(' · ')}</div>
          </Link>
        ))}
      </div>
    </div>
  )
}
