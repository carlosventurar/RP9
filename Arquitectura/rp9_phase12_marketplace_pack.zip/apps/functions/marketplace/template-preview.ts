
import { Handler } from '@netlify/functions'
// Devuelve una versión 'safe' del JSON (sin credenciales) para preview
const SB = { url: process.env.SUPABASE_URL!, key: process.env.SUPABASE_SERVICE_ROLE_KEY! }
const headers = { 'apikey':SB.key, 'Authorization':`Bearer ${SB.key}` }

function scrub(workflow:any){
  const copy = JSON.parse(JSON.stringify(workflow))
  if (Array.isArray(copy.nodes)) {
    for (const n of copy.nodes) {
      if (n.credentials) {
        for (const k of Object.keys(n.credentials)) {
          n.credentials[k] = { id:'PLACEHOLDER', name:'Configure your credentials' }
        }
      }
      if (n.parameters) {
        // Remueve datos sensibles comunes
        for (const k of Object.keys(n.parameters)) {
          if (String(k).match(/password|secret|token|key/i)) n.parameters[k] = '***'
        }
      }
    }
  }
  return copy
}

export const handler: Handler = async (event) => {
  try {
    const versionId = event.queryStringParameters?.version_id
    if (!versionId) return { statusCode: 400, body: 'version_id required' }
    const r = await fetch(`${SB.url}/rest/v1/template_versions?id=eq.${versionId}`, { headers })
    const [v] = await r.json()
    if (!v) return { statusCode: 404, body: 'not found' }
    return { statusCode: 200, body: JSON.stringify({ version:v.version, preview: scrub(v.n8n_json) }) }
  } catch (e:any) {
    return { statusCode: 500, body: e.message }
  }
}
