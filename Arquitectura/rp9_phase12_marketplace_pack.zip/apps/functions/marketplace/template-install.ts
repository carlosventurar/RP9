
import { Handler } from '@netlify/functions'

const SB = { url: process.env.SUPABASE_URL!, key: process.env.SUPABASE_SERVICE_ROLE_KEY! }
const N8N = { url: process.env.N8N_BASE_URL!, key: process.env.N8N_API_KEY! }

export const handler: Handler = async (event) => {
  try {
    if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' }
    const { tenant_id, template_version_id, workflow_name, credentialsMap } = JSON.parse(event.body||'{}')
    if (!tenant_id || !template_version_id) return { statusCode: 400, body: 'tenant_id and template_version_id required' }

    // 1) Fetch template version
    const tv = await fetch(`${SB.url}/rest/v1/template_versions?id=eq.${template_version_id}`, {
      headers:{ 'apikey':SB.key, 'Authorization':`Bearer ${SB.key}` }
    }).then(r=>r.json()).then(arr=>arr[0])
    if (!tv) return { statusCode: 404, body: 'template version not found' }

    // 2) Map credentials placeholders if provided
    const wf = JSON.parse(JSON.stringify(tv.n8n_json))
    if (credentialsMap && Array.isArray(wf.nodes)) {
      for (const n of wf.nodes) {
        if (n.credentials) {
          for (const ck of Object.keys(n.credentials)) {
            if (credentialsMap[ck]) n.credentials[ck] = credentialsMap[ck]
          }
        }
      }
    }
    if (workflow_name) wf.name = workflow_name

    // 3) Create workflow in n8n
    const r = await fetch(`${N8N.url.replace(/\/$/,'')}/api/v1/workflows`, {
      method:'POST',
      headers:{ 'content-type':'application/json', 'X-N8N-API-KEY': N8N.key },
      body: JSON.stringify(wf)
    })
    if (!r.ok) return { statusCode: r.status, body: await r.text() }
    const created = await r.json()

    // 4) Record installation
    await fetch(`${SB.url}/rest/v1/template_installations`, {
      method:'POST',
      headers:{ 'apikey':SB.key, 'Authorization':`Bearer ${SB.key}`, 'content-type':'application/json' },
      body: JSON.stringify({
        tenant_id, template_id: tv.template_id, template_version_id, workflow_id: created.id, status:'installed'
      })
    })

    return { statusCode: 200, body: JSON.stringify({ ok:true, workflow_id: created.id }) }
  } catch (e:any) {
    return { statusCode: 500, body: e.message }
  }
}
