
import { Handler } from '@netlify/functions'
import Stripe from 'stripe'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' })
const SB = { url: process.env.SUPABASE_URL!, key: process.env.SUPABASE_SERVICE_ROLE_KEY! }
const headers = { 'apikey':SB.key, 'Authorization':`Bearer ${SB.key}`, 'content-type':'application/json' }

export const handler: Handler = async (event) => {
  try {
    if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' }
    const { tenant_id, template_id, mode, success_url, cancel_url, price_cents=0, currency='usd' } = JSON.parse(event.body||'{}')
    if (!tenant_id || !template_id || !mode) return { statusCode: 400, body: 'tenant_id, template_id, mode required' }

    // Create pending order (for reconciliation)
    const ordRes = await fetch(`${SB.url}/rest/v1/orders`, {
      method:'POST', headers, body: JSON.stringify({ tenant_id, subtotal: price_cents/100, total: price_cents/100, status:'pending', currency })
    })
    const [order] = await ordRes.json()

    const session = await stripe.checkout.sessions.create({
      mode: mode === 'subscription' ? 'subscription' : 'payment',
      line_items: [{ price_data: { currency, product_data: { name: `RP9 Template ${template_id}` }, unit_amount: price_cents }, quantity: 1 }],
      success_url: success_url || 'https://app.rp9.io/templates?status=success',
      cancel_url: cancel_url || 'https://app.rp9.io/templates?status=cancel',
      metadata: { tenant_id, template_id, order_id: order.id }
    })

    await fetch(`${SB.url}/rest/v1/orders?id=eq.${order.id}`, {
      method:'PATCH', headers, body: JSON.stringify({ stripe_checkout_id: session.id })
    })

    return { statusCode: 200, body: JSON.stringify({ checkout_url: session.url }) }
  } catch (e:any) {
    return { statusCode: 500, body: e.message }
  }
}
