
import { Handler } from '@netlify/functions'

const SB = { url: process.env.SUPABASE_URL!, key: process.env.SUPABASE_SERVICE_ROLE_KEY! }
const headers = { 'apikey':SB.key, 'Authorization':`Bearer ${SB.key}`, 'content-type':'application/json' }

export const handler: Handler = async (event) => {
  try {
    if (event.httpMethod!=='POST') return { statusCode:405, body:'Method Not Allowed' }
    const body = JSON.parse(event.body||'{}')
    // body: { creator_id, title, category, tags, price_oneoff?, price_monthly?, n8n_json, readme, requires[] }
    if (!body.creator_id || !body.title || !body.category || !body.n8n_json) return { statusCode:400, body:'missing fields' }

    // 1) Crea template draft
    const tRes = await fetch(`${SB.url}/rest/v1/templates`, { method:'POST', headers, body: JSON.stringify({
      owner_creator: body.creator_id, title: body.title, category: body.category, tags: body.tags||[], kind: 'template',
      price_oneoff: body.price_oneoff||0, price_monthly: body.price_monthly||null, status:'review'
    })})
    const [t] = await tRes.json()

    // 2) Crea versión
    await fetch(`${SB.url}/rest/v1/template_versions`, { method:'POST', headers, body: JSON.stringify({
      template_id: t.id, version: '1.0.0', n8n_json: body.n8n_json, requires: body.requires||[], linter_passed: false
    })})

    // 3) Encola curaduría
    await fetch(`${SB.url}/rest/v1/curation_queue`, { method:'POST', headers, body: JSON.stringify({ template_id: t.id, status:'queued' }) })

    return { statusCode: 200, body: JSON.stringify({ ok:true, template_id: t.id }) }
  } catch (e:any) {
    return { statusCode:500, body:e.message }
  }
}
