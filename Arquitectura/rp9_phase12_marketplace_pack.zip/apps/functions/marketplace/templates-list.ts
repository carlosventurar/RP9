
import { Handler } from '@netlify/functions'

const SB = { url: process.env.SUPABASE_URL!, key: process.env.SUPABASE_SERVICE_ROLE_KEY! }
const headers = { 'apikey':SB.key, 'Authorization':`Bearer ${SB.key}` }

export const handler: Handler = async (event) => {
  try {
    const qs = event.queryStringParameters || {}
    const category = qs.category || ''
    const search = qs.search || ''
    let path = 'templates?status=eq.published'
    if (category) path += `&category=eq.${encodeURIComponent(category)}`
    if (search) path += `&or=(title.ilike.*${encodeURIComponent(search)}*,summary.ilike.*${encodeURIComponent(search)}*)`
    const r = await fetch(`${SB.url}/rest/v1/${path}`, { headers })
    const data = await r.json()
    return { statusCode: 200, body: JSON.stringify({ items: data }) }
  } catch (e:any) {
    return { statusCode: 500, body: e.message }
  }
}
