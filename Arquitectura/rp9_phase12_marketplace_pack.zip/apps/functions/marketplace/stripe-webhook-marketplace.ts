
import { Handler } from '@netlify/functions'
import Stripe from 'stripe'
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' })

const SB = { url: process.env.SUPABASE_URL!, key: process.env.SUPABASE_SERVICE_ROLE_KEY! }
const headers = { 'apikey':SB.key, 'Authorization':`Bearer ${SB.key}`, 'content-type':'application/json' }
const WH = process.env.STRIPE_WEBHOOK_SECRET!

export const handler: Handler = async (event) => {
  try {
    const sig = event.headers['stripe-signature'] as string
    const evt = stripe.webhooks.constructEvent(event.body!, sig, WH)

    if (evt.type === 'checkout.session.completed') {
      const s = evt.data.object as Stripe.Checkout.Session
      const { tenant_id, template_id, order_id } = (s.metadata||{}) as any
      // Mark order paid
      await fetch(`${SB.url}/rest/v1/orders?id=eq.${order_id}`, { method:'PATCH', headers, body: JSON.stringify({ status:'paid', stripe_payment_intent: s.payment_intent }) })
      // Issue license
      await fetch(`${SB.url}/rest/v1/licenses`, {
        method:'POST', headers,
        body: JSON.stringify({ tenant_id, template_id, kind: s.mode==='subscription'?'subscription':'oneoff', status:'active', fingerprint: `${tenant_id}:${order_id}:${template_id}`, order_id })
      })
      // Accrue payout item (split 70/30 via revenue_share_rules or default)
      // (Para simplificar, asumimos 70% del total al creator si existe)
      const total = (s.amount_total||0)/100
      const payoutItem = { template_id, amount: total*0.70, meta: { stripe_session: s.id, currency: s.currency } }
      // Guardar item suelto; la liquidación mensual consolidará en payouts
      await fetch(`${SB.url}/rest/v1/payout_items`, { method:'POST', headers, body: JSON.stringify(payoutItem) })
    }

    return { statusCode: 200, body: JSON.stringify({ received: true }) }
  } catch (e:any) {
    return { statusCode: 400, body: `Webhook error: ${e.message}` }
  }
}
