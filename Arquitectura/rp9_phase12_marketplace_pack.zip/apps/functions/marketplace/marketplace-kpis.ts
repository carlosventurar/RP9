
import { Handler } from '@netlify/functions'
const SB = { url: process.env.SUPABASE_URL!, key: process.env.SUPABASE_SERVICE_ROLE_KEY! }
const headers = { 'apikey':SB.key, 'Authorization':`Bearer ${SB.key}` }

export const handler: Handler = async () => {
  const t = await fetch(`${SB.url}/rest/v1/templates?select=id,title,installs,rating_avg&status=eq.published&order=installs.desc`, { headers }).then(r=>r.json())
  const rank = await fetch(`${SB.url}/rest/v1/mv_adoption_pack_rank?order=score.desc&limit=20`, { headers }).then(r=>r.json())
  return { statusCode: 200, body: JSON.stringify({ top_templates: t, adoption_rank: rank }) }
}
