import { Handler } from '@netlify/functions'

export const handler: Handler = async (event, context) => {
  try {
    if (event.httpMethod === 'OPTIONS') return { statusCode: 200, body: '' }
    // TODO: implement
    return { statusCode: 200, body: JSON.stringify({ ok: true }) }
  } catch (e:any) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) }
  }
}
