# RP9 Creator Guidelines (MVP)
- README con descripción, variables y pasos.
- Tags (industria, proveedor, CRM).
- Mock data y diagrama.
- Changelog semántico (semver).
- Pasar linter (sanitización y secretos).
- Pruebas de instalación automática (script).
- Soporte: responder issues en ≤72h.
