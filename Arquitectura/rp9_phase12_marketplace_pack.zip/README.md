# RP9 Marketplace (Fase 12)

## Pasos rápidos
1) Importa `infra/supabase/migrations/30_marketplace.sql` en Supabase.
2) Configura `.env` con Stripe y Supabase. 
3) Despliega Functions en Netlify (ver `netlify.toml`). 
4) Carga seeds (categorías/tags y 3 packs mock).
5) Prueba `marketplace-list`/`detail`/`purchase`/`install`.

> Nota: Los handlers están como esqueleto — completa lógica de negocio.
