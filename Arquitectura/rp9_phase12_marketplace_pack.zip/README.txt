
RP9 — Fase 12 (Marketplace & Plantillas monetizadas)
===================================================

1) Supabase
-----------
- Ejecuta `infra/supabase/migrations/70_marketplace.sql`.
- Habilita RLS y políticas según tu auth (ver comentarios).
- Crea **Storage** para `template_assets` (opcional).

2) Stripe
---------
- Activa **Stripe Connect (Standard)** para payouts.
- Configura webhook → `stripe-webhook-marketplace` (events: checkout.session.completed).

3) Netlify Functions
--------------------
- Despliega todo `apps/functions/marketplace/*` y define variables `.env`.
- Endpoints:
  - `templates-list`, `template-detail`, `template-preview`
  - `template-purchase`, `stripe-webhook-marketplace`
  - `template-install`, `creator-submit`, `marketplace-kpis`

4) Portal
---------
- Páginas: `/templates`, `/templates/[id]`, `/creator`.
- Añade CTA “Instalar en 1‑click” (usa `template-install`).

5) CI
-----
- Ejecuta `scripts/sanitize-workflow.ts` al recibir submissions.
- Añade linter de metadata (pendiente) y pruebas de instalación en tenant demo.
