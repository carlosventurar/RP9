-- 30_marketplace.sql (ver también el .md para detalles)
-- Ejecutar en Supabase; ajusta RLS según tu modelo de auth.
-- (Contenido idéntico al bloque SQL del .md)

-- CREATOR & KYC
create table if not exists creators (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,         -- user del portal
  country text,
  display_name text,
  stripe_account_id text,        -- Connect
  status text default 'pending', -- pending|active|disabled
  created_at timestamptz default now()
);
create unique index if not exists creators_user_uidx on creators(user_id);

-- TAXONOMY + GOVERNANCE
create table if not exists catalog_categories (
  key text primary key,          -- cc, fin, wa, ops, etc.
  name text not null
);
insert into catalog_categories(key,name) values
  ('cc','Contact Center') on conflict do nothing;

create table if not exists catalog_tags (
  id bigserial primary key,
  tag text unique not null
);

-- ITEMS
create table if not exists marketplace_items (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  type text not null check (type in ('template','pack','solution')),
  category_key text references catalog_categories(key),
  owner_creator uuid references creators(id) on delete set null,
  title text not null,
  short_desc text not null,
  long_desc text,
  images jsonb default '[]',
  -- pricing híbrido
  currency text default 'usd',
  one_off_price_cents int,             -- null si no aplica
  subscription_price_cents int,        -- null si no aplica
  tier text default 'mid',             -- low|mid|pro|enterprise
  revenue_share_bps int default 7000,  -- 70/30
  status text default 'draft',         -- draft|pending|approved|rejected|delisted
  featured_score numeric default 0,
  metadata jsonb default '{}',
  version text default '1.0.0',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists item_tags (
  item_id uuid references marketplace_items(id) on delete cascade,
  tag_id bigint references catalog_tags(id) on delete cascade,
  primary key (item_id, tag_id)
);

create table if not exists item_versions (
  id bigserial primary key,
  item_id uuid references marketplace_items(id) on delete cascade,
  version text not null,
  changelog text,
  json_url text,          -- Storage key del JSON export n8n
  passed_lint boolean default false,
  created_at timestamptz default now()
);

-- PREVIEW TOKENS (limit free runs)
create table if not exists preview_tokens (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  item_id uuid references marketplace_items(id) on delete cascade,
  remaining int default 5,
  last_used_at timestamptz,
  created_at timestamptz default now()
);

-- PURCHASES & LICENSE
create table if not exists purchases (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  buyer_user uuid,
  item_id uuid references marketplace_items(id) on delete cascade,
  stripe_customer_id text,
  stripe_payment_intent_id text,
  stripe_subscription_id text,
  currency text not null,
  amount_cents int not null,
  kind text not null check (kind in ('one_off','subscription')),
  status text not null default 'active', -- active|refunded|canceled
  fingerprint text,            -- hash(tenant_id+item_id+stripe_id)
  created_at timestamptz default now()
);
create index on purchases (tenant_id, item_id);

create table if not exists refunds (
  id bigserial primary key,
  purchase_id uuid references purchases(id) on delete cascade,
  reason text,
  stripe_refund_id text,
  status text default 'pending', -- pending|approved|rejected|done
  created_at timestamptz default now()
);

-- INSTALLS & ADOPTION
create table if not exists template_installs (
  id bigserial primary key,
  tenant_id uuid not null,
  item_id uuid references marketplace_items(id) on delete cascade,
  workflow_id text,                 -- id en n8n
  executions_30d int default 0,
  outcomes_30d int default 0,
  last_exec_at timestamptz,
  created_at timestamptz default now(),
  unique (tenant_id, item_id)
);

-- CREATOR EARNINGS & PAYOUTS
create table if not exists creator_earnings (
  id bigserial primary key,
  creator_id uuid references creators(id) on delete cascade,
  item_id uuid references marketplace_items(id) on delete set null,
  purchase_id uuid references purchases(id) on delete set null,
  amount_cents int not null,     -- neto para creator
  currency text not null,
  created_at timestamptz default now(),
  paid_out boolean default false,
  payout_id uuid
);

create table if not exists payouts (
  id uuid primary key default gen_random_uuid(),
  creator_id uuid references creators(id) on delete cascade,
  stripe_transfer_id text,
  period_start date,
  period_end date,
  amount_cents int not null,
  currency text default 'usd',
  status text default 'pending', -- pending|paid|failed
  created_at timestamptz default now()
);

-- RLS (ejemplo mínimo; ajustar políticas por rol)
alter table purchases enable row level security;
create policy purchases_by_tenant on purchases
  using (true); -- en Functions usar service role; UI filtra por tenant.

-- Views útiles
create or replace view v_adoption_score as
select
  i.id as item_id,
  i.title,
  coalesce(sum(t.executions_30d),0) as exec_30d,
  coalesce(sum(t.outcomes_30d),0) as out_30d,
  case
    when coalesce(sum(t.executions_30d),0)=0 and coalesce(sum(t.outcomes_30d),0)=0 then 0
    else
      ( (coalesce(sum(t.executions_30d),0)::numeric) / nullif((select max(exec_30d) from (
            select sum(executions_30d) exec_30d from template_installs group by item_id) m),0) * 0.6 )
      +
      ( (coalesce(sum(t.outcomes_30d),0)::numeric) / nullif((select max(out_30d) from (
            select sum(outcomes_30d) out_30d from template_installs group by item_id) m),0) * 0.4 )
  end as score_30d
from marketplace_items i
left join template_installs t on t.item_id = i.id
group by i.id, i.title;
