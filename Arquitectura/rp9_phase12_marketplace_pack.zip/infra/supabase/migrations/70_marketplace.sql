
-- 70_marketplace.sql
-- Esquema base de Marketplace RP9 (Supabase/Postgres)

-- =======================
-- Catálogo y versiones
-- =======================
create table if not exists creators (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  user_id uuid,                -- opcional: vínculo a auth
  name text not null,
  email text,
  country text,
  status text default 'pending',  -- pending|approved|blocked
  payout_account_id text,         -- Stripe Connect account
  meta jsonb default '{}'::jsonb
);

create table if not exists templates (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  code text unique,               -- CC-001, FIN-003, PACK-CC-STARTER
  kind text not null,             -- template|pack
  title text not null,
  summary text,
  category text,                  -- CC|FIN|MKT|OPS...
  tags text[] default '{}',
  price_oneoff numeric,           -- USD
  price_monthly numeric,          -- USD (para pack subscriptivo)
  currency text default 'usd',
  owner_creator uuid references creators(id),
  status text default 'draft',    -- draft|review|published|suspended
  rating_avg numeric default 0,
  installs int default 0,
  metadata jsonb default '{}'::jsonb
);

create table if not exists template_versions (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  template_id uuid references templates(id) on delete cascade,
  version text not null,          -- semver
  n8n_json jsonb not null,        -- workflow o pack manifest
  changelog text,
  requires text[],                -- credenciales/servicios
  is_major boolean default false,
  linter_passed boolean default false,
  published_at timestamptz
);
create index if not exists idx_tv_template on template_versions(template_id, created_at desc);

create table if not exists template_assets (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  template_id uuid references templates(id) on delete cascade,
  type text not null,             -- image|video|doc
  path text not null,             -- Supabase Storage key
  meta jsonb default '{}'::jsonb
);

-- =======================
-- Compras, instalaciones y licencias
-- =======================
create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  tenant_id uuid,                 -- comprador
  buyer_email text,
  stripe_checkout_id text,
  stripe_payment_intent text,
  currency text default 'usd',
  subtotal numeric not null,
  tax numeric default 0,
  total numeric not null,
  status text default 'pending'   -- pending|paid|refunded|canceled
);
create index on orders (tenant_id, created_at desc);

create table if not exists order_items (
  id bigserial primary key,
  order_id uuid references orders(id) on delete cascade,
  template_id uuid references templates(id) on delete set null,
  template_version_id uuid references template_versions(id) on delete set null,
  kind text not null,             -- oneoff|subscription|bundle
  unit_price numeric not null,
  qty int not null default 1,
  total numeric not null
);

create table if not exists licenses (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  tenant_id uuid not null,
  template_id uuid not null references templates(id),
  template_version_id uuid references template_versions(id),
  kind text not null,             -- oneoff|subscription
  status text default 'active',   -- active|expired|revoked
  fingerprint text,               -- hash (tenant_id + order_id + template_id)
  order_id uuid references orders(id)
);
create index on licenses (tenant_id, template_id);

create table if not exists template_installations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  tenant_id uuid not null,
  template_id uuid not null references templates(id),
  template_version_id uuid not null references template_versions(id),
  workflow_id text,               -- id/name creado en n8n
  status text default 'installed',-- installed|updated|removed
  meta jsonb default '{}'::jsonb
);
create index on template_installations (tenant_id, template_id, created_at desc);

-- =======================
-- Ratings & Reviews
-- =======================
create table if not exists ratings (
  id bigserial primary key,
  created_at timestamptz default now(),
  tenant_id uuid,
  template_id uuid references templates(id) on delete cascade,
  rating int check (rating between 1 and 5),
  review text,
  unique (tenant_id, template_id)
);

-- =======================
-- Curation / Featured / Discounts
-- =======================
create table if not exists curation_queue (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  creator_id uuid references creators(id),
  template_id uuid references templates(id),
  template_version_id uuid references template_versions(id),
  status text default 'queued',   -- queued|approved|rejected
  notes text
);

create table if not exists featured_slots (
  id bigserial primary key,
  created_at timestamptz default now(),
  template_id uuid references templates(id),
  starts_at timestamptz,
  ends_at timestamptz,
  placement text not null,        -- home|category|banner
  sponsored boolean default false
);

create table if not exists discounts (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  code text unique,
  type text not null,             -- percent|fixed|bundle
  value numeric not null,
  meta jsonb default '{{}}'::jsonb,
  starts_at timestamptz,
  ends_at timestamptz,
  active boolean default true
);

-- =======================
-- Revenue Share & Payouts
-- =======================
create table if not exists revenue_share_rules (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  template_id uuid references templates(id),
  share_creator numeric not null default 0.70,  -- 70/30 por defecto
  share_rp9 numeric not null default 0.30
);

create table if not exists payouts (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  creator_id uuid references creators(id),
  month date not null,
  gross_amount numeric not null default 0,
  fees numeric default 0,
  tax_withheld numeric default 0,
  net_amount numeric not null default 0,
  currency text default 'usd',
  status text default 'pending',            -- pending|paid|failed
  stripe_transfer_id text
);
create unique index on payouts (creator_id, month);

create table if not exists payout_items (
  id bigserial primary key,
  payout_id uuid references payouts(id) on delete cascade,
  order_id uuid references orders(id) on delete set null,
  order_item_id bigint references order_items(id) on delete set null,
  template_id uuid references templates(id),
  amount numeric not null,
  meta jsonb default '{{}}'::jsonb
);

-- =======================
-- Adopción por pack (ranking/payouts)
-- Depende de usage_executions y business_outcomes (fases anteriores)
-- =======================
create materialized view if not exists mv_adoption_pack_rank as
with execs as (
  select tenant_id,
         date_trunc('month', coalesce(stopped_at, created_at))::date as month,
         workflow_id,
         count(*) filter (where status='success') as ok
  from usage_executions
  group by 1,2,3
),
map as (
  select t.id as template_id, t.code, t.category,
         tv.id as template_version_id
  from templates t
  left join template_versions tv on tv.template_id = t.id
),
pack_exec as (
  select e.tenant_id, e.month,
         case when e.workflow_id ilike 'CC-%' then 'CC'
              when e.workflow_id ilike 'FIN-%' then 'FIN' else 'GEN' end as pack,
         sum(e.ok) as executions
  from execs e
  group by 1,2,3
),
outc as (
  select tenant_id,
         date_trunc('month', occurred_at)::date as month,
         case when outcome_type ilike 'ticket.%' then 'CC'
              when outcome_type ilike 'cfdi.%' or outcome_type ilike 'dian.%' then 'FIN'
              else 'GEN' end as pack,
         count(*) as outcomes
  from business_outcomes
  group by 1,2,3
)
select coalesce(pe.month, o.month) as month,
       coalesce(pe.pack, o.pack) as pack,
       sum(coalesce(pe.executions,0)) as executions,
       sum(coalesce(o.outcomes,0)) as outcomes,
       round( (0.6*sum(coalesce(pe.executions,0))::numeric) + (0.4*sum(coalesce(o.outcomes,0))::numeric), 2) as score
from pack_exec pe
full join outc o on pe.tenant_id=o.tenant_id and pe.month=o.month and pe.pack=o.pack
group by 1,2;

-- =======================
-- RLS (esqueleto; ajustar a tu auth)
-- =======================
-- alter table templates enable row level security;
-- create policy read_templates on templates for select using (true);
-- (agrega políticas para tenants/creators según tu modelo de auth)
