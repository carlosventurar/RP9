
// scripts/sanitize-workflow.ts
// node scripts/sanitize-workflow.js < input.json > output.json
import fs from 'fs'
function sanitize(json:any){
  const wf = typeof json === 'string' ? JSON.parse(json) : json
  if (Array.isArray(wf.nodes)) {
    for (const n of wf.nodes) {
      if (n.credentials) {
        for (const k of Object.keys(n.credentials)) {
          n.credentials[k] = { id:'PLACEHOLDER', name:'Configure your credentials' }
        }
      }
      if (n.parameters) {
        for (const k of Object.keys(n.parameters)) {
          if (String(k).match(/password|secret|token|key/i)) n.parameters[k] = '***'
        }
      }
    }
  }
  return wf
}
const input = fs.readFileSync(0, 'utf-8')
const out = sanitize(input)
process.stdout.write(JSON.stringify(out, null, 2))
